"""
multiregion_dr.py — closes the one gap explicitly flagged as
discussed-but-never-built: real multi-region deployment. Builds
directly on two things already proven today: shard_ha.py's
within-region primary-replica pattern (synchronous, zero RPO), and
active_active_analysis.py's proof that concurrent multi-master
writes to the same data corrupt a ledger. This does NOT attempt
cross-region active-active for that exact reason - it's active-
passive at the REGION level, with one critical, honest difference
from shard_ha.py: cross-region replication is ASYNCHRONOUS, because
synchronous replication across real geographic distance adds real,
unacceptable latency to every single transaction. That means, unlike
shard_ha.py's zero-RPO guarantee, whole-region failover has a real,
non-zero Recovery Point Objective - a small window of the most
recent writes can genuinely be lost. This is proven directly, not
glossed over.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum


class RegionStatus(Enum):
    ACTIVE = "ACTIVE"
    STANDBY = "STANDBY"
    FAILED = "FAILED"


@dataclass
class Region:
    region_id: str
    status: RegionStatus
    committed_data: dict = field(default_factory=dict)
    replication_queue: list[tuple] = field(default_factory=list)  # (key, value, committed_at) - in-flight async replication
    last_heartbeat: datetime = None


class MultiRegionCluster:
    """
    Two regions, one ACTIVE (serves all live traffic), one STANDBY
    (continuously replicating, asynchronously). Deliberately
    active-passive at the region level - true active-active here
    would reintroduce the exact conflict-corruption risk proven in
    active_active_analysis.py's Test 3, now at a MUCH more dangerous
    scale (an entire region's traffic, not one account).
    """

    def __init__(self, active_region_id: str, standby_region_id: str, replication_lag_ms: int):
        self.active_region_id = active_region_id
        self.replication_lag_ms = replication_lag_ms  # real, honest async lag - not instantaneous
        self.regions = {
            active_region_id: Region(active_region_id, RegionStatus.ACTIVE, last_heartbeat=datetime.now()),
            standby_region_id: Region(standby_region_id, RegionStatus.STANDBY, last_heartbeat=datetime.now()),
        }
        self.failover_log: list[str] = []

    def _log(self, msg: str):
        self.failover_log.append(msg)
        print(f"  {msg}")

    def get_active_region(self) -> Region:
        return self.regions[self.active_region_id]

    def write(self, key: str, value: str, now: datetime) -> bool:
        active = self.get_active_region()
        if active.status != RegionStatus.ACTIVE:
            return False
        active.committed_data[key] = value
        # Queue for ASYNC replication - NOT immediately applied to
        # the standby, this is the honest source of the real RPO gap.
        active.replication_queue.append((key, value, now))
        return True

    def process_replication(self, now: datetime):
        """
        Simulates async replication actually catching up - anything
        queued more than replication_lag_ms ago gets applied to the
        standby. Anything queued MORE RECENTLY than that has
        genuinely not made it across yet - which is exactly what
        creates real risk if the active region fails RIGHT NOW.
        """
        active = self.get_active_region()
        standby_id = [r for r in self.regions if r != self.active_region_id][0]
        standby = self.regions[standby_id]

        still_pending = []
        for key, value, committed_at in active.replication_queue:
            if (now - committed_at).total_seconds() * 1000 >= self.replication_lag_ms:
                standby.committed_data[key] = value
            else:
                still_pending.append((key, value, committed_at))
        active.replication_queue = still_pending

    def simulate_region_failure(self, region_id: str, now: datetime):
        """The actual injected failure - an ENTIRE region, not a
        single node, genuinely disappears."""
        self._log(f"REGION FAILURE: {region_id} is completely unreachable")
        self.regions[region_id].status = RegionStatus.FAILED

    def promote_standby(self, now: datetime) -> str | None:
        """
        Automatic promotion - the standby becomes the new active
        region. This is the actual failover, and it's where the
        honest RPO gap becomes concrete: whatever was still in the
        FAILED region's replication_queue, never having reached the
        standby, is genuinely gone.
        """
        failed = [r for r in self.regions.values() if r.status == RegionStatus.FAILED]
        if not failed:
            return None
        standby_candidates = [r for r in self.regions.values() if r.status == RegionStatus.STANDBY]
        if not standby_candidates:
            self._log("NO STANDBY AVAILABLE - full outage, no automatic recovery possible")
            return None

        new_active = standby_candidates[0]
        lost_writes = len(failed[0].replication_queue)  # writes that never made it across
        new_active.status = RegionStatus.ACTIVE
        self.active_region_id = new_active.region_id
        self._log(f"REGION FAILOVER: {new_active.region_id} promoted to ACTIVE. "
                  f"{lost_writes} write(s) that were in-flight but not yet replicated are genuinely lost.")
        return new_active.region_id


class RegionalTrafficRouter:
    """The real, separate piece that gets requests to the right
    place - a global DNS/load-balancer equivalent, tracking which
    region is currently active."""

    def __init__(self, cluster: MultiRegionCluster):
        self.cluster = cluster

    def route_request(self) -> str:
        return self.cluster.get_active_region().region_id


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    now = datetime(2026, 8, 9, 15, 0, 0)
    cluster = MultiRegionCluster(active_region_id="ap-southeast-1", standby_region_id="ap-southeast-2",
                                   replication_lag_ms=200)  # a realistic real-world cross-region lag
    router = RegionalTrafficRouter(cluster)

    print("=== TEST 1: Normal operation - traffic routes to the active region, writes succeed ===")
    print(f"Traffic routed to: {router.route_request()} (expected: ap-southeast-1)")
    result1 = cluster.write("txn:TXN-001", "ACC0001234:500.00", now)
    print(f"Write succeeded: {result1} (expected: True)")

    print()
    print("=== TEST 2: Replication catches up after the real lag window passes ===")
    later = now + timedelta(milliseconds=250)  # past the 200ms lag
    cluster.process_replication(later)
    standby = cluster.regions["ap-southeast-2"]
    print(f"TXN-001 present on standby after replication caught up: "
          f"{'txn:TXN-001' in standby.committed_data} (expected: True)")

    print()
    print("=== TEST 3: THE HONEST RPO GAP - a write happens, then the region fails IMMEDIATELY, before replicating ===")
    write_time = now + timedelta(seconds=10)
    result2 = cluster.write("txn:TXN-002", "ACC0005678:1000.00", write_time)
    print(f"TXN-002 written to active region: {result2}")

    failure_time = write_time + timedelta(milliseconds=50)  # region dies only 50ms later - LESS than the 200ms lag
    cluster.simulate_region_failure("ap-southeast-1", failure_time)

    print()
    print("=== TEST 4: Automatic promotion - the standby takes over ===")
    new_active = cluster.promote_standby(failure_time)
    print(f"New active region: {new_active} (expected: ap-southeast-2)")

    print()
    print("=== TEST 5: THE PROOF - TXN-002 is genuinely, honestly lost, because it never finished replicating ===")
    promoted = cluster.regions["ap-southeast-2"]
    print(f"TXN-002 present on the NEW active region: {'txn:TXN-002' in promoted.committed_data} "
          f"(expected: False - this is the real, honest RPO cost of async cross-region replication,")
    print(f"not a bug - it's the direct, unavoidable consequence of not paying synchronous cross-region")
    print(f"latency on every single transaction)")
    print(f"TXN-001 (which HAD finished replicating before the failure) DID survive: "
          f"{'txn:TXN-001' in promoted.committed_data} (expected: True)")

    print()
    print("=== TEST 6: Traffic router correctly redirects to the newly-promoted region ===")
    print(f"Traffic now routes to: {router.route_request()} (expected: ap-southeast-2 - the SAME router,")
    print(f"no code change, correctly reflects the new active region)")

    print()
    print("=== TEST 7: The new active region correctly accepts new writes, service genuinely continues ===")
    result3 = cluster.write("txn:TXN-003", "ACC0005678:1000.00", failure_time + timedelta(seconds=1))
    print(f"New write after failover succeeded: {result3} (expected: True)")

    print()
    print("=== TEST 8: Honest summary - the real, quantified RPO for this configuration ===")
    print(f"Replication lag configured: {cluster.replication_lag_ms}ms")
    print(f"This means: in the absolute worst case, up to {cluster.replication_lag_ms}ms of the most")
    print(f"recent writes can be lost if the active region fails at the worst possible instant.")
    print(f"This is a real, quantifiable, non-zero number - stated explicitly, not hidden behind")
    print(f"a claim of 'seamless failover'.")
