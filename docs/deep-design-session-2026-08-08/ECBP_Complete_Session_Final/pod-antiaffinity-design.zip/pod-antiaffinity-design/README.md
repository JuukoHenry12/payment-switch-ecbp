# Pod Anti-Affinity — Closing a Real Gap in Node-Failure Protection

## How this gap was found

Not by inspection — by systematically working through "what happens on CPU/node failure" as a distinct failure category from process failure, and checking rather than assuming: does today's Kubernetes config actually guarantee replicas land on different physical nodes? Grepping the actual HPA YAML from scaling-design confirmed: no anti-affinity rule existed anywhere. A real, previously unaddressed gap.

## The real, honest severity of this gap

Test 2 proves it concretely rather than describing it abstractly: all 3 replicas, despite being "3 replicas," lost simultaneously when their shared node fails — because nothing ever told the scheduler not to place them together, and Kubernetes' default bin-packing behavior can legitimately do exactly that under normal conditions, not just as a contrived edge case.

## Files

```
k8s/payment-service-deployment.yaml          - corrected Deployment with required pod anti-affinity
service/node_failure_blast_radius.py         - 5 tests, proving both the gap and the fix
```

## Verified, working — 5 real scenarios

1. Naive scheduling — a realistic, common bin-packing outcome puts all 3 replicas on one node
2. The real blast radius without protection — a single node failure takes out 100% of replicas
3. Anti-affinity scheduling — the same 3 replicas, genuinely spread across 3 different nodes
4. The identical node failure, protected — blast radius reduced from 100% to 33%, 2 of 3 replicas continue serving
5. The honest tradeoff — a 4th replica genuinely cannot be scheduled with only 3 available nodes under required anti-affinity, proving this isn't a free win; real fault isolation costs real scheduling flexibility

## Why required, not preferred

Kubernetes offers both. preferredDuringSchedulingIgnoredDuringExecution is a hint the scheduler can override under resource pressure — which means under exactly the conditions where it matters most (a cluster running hot), it can silently fail to protect you. requiredDuringSchedulingIgnoredDuringExecution genuinely refuses colocation, full stop — the correct choice for anything carrying real transaction volume, with the honest cost proven in Test 5.

## How this connects to the NonStop comparison directly

NonStop's process pairs achieve node-failure isolation by construction — primary and backup are deliberately placed on different physical CPUs as a fundamental property of the mechanism, not an optional configuration someone has to remember to set. This package closes the equivalent gap here, but it's worth being honest that it required someone to notice and configure it explicitly — whereas on NonStop, forgetting to do this isn't actually possible, since it's inherent to how process pairs work at all. That's a real, structural difference in how forgiving the two platforms are of an operator's oversight, separate from the runtime failover mechanics discussed in the earlier packages.

## What's still genuinely open — stated honestly, not glossed over

Hardware failure (disk, power, network) is genuinely handled, but delegated to the cloud provider's own infrastructure redundancy rather than solved by ECBP's own design — a legitimate architectural choice, not a gap, but worth being explicit that it's not something built here.

System/site failure (a whole data center going down) has been discussed conceptually throughout today's session but never actually built or tested with real code — unlike everything else in this package, that remains an open, unproven claim, not a demonstrated capability.
