-- ============================================================
-- ECBP Reconciliation & Exception ("Break") Handling — DDL
-- ============================================================
-- The core problem this solves: every settlement decision made so
-- far is ECBP's own OPTIMISTIC view - "we released liquidity and
-- sent this." The ground truth is whatever the external network
-- actually confirms, and there is always a real gap between those
-- two things. This schema tracks that gap explicitly, rather than
-- assuming it away.
-- ============================================================

CREATE TABLE RECONCILIATION_BREAK (
    BREAK_ID                UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    SETTLEMENT_ID            UUID            NOT NULL,   -- FK to SETTLEMENT_INSTRUCTION
    BREAK_TYPE               VARCHAR(30)     NOT NULL,   -- OVERDUE_CONFIRMATION, AMOUNT_MISMATCH,
                                                          -- REFERENCE_MISMATCH, LATE_EXTERNAL_FAILURE
    EXPECTED_AMOUNT          DECIMAL(18,2)   NULL,
    ACTUAL_AMOUNT            DECIMAL(18,2)   NULL,       -- populated for AMOUNT_MISMATCH
    EXPECTED_REFERENCE       VARCHAR(100)    NULL,
    ACTUAL_REFERENCE         VARCHAR(100)    NULL,       -- populated for REFERENCE_MISMATCH
    STATUS                   VARCHAR(20)     NOT NULL DEFAULT 'OPEN', -- OPEN, INVESTIGATING, RESOLVED, ESCALATED
    DETECTED_AT               TIMESTAMPTZ     NOT NULL DEFAULT now(),
    RESOLVED_AT                TIMESTAMPTZ    NULL,
    RESOLUTION_NOTES            TEXT           NULL,
    RESOLUTION_ACTION            VARCHAR(30)   NULL       -- ACCEPTED_LATE, MANUAL_CORRECTION, REVERSED, WRITTEN_OFF
);

CREATE INDEX IDX_BREAK_STATUS ON RECONCILIATION_BREAK (STATUS) WHERE STATUS != 'RESOLVED';
CREATE INDEX IDX_BREAK_SETTLEMENT ON RECONCILIATION_BREAK (SETTLEMENT_ID);

-- Every SETTLEMENT_INSTRUCTION needs an explicit SLA to know what
-- "overdue" even means, per settlement account (real-time rails vs
-- correspondent banking have very different realistic SLAs).
ALTER TABLE SETTLEMENT_ACCOUNT
    ADD COLUMN CONFIRMATION_SLA_SECONDS INTEGER NOT NULL DEFAULT 30;
    -- e.g. 5 seconds for a real-time rail, 3600+ for a SWIFT correspondent

-- Sample: a SWIFT correspondent relationship realistically has a
-- much longer confirmation SLA than a real-time rail
UPDATE SETTLEMENT_ACCOUNT SET CONFIRMATION_SLA_SECONDS = 5
    WHERE ACCOUNT_TYPE = 'RTGS_RESERVE';
UPDATE SETTLEMENT_ACCOUNT SET CONFIRMATION_SLA_SECONDS = 7200
    WHERE ACCOUNT_TYPE = 'NOSTRO';
