## IMPORTANT FIX — apply this to SettlementDecisionEngine.java from the earlier design pass

`attemptSettlement()` had no idempotency guard. If a Kafka consumer ever
redelivers the same `PaymentSettled` event — a completely normal, expected
occurrence in any event-driven system, not a bug elsewhere — the method
would reserve and settle the same instruction a second time.

**Add this check as the very first line of `attemptSettlement()`:**

```java
public SettlementOutcome attemptSettlement(SettlementInstruction instruction) {

    // IDEMPOTENCY GUARD - added during the reconciliation design pass.
    // Without this, a redelivered PaymentSettled event (normal Kafka
    // behavior under at-least-once delivery) would double-settle.
    Optional<SettlementStatus> existingStatus =
            instructionRepository.getExistingStatus(instruction.settlementId());
    if (existingStatus.isPresent() && existingStatus.get() != SettlementStatus.FAILED) {
        return SettlementOutcome.ALREADY_PROCESSED;
    }

    SettlementAccount account = instructionRepository
            .getSettlementAccount(instruction.settlementAccountId());
    // ... rest of the method unchanged
```

Add `ALREADY_PROCESSED` to the `SettlementOutcome` enum, and add
`getExistingStatus(String settlementId)` to the
`SettlementInstructionRepository` interface.

**Why this matters specifically here, not just as a general best practice:**
this is precisely the kind of bug that would pass every unit test written
against a single, clean call, and only surface under real production
message redelivery — exactly the category of issue chaos/load testing
(Phase 24-25 in the roadmap) exists to catch, but far better to fix by
design now than discover then.
