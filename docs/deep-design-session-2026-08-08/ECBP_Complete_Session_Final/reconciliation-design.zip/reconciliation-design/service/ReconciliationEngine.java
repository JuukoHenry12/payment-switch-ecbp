package com.balasubramani.ecbp.reconciliation.service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * ReconciliationEngine — detects the gap between ECBP's own
 * optimistic settlement view and external ground truth, in three
 * distinct ways:
 *
 *   1. TIMEOUT SWEEP: a settlement was marked SETTLED/RELEASED, but
 *      no ExternalSettlementConfirmed event arrived within that
 *      account's configured SLA. This runs periodically (e.g. every
 *      minute) as a scheduled sweep, not reactively - you cannot
 *      react to an event that never arrives, only notice its absence.
 *
 *   2. MATCH VALIDATION: when ExternalSettlementConfirmed DOES
 *      arrive, verify its amount and reference actually match what
 *      was sent. Blindly trusting an incoming confirmation without
 *      checking it against the original instruction is a genuine,
 *      real operational risk - reconciliation exists specifically
 *      to catch data integrity problems, not just absence.
 *
 *   3. LATE FAILURE HANDLING: the worst case - the external network
 *      reports a rejection/failure AFTER ECBP already settled
 *      internally. This cannot be handled by the original saga's
 *      compensation logic (that saga already completed successfully
 *      from ECBP's perspective) - it requires triggering a NEW,
 *      explicit reversal transaction, clearly distinguished in the
 *      ledger from a normal compensation.
 */
public class ReconciliationEngine {

    private final SettlementRepository settlementRepository;
    private final BreakRepository breakRepository;
    private final ReversalTrigger reversalTrigger;

    public ReconciliationEngine(
            SettlementRepository settlementRepository,
            BreakRepository breakRepository,
            ReversalTrigger reversalTrigger) {
        this.settlementRepository = settlementRepository;
        this.breakRepository = breakRepository;
        this.reversalTrigger = reversalTrigger;
    }

    /**
     * Scheduled sweep — call periodically (e.g. every 60 seconds).
     * Finds every settled/released instruction whose SLA has elapsed
     * with no external confirmation, and opens a break for each.
     */
    public List<ReconciliationBreak> runTimeoutSweep(Instant now) {
        List<SettlementInstruction> unconfirmed =
                settlementRepository.findSettledWithoutConfirmation();

        return unconfirmed.stream()
                .filter(instr -> isOverdue(instr, now))
                .map(instr -> openBreak(instr, BreakType.OVERDUE_CONFIRMATION, null, null))
                .toList();
    }

    private boolean isOverdue(SettlementInstruction instr, Instant now) {
        int slaSeconds = settlementRepository.getConfirmationSla(instr.settlementAccountId());
        Duration elapsed = Duration.between(instr.settledAt(), now);
        return elapsed.getSeconds() > slaSeconds;
    }

    /**
     * Called when an ExternalSettlementConfirmed event actually
     * arrives. This is where blind trust would be a mistake - always
     * validate against what was actually sent.
     */
    public ReconciliationOutcome processConfirmation(
            String settlementId, BigDecimal confirmedAmount, String confirmedReference) {

        SettlementInstruction original = settlementRepository.get(settlementId);

        if (original.amount().compareTo(confirmedAmount) != 0) {
            ReconciliationBreak brk = openBreak(
                    original, BreakType.AMOUNT_MISMATCH, confirmedAmount, confirmedReference);
            return ReconciliationOutcome.breakDetected(brk);
        }

        if (!Objects.equals(original.expectedReference(), confirmedReference)) {
            ReconciliationBreak brk = openBreak(
                    original, BreakType.REFERENCE_MISMATCH, confirmedAmount, confirmedReference);
            return ReconciliationOutcome.breakDetected(brk);
        }

        // Genuinely matches - close out cleanly, no break needed.
        settlementRepository.markExternallyConfirmed(settlementId, confirmedReference);
        return ReconciliationOutcome.clean();
    }

    /**
     * Called when the external network reports a failure for a
     * settlement ECBP had ALREADY marked settled internally. This is
     * the case that genuinely requires a new reversal, not just
     * closing a break record - real money-equivalent state (an
     * internal ledger entry, a released hold) needs to be undone.
     */
    public ReconciliationOutcome processLateExternalFailure(String settlementId, String failureReason) {

        SettlementInstruction original = settlementRepository.get(settlementId);

        ReconciliationBreak brk = openBreak(original, BreakType.LATE_EXTERNAL_FAILURE, null, null);

        // This is intentionally NOT automatic in every case - a late
        // failure on a large-value settlement is exactly the kind of
        // event that should require a human decision (ESCALATED)
        // rather than a fully automated reversal, given the real
        // financial and reputational stakes. Small-value, high-
        // confidence cases can reverse automatically; large or
        // ambiguous ones should not.
        if (original.amount().compareTo(AUTO_REVERSAL_THRESHOLD) <= 0) {
            reversalTrigger.triggerReversal(original.txnId(), failureReason);
            breakRepository.updateStatus(brk.breakId(), BreakStatus.RESOLVED, "REVERSED",
                    "Auto-reversed: amount below threshold, late external failure");
        } else {
            breakRepository.updateStatus(brk.breakId(), BreakStatus.ESCALATED, null,
                    "Amount exceeds auto-reversal threshold - requires manual review");
        }

        return ReconciliationOutcome.breakDetected(brk);
    }

    private ReconciliationBreak openBreak(
            SettlementInstruction instr, BreakType type,
            BigDecimal actualAmount, String actualReference) {

        ReconciliationBreak brk = new ReconciliationBreak(
                instr.settlementId(), type, instr.amount(), actualAmount,
                instr.expectedReference(), actualReference, Instant.now());

        breakRepository.save(brk);
        return brk;
    }

    private static final BigDecimal AUTO_REVERSAL_THRESHOLD = new BigDecimal("1000.00");
    // Deliberately conservative and configurable - a real institution
    // would set this based on actual risk appetite, not a hardcoded
    // constant. Kept simple here to make the decision point visible.

    // --- Supporting types ---

    public enum BreakType { OVERDUE_CONFIRMATION, AMOUNT_MISMATCH, REFERENCE_MISMATCH, LATE_EXTERNAL_FAILURE }
    public enum BreakStatus { OPEN, INVESTIGATING, RESOLVED, ESCALATED }

    public record SettlementInstruction(
            String settlementId, String settlementAccountId, String txnId,
            BigDecimal amount, String expectedReference, Instant settledAt) {}

    public record ReconciliationBreak(
            String settlementId, BreakType type, BigDecimal expectedAmount, BigDecimal actualAmount,
            String expectedReference, String actualReference, Instant detectedAt) {
        public String breakId() { return settlementId + "-" + type; } // simplified for this design pass
    }

    public record ReconciliationOutcome(boolean hasBreak, Optional<ReconciliationBreak> theBreak) {
        public static ReconciliationOutcome clean() {
            return new ReconciliationOutcome(false, Optional.empty());
        }
        public static ReconciliationOutcome breakDetected(ReconciliationBreak brk) {
            return new ReconciliationOutcome(true, Optional.of(brk));
        }
    }

    public interface SettlementRepository {
        SettlementInstruction get(String settlementId);
        List<SettlementInstruction> findSettledWithoutConfirmation();
        int getConfirmationSla(String settlementAccountId);
        void markExternallyConfirmed(String settlementId, String confirmedReference);
    }

    public interface BreakRepository {
        void save(ReconciliationBreak brk);
        void updateStatus(String breakId, BreakStatus status, String resolutionAction, String notes);
    }

    public interface ReversalTrigger {
        void triggerReversal(String txnId, String reason);
    }
}
