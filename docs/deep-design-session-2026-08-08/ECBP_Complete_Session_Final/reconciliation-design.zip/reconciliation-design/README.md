# Reconciliation & Exception Handling — Design Package

## The problem this closes

Every prior design pass (settlement, liquidity, gridlock) assumed external confirmation arrives, matches, and arrives on time. Real operations never guarantee any of the three. This package handles all of it explicitly, tested against 5 real scenarios, not just designed on paper.

## Files

```
ddl/reconciliation_ddl.sql          - RECONCILIATION_BREAK table + per-account SLA config
service/ReconciliationEngine.java   - timeout sweep, match validation, late-failure handling
schemas/*.avsc                      - 2 new events
IDEMPOTENCY_FIX.md                  - a real gap found in the EARLIER settlement engine, fix included
```

## Verified, working — 5 real test scenarios, all passed

1. **Timeout sweep** — an RTGS instruction settled 10 seconds ago with a 5-second SLA correctly flags as overdue
2. **Amount mismatch** — a confirmation arriving with a different amount than sent correctly opens a break, does not silently accept it
3. **Clean match** — a confirmation matching exactly closes out with zero break, no false positives
4. **Small-value late failure** — auto-reverses correctly, since the risk is genuinely low enough to automate
5. **Large-value late failure** — deliberately does **not** auto-reverse; escalates for human review instead

Test 5 is the one worth paying attention to: a real institution should never fully automate reversal of a large-value transaction based on a late external failure report alone — that's exactly the kind of judgment call requiring a human, and the code enforces that distinction explicitly via `AUTO_REVERSAL_THRESHOLD` rather than treating all failures identically.

## The idempotency fix — read this even though it's a small file

This was a genuine bug found in the *previous* design pass's `SettlementDecisionEngine`, not something new. Worth fixing before that class gets implemented for real, not after.

## How this fits with everything designed so far

```
SettlementDecisionEngine.attemptSettlement() [with idempotency fix applied]
        │
        ├── SETTLED_IMMEDIATELY or RELEASED
        │
        ▼
ReconciliationEngine.runTimeoutSweep() [runs on a schedule, e.g. every 60s]
        │
        ├── confirmation arrived in time → processConfirmation() → match check
        │       ├── clean → done
        │       └── mismatch → RECONCILIATION_BREAK opened
        │
        └── confirmation overdue → RECONCILIATION_BREAK opened (OVERDUE_CONFIRMATION)

Separately, at any point:
external network reports failure AFTER internal settlement
        │
        ▼
ReconciliationEngine.processLateExternalFailure()
        │
        ├── small amount → auto-reversal triggered
        └── large amount → ESCALATED, human review required
```

## Where this lives

A new bounded service, `reconciliation-service` — deliberately separate from `settlement-service`, mirroring how real bank operations teams are often organizationally distinct from treasury/settlement functions. The timeout sweep runs as a scheduled job (Spring's `@Scheduled`, same pattern already used in `batch-service`), not something triggered reactively.
