"""
token_lifecycle_service.py — closes three real gaps in the earlier
tokenization design: (1) persistent tokens for stored-card/recurring
use cases, using a genuine HMAC-based lookup so the same PAN always
resolves to the same token without ever storing the PAN in
searchable form; (2) full lifecycle management - suspend, reactivate,
revoke, each audited; (3) a safe "verification view" that never
touches the real PAN or the strict detokenization gate at all.
"""

import hashlib
import hmac
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


HMAC_LOOKUP_KEY = b"ecbp-token-lookup-hmac-key-would-be-in-HSM-KMS"  # same principle as the security-design package's KEK


class TokenType(Enum):
    DYNAMIC = "DYNAMIC"       # a fresh token every call - prevents correlation, for wallet/POS use
    PERSISTENT = "PERSISTENT"  # same token every call for the same PAN - for stored-card/recurring billing


class TokenStatus(Enum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"
    REVOKED = "REVOKED"


class TokenRevokedError(Exception):
    pass


@dataclass
class TokenRecord:
    token: str
    token_type: TokenType
    status: TokenStatus
    pan_last_four: str
    revoked_reason: str | None = None


def pan_lookup_hash(pan: str) -> str:
    """
    A keyed HMAC of the PAN - deliberately NOT a plain hash. A plain
    SHA-256 of a PAN would be vulnerable to a rainbow-table style
    attack (PANs are only 13-19 digits, a genuinely small search
    space to brute-force against an unkeyed hash). HMAC with a secret
    key closes that specific, real weakness.
    """
    return hmac.new(HMAC_LOOKUP_KEY, pan.encode(), hashlib.sha256).hexdigest()


class TokenLifecycleService:

    def __init__(self):
        self._tokens: dict[str, TokenRecord] = {}          # token -> record
        self._persistent_lookup: dict[str, str] = {}       # pan_lookup_hash -> token
        self._lifecycle_log: list[dict] = []

    def _log_event(self, token: str, action: str, reason: str | None, performed_by: str):
        self._lifecycle_log.append({
            "token": token, "action": action, "reason": reason,
            "performed_by": performed_by, "at": datetime.now(timezone.utc),
        })

    def get_or_create_persistent_token(self, pan: str, performed_by: str) -> str:
        """
        THE key correctness property for stored-card use cases: the
        SAME pan always returns the SAME token, via the HMAC lookup -
        no duplicate tokens ever created for the same underlying card.
        """
        lookup_hash = pan_lookup_hash(pan)

        if lookup_hash in self._persistent_lookup:
            existing_token = self._persistent_lookup[lookup_hash]
            record = self._tokens[existing_token]
            if record.status == TokenStatus.REVOKED:
                raise TokenRevokedError(
                    f"This card's token was revoked ({record.revoked_reason}) - "
                    f"cannot reuse for a new transaction, a fresh card must be provided")
            return existing_token

        # Genuinely new card - create a fresh persistent token
        token = self._generate_token(pan)
        self._tokens[token] = TokenRecord(
            token=token, token_type=TokenType.PERSISTENT, status=TokenStatus.ACTIVE,
            pan_last_four=pan[-4:],
        )
        self._persistent_lookup[lookup_hash] = token
        self._log_event(token, "CREATED", None, performed_by)
        return token

    def create_dynamic_token(self, pan: str, performed_by: str) -> str:
        """The original behavior from the security-design package,
        preserved exactly - a fresh token every call, for wallet/POS
        use where correlation prevention matters more than reuse."""
        token = self._generate_token(pan)
        self._tokens[token] = TokenRecord(
            token=token, token_type=TokenType.DYNAMIC, status=TokenStatus.ACTIVE,
            pan_last_four=pan[-4:],
        )
        self._log_event(token, "CREATED", None, performed_by)
        return token

    def _generate_token(self, pan: str) -> str:
        bin_prefix = pan[:6]
        random_digits = "".join(secrets.choice("0123456789") for _ in range(len(pan) - 6))
        return bin_prefix + random_digits

    def revoke(self, token: str, reason: str, performed_by: str):
        """Card reported lost/stolen - permanent, cannot be undone.
        Every future authorization attempt using this token must
        fail, checked at the point of use (tested below, tying
        directly into card-service's authorize() from earlier)."""
        record = self._tokens.get(token)
        if record is None:
            raise ValueError(f"Unknown token: {token}")
        record.status = TokenStatus.REVOKED
        record.revoked_reason = reason
        self._log_event(token, "REVOKED", reason, performed_by)

    def suspend(self, token: str, reason: str, performed_by: str):
        """Temporary hold - e.g. suspected fraud under investigation,
        NOT yet confirmed lost/stolen. Reversible, unlike revocation."""
        record = self._tokens.get(token)
        record.status = TokenStatus.SUSPENDED
        self._log_event(token, "SUSPENDED", reason, performed_by)

    def reactivate(self, token: str, performed_by: str):
        record = self._tokens.get(token)
        if record.status == TokenStatus.REVOKED:
            raise ValueError("A REVOKED token can never be reactivated - only SUSPENDED tokens can be")
        record.status = TokenStatus.ACTIVE
        self._log_event(token, "REACTIVATED", None, performed_by)

    def get_masked_view(self, token: str) -> str:
        """
        THE actual answer to 'how do we see the tokenized PAN for
        verification' - this NEVER touches ENCRYPTED_PAN, NEVER calls
        detokenize(), and therefore never invokes the strict
        default-deny access control gate from the security-design
        package at all. For verification purposes (customer service
        confirming 'is this the right card', a statement display),
        the real PAN is simply never needed.
        """
        record = self._tokens.get(token)
        if record is None:
            return "Card not found"
        return f"•••• •••• •••• {record.pan_last_four}"

    def check_usable(self, token: str) -> bool:
        record = self._tokens.get(token)
        return record is not None and record.status == TokenStatus.ACTIVE


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    service = TokenLifecycleService()
    real_pan = "4532123456789012"

    print("=== TEST 1: Persistent token - the SAME PAN always returns the SAME token ===")
    token_a = service.get_or_create_persistent_token(real_pan, performed_by="card-service")
    token_b = service.get_or_create_persistent_token(real_pan, performed_by="payment-service")
    token_c = service.get_or_create_persistent_token(real_pan, performed_by="settlement-service")
    print(f"card-service got:       {token_a}")
    print(f"payment-service got:    {token_b}")
    print(f"settlement-service got: {token_c}")
    print(f"All three identical (correct token PROPAGATION across service boundaries): "
          f"{token_a == token_b == token_c}")

    print()
    print("=== TEST 2: Dynamic token mode STILL works exactly as before - different token every call ===")
    dyn1 = service.create_dynamic_token(real_pan, performed_by="wallet-service")
    dyn2 = service.create_dynamic_token(real_pan, performed_by="wallet-service")
    print(f"First dynamic token:  {dyn1}")
    print(f"Second dynamic token: {dyn2}")
    print(f"Genuinely different, preserving the original correlation-prevention property: {dyn1 != dyn2}")

    print()
    print("=== TEST 3: Safe masked view - verification WITHOUT ever touching the real PAN ===")
    masked = service.get_masked_view(token_a)
    print(f"Masked view: {masked}")
    print(f"Never exposes anything beyond last 4 digits: {masked == '•••• •••• •••• 9012'}")

    print()
    print("=== TEST 4: Revoke a token (card reported lost/stolen) ===")
    service.revoke(token_a, reason="Card reported stolen", performed_by="fraud-ops-team")
    print(f"Token status after revocation: {service._tokens[token_a].status.value}")

    print()
    print("=== TEST 5: A REVOKED token cannot be reused for a new transaction ===")
    try:
        service.get_or_create_persistent_token(real_pan, performed_by="payment-service")
        print("FAIL - a revoked card's token was reused")
    except TokenRevokedError as e:
        print(f"Correctly refused: {e}")

    print()
    print("=== TEST 6: check_usable() correctly reflects revocation - what card-service's authorize() would check ===")
    print(f"Token usable: {service.check_usable(token_a)} (expected: False - directly gates the")
    print(f"card-authorization-service.authorize() from earlier today, preventing a revoked card")
    print(f"from ever placing a new hold)")

    print()
    print("=== TEST 7: Suspend (reversible) is different from revoke (permanent) ===")
    other_pan = "5412345678901234"
    other_token = service.get_or_create_persistent_token(other_pan, performed_by="card-service")
    service.suspend(other_token, reason="Unusual activity under review", performed_by="fraud-ops-team")
    print(f"After suspend, usable: {service.check_usable(other_token)} (expected: False)")
    service.reactivate(other_token, performed_by="fraud-ops-team")
    print(f"After reactivate, usable: {service.check_usable(other_token)} (expected: True - suspend is reversible)")

    print()
    print("=== TEST 8: A REVOKED token can NEVER be reactivated, even by mistake ===")
    try:
        service.reactivate(token_a, performed_by="someone-making-a-mistake")
        print("FAIL - a revoked token was reactivated")
    except ValueError as e:
        print(f"Correctly refused: {e}")

    print()
    print("=== TEST 9: Full lifecycle audit trail exists for the revoked card ===")
    for event in service._lifecycle_log:
        if event["token"] == token_a:
            print(f"  {event['action']} by {event['performed_by']} at {event['at'].strftime('%H:%M:%S')} "
                  f"- reason: {event['reason']}")
