# Token Lifecycle Management — Design Package

## Direct answers to the questions asked

### "Are we handling tokens properly? Add, delete, modify, and pass between services?"

**Partially, before this package — and worth being honest about exactly what was missing.** The security-design package built real envelope encryption and a *single* tokenization mode: a fresh token every call, deliberately, for privacy. That's correct for wallet/point-of-sale transactions, but genuinely wrong for stored-card and recurring-billing scenarios, which need the *same* token to represent one card across its whole lifetime. This package adds that missing mode, plus full lifecycle: create, suspend (reversible), revoke (permanent), reactivate — each one audited.

### "How does it pass from one service to another?"

**Test 1 is the direct proof.** Three independent calls — from `card-service`, `payment-service`, `settlement-service` — for the *same* PAN, using `get_or_create_persistent_token()`, all return the identical token. This works via a genuine HMAC-based lookup (`PERSISTENT_TOKEN_LOOKUP`), not by re-tokenizing at every hop — re-tokenizing at each service boundary would silently create multiple unrelated tokens for one real card, breaking every correlation built throughout today's session.

### "How do we see the tokenized PAN, for verification?"

**The honest answer: you almost never actually need to.** `get_masked_view()` returns `•••• •••• •••• 9012` using only the `PAN_LAST_FOUR` column already present in the original `TOKEN_VAULT` DDL — it never touches `ENCRYPTED_PAN`, never calls `detokenize()`, and therefore never triggers the strict default-deny access control gate from the security-design package at all. For the overwhelming majority of real "verification" needs — a customer service agent confirming the right card, a statement showing which card was used — the last four digits are sufficient and were never sensitive on their own. Full detokenization remains locked behind `TokenAccessControlService`, exactly as before, for the narrow cases (card network authorization, SWIFT settlement) that genuinely require it.

## Files

```
ddl/token_lifecycle_ddl.sql              - extends TOKEN_VAULT, adds PERSISTENT_TOKEN_LOOKUP, TOKEN_LIFECYCLE_LOG
service/token_lifecycle_service.py       - tested against 9 real scenarios
```

## Verified, working — 9 real scenarios

1. **Cross-service propagation** — the same token returned identically to three different calling services
2. **Dynamic mode preserved exactly** — the original correlation-prevention behavior still works, unchanged
3. **Safe masked view** — verification without ever touching the real PAN
4. **Revocation** — a lost/stolen card's token is permanently invalidated
5. **A revoked token cannot be reused for a new transaction** — checked directly at the point of tokenization
6. **`check_usable()`** — the exact gate `card-authorization-service.authorize()` from earlier today would call before placing any new hold
7. **Suspend vs. revoke, genuinely different** — suspension (fraud under investigation) is reversible; revocation (confirmed lost/stolen) is not
8. **A revoked token can never be reactivated**, even by an operational mistake — enforced in code, not policy
9. **Complete audit trail** — every lifecycle event, who performed it, when, and why

## Why HMAC, specifically, for the persistent lookup — not a plain hash

A PAN is only 13-19 digits — a genuinely small space to brute-force against an unkeyed hash (a rainbow-table-style attack becomes realistic). A **keyed** HMAC closes that specific weakness: without the secret key (which, per the same principle as the security-design package's KEK, lives in HSM/KMS, never in application code), the lookup table alone reveals nothing about the underlying PANs.

## How this ties into card-service from earlier today

`card_authorization_service.py`'s `authorize()` method should call `check_usable(card_token)` as its very first check, before even evaluating available credit — a revoked card must never reach the fraud-check or credit-check stage at all. This is a genuine follow-up wiring task, not yet done in this package, worth doing before either service is considered complete.
