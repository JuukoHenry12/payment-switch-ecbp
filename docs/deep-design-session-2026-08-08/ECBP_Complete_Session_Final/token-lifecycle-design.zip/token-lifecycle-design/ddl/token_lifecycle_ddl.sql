-- ============================================================
-- ECBP Token Lifecycle Management — DDL
-- Extends TOKEN_VAULT (security-design package, this afternoon)
-- ============================================================
-- The gap this closes: the original TOKEN_VAULT only supported
-- ONE mode - a fresh token every single call, by design, for
-- privacy (preventing cross-transaction correlation). That is
-- CORRECT for wallet/point-of-sale dynamic tokenization, but WRONG
-- for stored-card and recurring-billing use cases, which genuinely
-- require the SAME token to represent one card across its entire
-- lifetime. Real financial systems need both modes, not one.
-- ============================================================

-- Add lifecycle status and a token-type distinction to the existing
-- TOKEN_VAULT table from the security-design package.
ALTER TABLE TOKEN_VAULT
    ADD COLUMN TOKEN_TYPE VARCHAR(20) NOT NULL DEFAULT 'DYNAMIC',  -- DYNAMIC or PERSISTENT
    ADD COLUMN STATUS VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',        -- ACTIVE, SUSPENDED, REVOKED
    ADD COLUMN REVOKED_AT TIMESTAMPTZ NULL,
    ADD COLUMN REVOKED_REASON VARCHAR(100) NULL;

-- ------------------------------------------------------------
-- PERSISTENT_TOKEN_LOOKUP — the mechanism that makes "same PAN
-- always resolves to the same token" possible, WITHOUT storing the
-- PAN in a searchable form anywhere. Uses a keyed HMAC of the PAN
-- as the lookup key, not the PAN itself and not a reversible
-- encryption - this is deliberately a one-way lookup structure,
-- searchable but never decryptable back to the PAN from this table
-- alone.
-- ------------------------------------------------------------
CREATE TABLE PERSISTENT_TOKEN_LOOKUP (
    PAN_LOOKUP_HASH          VARCHAR(64)    PRIMARY KEY,   -- HMAC-SHA256(PAN), hex-encoded
    TOKEN                       VARCHAR(19) NOT NULL REFERENCES TOKEN_VAULT(TOKEN),
    CREATED_AT                    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- TOKEN_LIFECYCLE_LOG — every CREATE, SUSPEND, REACTIVATE, REVOKE
-- action, who did it and why. A card being reported lost/stolen and
-- its token being revoked is a genuinely significant, auditable
-- event, not a silent database update.
-- ------------------------------------------------------------
CREATE TABLE TOKEN_LIFECYCLE_LOG (
    LIFECYCLE_EVENT_ID       UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    TOKEN                       VARCHAR(19)  NOT NULL,
    ACTION                        VARCHAR(20) NOT NULL,  -- CREATED, SUSPENDED, REACTIVATED, REVOKED
    REASON                          VARCHAR(100) NULL,
    PERFORMED_BY                       VARCHAR(50) NOT NULL,
    PERFORMED_AT                         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_LIFECYCLE_TOKEN ON TOKEN_LIFECYCLE_LOG (TOKEN, PERFORMED_AT);

-- ------------------------------------------------------------
-- The safe "see the card" mechanism, made explicit: TOKEN_VAULT
-- already has PAN_LAST_FOUR from the original security-design
-- package. A masked view (e.g. "•••• •••• •••• 9012") is built
-- ENTIRELY from this column - it never touches ENCRYPTED_PAN, never
-- calls detokenize(), and therefore never triggers the strict
-- default-deny TokenAccessControlService gate at all. This is the
-- actual answer to "how do we see the tokenized PAN for
-- verification" - the honest answer is: for verification purposes,
-- you almost never need the real PAN at all, only the last 4 digits,
-- which were never sensitive on their own.
-- ------------------------------------------------------------
