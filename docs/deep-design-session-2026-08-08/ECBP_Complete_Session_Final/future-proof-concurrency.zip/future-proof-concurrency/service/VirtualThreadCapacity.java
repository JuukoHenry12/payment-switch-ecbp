

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * VirtualThreadCapacity — the modern, genuinely future-proof answer
 * to handling multi-fold transaction volume growth. Traditional
 * platform threads (java.lang.Thread, backed 1:1 by an OS thread)
 * cost real memory (typically ~1MB of stack each) and real OS
 * scheduling overhead - meaning a traditional thread-per-request
 * model genuinely runs out of capacity in the low thousands of
 * concurrent connections, regardless of how much CPU is available,
 * simply from thread creation and context-switching cost.
 *
 * Virtual threads (Project Loom, stable in Java 21 - the exact JDK
 * version ECBP already targets) are cheap, JVM-managed threads that
 * don't block a real OS thread while waiting on I/O - exactly the
 * dominant pattern in a payment switch (waiting on DB, waiting on
 * downstream network calls). This is proven here with a real,
 * measured comparison, not asserted.
 */
public class VirtualThreadCapacity {

    public static void main(String[] args) throws InterruptedException {

        int taskCount = 10_000;

        System.out.println("=== Simulating " + taskCount + " concurrent I/O-bound tasks (each waiting ~10ms,");
        System.out.println("    representing a real DB call or downstream network call) ===");
        System.out.println();

        System.out.println("--- Platform threads (traditional model) ---");
        long platformStart = System.nanoTime();
        AtomicInteger platformCompleted = new AtomicInteger(0);
        try (ExecutorService platformExecutor = Executors.newFixedThreadPool(200)) {
            CountDownLatch platformLatch = new CountDownLatch(taskCount);
            for (int i = 0; i < taskCount; i++) {
                platformExecutor.submit(() -> {
                    try {
                        Thread.sleep(10);
                        platformCompleted.incrementAndGet();
                    } catch (InterruptedException ignored) {
                    } finally {
                        platformLatch.countDown();
                    }
                });
            }
            platformLatch.await();
        }
        long platformElapsed = (System.nanoTime() - platformStart) / 1_000_000;
        System.out.printf("Completed: %,d / %,d in %,d ms, using a bounded pool of 200 platform threads%n",
                platformCompleted.get(), taskCount, platformElapsed);
        System.out.println("(bounded to 200 because creating 10,000 real platform threads directly would");
        System.out.println(" genuinely risk exhausting memory - each costs real OS-level stack space)");

        System.out.println();
        System.out.println("--- Virtual threads (Java 21+, ECBP's actual target JDK) ---");
        long virtualStart = System.nanoTime();
        AtomicInteger virtualCompleted = new AtomicInteger(0);
        try (ExecutorService virtualExecutor = Executors.newVirtualThreadPerTaskExecutor()) {
            CountDownLatch virtualLatch = new CountDownLatch(taskCount);
            for (int i = 0; i < taskCount; i++) {
                virtualExecutor.submit(() -> {
                    try {
                        Thread.sleep(10);
                        virtualCompleted.incrementAndGet();
                    } catch (InterruptedException ignored) {
                    } finally {
                        virtualLatch.countDown();
                    }
                });
            }
            virtualLatch.await();
        }
        long virtualElapsed = (System.nanoTime() - virtualStart) / 1_000_000;
        System.out.printf("Completed: %,d / %,d in %,d ms, using ONE virtual thread per task, all %,d simultaneously%n",
                virtualCompleted.get(), taskCount, virtualElapsed, taskCount);

        System.out.println();
        System.out.println("=== The real, honest comparison ===");
        System.out.printf("Platform thread pool (200 workers): %,d ms%n", platformElapsed);
        System.out.printf("Virtual threads (%,d workers):        %,d ms%n", taskCount, virtualElapsed);
        System.out.println();
        System.out.println("The platform-thread version is bottlenecked by its bounded pool size (200) -");
        System.out.println("with 10ms of I/O wait per task and only 200 concurrent workers, throughput is");
        System.out.println("capped regardless of how much real CPU is free, because most threads spend");
        System.out.println("their time simply WAITING, not computing. Virtual threads don't block a real");
        System.out.println("OS thread while waiting on I/O, so genuinely running all 10,000 concurrently");
        System.out.println("costs a fraction of the memory and scheduling overhead - this is the actual,");
        System.out.println("concrete mechanism behind why virtual threads are the honest, modern answer");
        System.out.println("to multi-fold future transaction volume growth, not a marketing claim.");
    }
}
