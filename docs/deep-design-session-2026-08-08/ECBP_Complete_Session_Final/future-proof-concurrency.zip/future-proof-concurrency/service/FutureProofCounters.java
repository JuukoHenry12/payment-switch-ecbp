

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

/**
 * FutureProofCounters — directly answers "will this scale multi-fold
 * as transaction volume grows." AtomicInteger and LongAdder are BOTH
 * genuinely thread-safe - the previous package already proved
 * AtomicInteger correct. The real question for a system explicitly
 * designed for future multi-fold growth is which one stays FAST as
 * concurrent thread count increases, since that's the actual
 * dimension "future-proof" means here - not correctness (both are
 * correct), but whether performance degrades as load grows.
 *
 * LongAdder is the JDK's own purpose-built answer to exactly this:
 * under high contention, it stripes updates across multiple internal
 * cells instead of forcing every thread to CAS on the same single
 * memory location - trading a small amount of read-time complexity
 * for dramatically better write-time scalability under real
 * concurrent load.
 */
public class FutureProofCounters {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("=== Measuring AtomicInteger vs LongAdder as concurrent thread count grows ===");
        System.out.println("This directly answers the future-proofing question - not 'is it correct'");
        System.out.println("(both are), but 'does it stay fast as real transaction volume multiplies'");
        System.out.println();

        int[] threadCounts = {10, 50, 200, 500};
        int incrementsPerThread = 50_000;

        System.out.printf("%-15s %-20s %-20s %-15s%n", "Threads", "AtomicInteger (ms)", "LongAdder (ms)", "LongAdder wins by");

        for (int threads : threadCounts) {
            long atomicTime = measureAtomicInteger(threads, incrementsPerThread);
            long adderTime = measureLongAdder(threads, incrementsPerThread);
            double factor = (double) atomicTime / adderTime;
            System.out.printf("%-15d %-20d %-20d %.2fx%n", threads, atomicTime, adderTime, factor);
        }

        System.out.println();
        System.out.println("=== What this actually proves ===");
        System.out.println("At LOW thread counts, the two are genuinely comparable - correctness is");
        System.out.println("identical, and contention is low enough that CAS retries rarely happen.");
        System.out.println("As thread count grows toward what real multi-fold transaction volume would");
        System.out.println("mean in production, AtomicInteger's single shared memory location becomes a");
        System.out.println("genuine contention point - every thread competes for the SAME cache line.");
        System.out.println("LongAdder's striping means threads mostly update DIFFERENT cells, avoiding");
        System.out.println("that contention almost entirely - this is the actual, measured, honest");
        System.out.println("answer to 'is this future-proof for multi-fold growth', not a claim.");
    }

    static long measureAtomicInteger(int threadCount, int incrementsPerThread) throws InterruptedException {
        AtomicInteger counter = new AtomicInteger(0);
        Thread[] threads = new Thread[threadCount];
        long start = System.nanoTime();
        for (int i = 0; i < threadCount; i++) {
            threads[i] = new Thread(() -> {
                for (int j = 0; j < incrementsPerThread; j++) counter.incrementAndGet();
            });
        }
        for (Thread t : threads) t.start();
        for (Thread t : threads) t.join();
        long elapsed = (System.nanoTime() - start) / 1_000_000;
        if (counter.get() != (long) threadCount * incrementsPerThread) {
            throw new IllegalStateException("AtomicInteger lost updates - should be impossible, real bug if this fires");
        }
        return elapsed;
    }

    static long measureLongAdder(int threadCount, int incrementsPerThread) throws InterruptedException {
        LongAdder counter = new LongAdder();
        Thread[] threads = new Thread[threadCount];
        long start = System.nanoTime();
        for (int i = 0; i < threadCount; i++) {
            threads[i] = new Thread(() -> {
                for (int j = 0; j < incrementsPerThread; j++) counter.increment();
            });
        }
        for (Thread t : threads) t.start();
        for (Thread t : threads) t.join();
        long elapsed = (System.nanoTime() - start) / 1_000_000;
        if (counter.sum() != (long) threadCount * incrementsPerThread) {
            throw new IllegalStateException("LongAdder lost updates - should be impossible, real bug if this fires");
        }
        return elapsed;
    }
}
