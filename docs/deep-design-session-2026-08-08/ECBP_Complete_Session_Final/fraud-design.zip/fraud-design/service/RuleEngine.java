package com.balasubramani.ecbp.risk.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * RuleEngine — evaluates FRAUD_RULE rows (configuration, not code)
 * against a transaction's computed features. Adding a new rule, or
 * changing a threshold, is a data change via the FRAUD_RULE table -
 * genuinely no code deployment required, which is the entire point
 * of the "plugin-style rule engine" principle from the enterprise
 * architecture document.
 *
 * Rules are evaluated in PRIORITY order, and evaluation stops at the
 * first BLOCK-triggering rule (fail fast on the most severe outcome) -
 * there's no value in continuing to evaluate lower-priority rules
 * once a hard block condition is already found.
 */
public class RuleEngine {

    private final RuleRepository ruleRepository;

    public RuleEngine(RuleRepository ruleRepository) {
        this.ruleRepository = ruleRepository;
    }

    public RuleEvaluationResult evaluate(TransactionFeatures features) {

        List<FraudRule> activeRules = ruleRepository.getActiveRulesByPriority();

        for (FraudRule rule : activeRules) {
            Optional<RuleTrigger> trigger = evaluateSingleRule(rule, features);

            if (trigger.isPresent()) {
                RuleTrigger t = trigger.get();
                if (t.action() == FraudAction.BLOCK) {
                    // Fail fast - no point evaluating further once a
                    // hard block condition is found.
                    return RuleEvaluationResult.triggered(rule, t.action());
                }
                // FLAG_FOR_REVIEW or ALLOW_WITH_MONITORING - keep
                // evaluating remaining rules, since a later rule
                // could still escalate to BLOCK.
                return RuleEvaluationResult.triggered(rule, t.action());
            }
        }

        return RuleEvaluationResult.noTrigger();
    }

    private Optional<RuleTrigger> evaluateSingleRule(FraudRule rule, TransactionFeatures features) {
        return switch (rule.ruleType()) {
            case VELOCITY -> evaluateVelocity(rule, features);
            case AMOUNT_THRESHOLD -> evaluateAmountThreshold(rule, features);
            case GEO_ANOMALY -> evaluateGeoAnomaly(rule, features);
            case BLACKLIST -> evaluateBlacklist(rule, features);
        };
    }

    private Optional<RuleTrigger> evaluateVelocity(FraudRule rule, TransactionFeatures features) {
        int maxCount = rule.parameters().getInt("max_count");
        if (features.txnCount5Min() > maxCount) {
            return Optional.of(new RuleTrigger(rule.action()));
        }
        return Optional.empty();
    }

    private Optional<RuleTrigger> evaluateAmountThreshold(FraudRule rule, TransactionFeatures features) {
        BigDecimal maxAmount = rule.parameters().getDecimal("max_amount");
        if (features.transactionAmount().compareTo(maxAmount) > 0) {
            return Optional.of(new RuleTrigger(rule.action()));
        }
        return Optional.empty();
    }

    private Optional<RuleTrigger> evaluateGeoAnomaly(FraudRule rule, TransactionFeatures features) {
        double maxSpeed = rule.parameters().getDouble("max_distance_km_per_hour");
        if (features.impliedTravelSpeedKmh() > maxSpeed) {
            return Optional.of(new RuleTrigger(rule.action()));
        }
        return Optional.empty();
    }

    private Optional<RuleTrigger> evaluateBlacklist(FraudRule rule, TransactionFeatures features) {
        if (features.isOnBlacklist()) {
            return Optional.of(new RuleTrigger(rule.action()));
        }
        return Optional.empty();
    }

    // --- Supporting types ---

    public enum RuleType { VELOCITY, AMOUNT_THRESHOLD, GEO_ANOMALY, BLACKLIST }
    public enum FraudAction { BLOCK, FLAG_FOR_REVIEW, ALLOW_WITH_MONITORING }

    public record RuleParameters(Map<String, Object> values) {
        public int getInt(String key) { return ((Number) values.get(key)).intValue(); }
        public double getDouble(String key) { return ((Number) values.get(key)).doubleValue(); }
        public BigDecimal getDecimal(String key) { return new BigDecimal(values.get(key).toString()); }
    }

    public record FraudRule(String ruleId, RuleType ruleType, RuleParameters parameters, FraudAction action, int priority) {}

    public record TransactionFeatures(
            String txnId, BigDecimal transactionAmount, int txnCount5Min,
            double impliedTravelSpeedKmh, boolean isOnBlacklist) {}

    private record RuleTrigger(FraudAction action) {}

    public record RuleEvaluationResult(boolean triggered, Optional<FraudRule> rule, Optional<FraudAction> action) {
        public static RuleEvaluationResult noTrigger() {
            return new RuleEvaluationResult(false, Optional.empty(), Optional.empty());
        }
        public static RuleEvaluationResult triggered(FraudRule rule, FraudAction action) {
            return new RuleEvaluationResult(true, Optional.of(rule), Optional.of(action));
        }
    }

    public interface RuleRepository {
        List<FraudRule> getActiveRulesByPriority();
    }
}
