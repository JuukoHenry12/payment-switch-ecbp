-- ============================================================
-- ECBP Fraud Detection — Rules Engine & Feature Store DDL
-- ============================================================
-- Design decision, stated explicitly: rules are DATA, not code.
-- A risk analyst should be able to add or adjust a velocity/amount
-- threshold rule via configuration, without a code deployment. This
-- is exactly the "plugin-style rule engine" principle from the
-- enterprise architecture document, made concrete here.
-- ============================================================

CREATE TABLE FRAUD_RULE (
    RULE_ID              VARCHAR(50)     PRIMARY KEY,
    RULE_NAME            VARCHAR(100)    NOT NULL,
    RULE_TYPE            VARCHAR(30)     NOT NULL,  -- VELOCITY, AMOUNT_THRESHOLD, GEO_ANOMALY, BLACKLIST
    IS_ACTIVE            BOOLEAN         NOT NULL DEFAULT true,
    -- The actual rule logic, expressed as configuration, not code.
    -- e.g. for VELOCITY: {"window_seconds": 300, "max_count": 5}
    -- e.g. for AMOUNT_THRESHOLD: {"max_amount": 5000.00}
    RULE_PARAMETERS       JSONB           NOT NULL,
    ACTION_ON_TRIGGER      VARCHAR(30)    NOT NULL,  -- BLOCK, FLAG_FOR_REVIEW, ALLOW_WITH_MONITORING
    PRIORITY               SMALLINT       NOT NULL DEFAULT 5,  -- evaluation order, lower = evaluated first
    CREATED_AT              TIMESTAMPTZ    NOT NULL DEFAULT now(),
    UPDATED_AT              TIMESTAMPTZ    NOT NULL DEFAULT now(),
    UPDATED_BY              VARCHAR(50)    NOT NULL   -- audit trail for who changed a fraud rule - genuinely important
);

-- Sample rules - exactly the kind a risk analyst would configure,
-- not a developer deploying code
INSERT INTO FRAUD_RULE (RULE_ID, RULE_NAME, RULE_TYPE, RULE_PARAMETERS, ACTION_ON_TRIGGER, PRIORITY, UPDATED_BY)
VALUES
    ('RULE-VEL-001', 'High velocity - 5+ txns in 5 min', 'VELOCITY',
     '{"window_seconds": 300, "max_count": 5}', 'FLAG_FOR_REVIEW', 1, 'system'),
    ('RULE-AMT-001', 'Single transaction over $5000', 'AMOUNT_THRESHOLD',
     '{"max_amount": 5000.00}', 'FLAG_FOR_REVIEW', 2, 'system'),
    ('RULE-AMT-002', 'Single transaction over $20000', 'AMOUNT_THRESHOLD',
     '{"max_amount": 20000.00}', 'BLOCK', 1, 'system'),
    ('RULE-GEO-001', 'Transaction location inconsistent with prior activity', 'GEO_ANOMALY',
     '{"max_distance_km_per_hour": 800}', 'FLAG_FOR_REVIEW', 3, 'system'),
    ('RULE-BLK-001', 'Account or counterparty on blacklist', 'BLACKLIST',
     '{"list_name": "SANCTIONS_LIST"}', 'BLOCK', 0, 'system');

-- ------------------------------------------------------------
-- FEATURE_DEFINITION — what features the ML model and rules
-- engine both draw from, defined once, computed once, shared.
-- ------------------------------------------------------------
CREATE TABLE FEATURE_DEFINITION (
    FEATURE_NAME          VARCHAR(50)     PRIMARY KEY,
    DESCRIPTION           TEXT            NOT NULL,
    COMPUTATION_WINDOW     VARCHAR(20)    NOT NULL,  -- e.g. "5_MIN", "24_HOUR", "30_DAY"
    IS_ACTIVE              BOOLEAN        NOT NULL DEFAULT true
);

INSERT INTO FEATURE_DEFINITION (FEATURE_NAME, DESCRIPTION, COMPUTATION_WINDOW) VALUES
    ('txn_count_5min', 'Number of transactions by this account in the last 5 minutes', '5_MIN'),
    ('avg_amount_30day', 'Average transaction amount for this account over 30 days', '30_DAY'),
    ('stddev_amount_30day', 'Standard deviation of transaction amount over 30 days', '30_DAY'),
    ('distinct_merchants_24h', 'Distinct merchant categories transacted with in 24 hours', '24_HOUR'),
    ('hour_of_day', 'Hour of day the transaction occurred (0-23)', 'N/A'),
    ('is_new_payee', 'Whether this is the first transaction to this specific payee', 'N/A');

-- ------------------------------------------------------------
-- FRAUD_DECISION_LOG — every decision (rule or ML) is logged,
-- not just the ones that trigger. This is what lets you later
-- measure false-positive rates and tune thresholds with real
-- data, not guesswork.
-- ------------------------------------------------------------
CREATE TABLE FRAUD_DECISION_LOG (
    DECISION_ID           UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_ID                UUID            NOT NULL,
    DETECTION_METHOD       VARCHAR(20)    NOT NULL,  -- RULE_ENGINE, ML_ANOMALY
    RULE_ID                VARCHAR(50)    NULL,       -- populated if RULE_ENGINE
    ANOMALY_SCORE            DOUBLE PRECISION NULL,   -- populated if ML_ANOMALY
    ACTION_TAKEN              VARCHAR(30)  NOT NULL,  -- ALLOW, FLAG_FOR_REVIEW, BLOCK
    LATENCY_MS                 INTEGER     NOT NULL,  -- how long this decision took - the hard budget being measured
    DECIDED_AT                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_FRAUD_DECISION_TXN ON FRAUD_DECISION_LOG (TXN_ID);
CREATE INDEX IDX_FRAUD_DECISION_LATENCY ON FRAUD_DECISION_LOG (LATENCY_MS);
-- The latency index specifically supports the operational question
-- "are we still inside our authorization latency budget on average
-- and at p99" - a genuinely important ongoing monitoring query.
