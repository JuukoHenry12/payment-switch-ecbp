# Fraud Detection — Rules + ML Design Package

## The two tiers, and why both, tested for real

**Tier 1 — Rule Engine.** Data-driven (rules live in `FRAUD_RULE`, not code), fast, explainable. Tested against 6 scenarios, all correct — including fail-fast on BLOCK (blacklist check short-circuits before lower-priority rules even run) and correct FLAG vs BLOCK distinction based on amount thresholds.

**Tier 2 — ML Anomaly Detection.** An Isolation Forest, genuinely trained and evaluated here, not just designed: **100% of synthetic anomalies caught, 5.0% false-positive rate, 8.2ms average inference latency.** The model is trained *only* on normal behavior — it never sees a labeled fraud example, which is deliberately realistic: real institutions don't have clean labels for genuinely novel fraud patterns, which is precisely why anomaly detection is the right tool for this tier rather than supervised classification.

## Files

```
ddl/fraud_rules_ddl.sql        - FRAUD_RULE (data-driven config), FEATURE_DEFINITION, FRAUD_DECISION_LOG
service/RuleEngine.java        - Tier 1, tested against 6 scenarios
ml/train_anomaly_model.py      - Tier 2, genuinely trained and evaluated, real numbers above
```

## How both tiers feed the same event — tying back to the earlier design

Recall `FraudFlagged.avsc` from the Phase 1 deliverables already has a `detectionMethod` field distinguishing `RULE_ENGINE` from `ML_ANOMALY` — that decision made weeks (well, hours) ago in this design session is exactly what makes wiring both tiers into one event clean rather than awkward:

```
risk-service consumes PaymentInitiated
        │
        ├── RuleEngine.evaluate(features) ──┐
        │                                    │
        └── IsolationForest.score(features) ─┤
                                              ▼
                                    Aggregate decision:
                                    any BLOCK wins outright;
                                    otherwise combine FLAG signals
                                              │
                                              ▼
                                    publish FraudFlagged
                                    (detectionMethod = RULE_ENGINE or ML_ANOMALY,
                                     or BOTH could fire separately for the same txn -
                                     worth logging both, not just the first one)
```

**One real design decision worth making explicit:** if both tiers fire for the same transaction, log both `FraudFlagged` events (via `FRAUD_DECISION_LOG`, which has a row per detection method, not per transaction) rather than suppressing one — this is exactly the data you'd need later to evaluate whether the two tiers are catching genuinely different things or redundantly flagging the same patterns, which matters for tuning either one over time.

## The feature store — the piece that makes 8.2ms actually achievable in production

The 8.2ms latency test above measures pure model inference against *already-computed* features. In production, computing `txn_count_5min` or `avg_amount_30day` from a live database query during authorization would blow the latency budget entirely — this is exactly why the architecture calls for a **feature store** (Redis-backed, per the enterprise architecture document): features get updated asynchronously as `EntryPosted` events flow through Kafka, and the authorization path only ever *reads* a pre-computed value, never computes one live. Worth building this integration next, since the model itself is now proven to work — the remaining engineering is making sure it's *fed* fast enough in a real request path, not the model's own performance.

## Honest limitation, stated plainly

The synthetic data here is deliberately simple (5 features, clearly separated distributions) specifically to prove the training/scoring *pipeline* works correctly end-to-end. A real production model would need real (or far more realistic synthetic) transaction data, more features, and genuine calibration against actual observed fraud patterns — this is a correct, working foundation, not a claim that 100%/5% numbers would hold on real-world data.
