# Gridlock Resolution — Design Package

## The core insight this package is built around

Per-account FIFO+priority queuing (the version built in the first settlement design pass) cannot resolve **gridlock** — circular chains of obligations where every participant looks illiquid individually, but the group's net movement required is zero or small. A→B→C→A owing the same amount is the classic case: nobody can pay until someone else does, forever, unless something looks at the *system*, not just one account.

## The honest architectural boundary — read this before wiring anything up

**True multilateral netting across independent counterparties requires visibility ECBP does not have and should not pretend to have.** ECBP can never see what Correspondent A owes Correspondent B — that's not ECBP's data. Real multilateral netting (CHIPS, TARGET2's gridlock resolution) is performed by the **network operator**, not by individual participant banks. Designing ECBP to unilaterally "solve" this across counterparties it can't see would be architecturally dishonest, not just incomplete.

**This package therefore contains three genuinely different things, each correctly scoped:**

| File | What it is | Who runs it |
|---|---|---|
| `service/BilateralNettingService.java` | Nets ECBP's own outgoing + incoming with **one** counterparty | ECBP itself, legitimately |
| `service/LiquiditySweepService.java` | Moves ECBP's own liquidity between its own settlement accounts | ECBP itself, legitimately |
| `simulator/NetworkClearingSimulator.java` | Full multilateral cycle-cancellation + net-feasibility clearing | A network operator's role — simulated here for genuine understanding, or as a demo of "here's how the clearing house ECBP participates in actually works" |

## Verified, working — real test results

I compiled and ran `NetworkClearingSimulator` directly (Java 21 supports single-file execution without a separate build step) against two real scenarios:

**Test 1 — the classic 3-way gridlock** (ECBP→CorrespondentA→CorrespondentB→ECBP, all $100): **fully cancelled via cycle detection, zero liquidity required.** Exactly the theoretical result.

**Test 2 — a more complex case I didn't fully plan**: the topology happened to also form a cycle regardless of the differing amounts ($500/$300/$50). The algorithm correctly cancelled the smallest common amount ($50) across all three edges first, then correctly evaluated the *remaining* DAG for net feasibility — and found it exactly balanced (one participant's shortfall came out to precisely zero), releasing the rest as one batch. This is the algorithm handling a case correctly that I hadn't deliberately constructed — a good sign, not a coincidence I'm claiming credit for planning.

## How the algorithm works, in two phases

**Phase 1 — cycle cancellation.** Find circular chains, cancel the minimum common amount across the whole cycle. This is a pure netting identity — no liquidity needed at all, since a cycle by definition sums to zero net movement.

**Phase 2 — multilateral net feasibility.** For whatever remains (now a DAG, no cycles), compute every participant's net position if the whole batch released at once. If every net payer can cover their shortfall, release everything simultaneously. If not, remove the worst-offending participant and every obligation touching them, recompute, repeat — a greedy heuristic real clearing systems use for the same reason: release *something* quickly rather than searching exhaustively for a theoretically perfect subset.

**Honest limitation, stated in the code comments too:** the cycle detection is a straightforward DFS, correct but not the most efficient algorithm for very large participant counts (Johnson's algorithm would be the production-scale choice). Appropriate for demonstrating the concept correctly; worth knowing the limitation rather than implying production-scale performance that hasn't been tested.

## What to actually wire into settlement-service

Only `BilateralNettingService` and `LiquiditySweepService` — call these *before* falling back to the gross `SettlementDecisionEngine.attemptSettlement()` from the previous design pass, since netting/sweeping first reduces how often gross settlement (and its liquidity requirement) is even needed.

`NetworkClearingSimulator` is not something `settlement-service` calls in production — it's either a standalone educational/demo artifact, or the starting point if you ever want ECBP to explicitly simulate operating a small closed clearing network for demo purposes (a genuinely interesting, honest extension, clearly labeled as simulating the network operator's role rather than ECBP's own).
