package com.balasubramani.ecbp.settlement.simulator;

import java.math.BigDecimal;
import java.util.*;

/**
 * NetworkClearingSimulator — implements what a NETWORK OPERATOR does
 * (a CHIPS-style multilateral netting system, or an RTGS operator's
 * gridlock-resolution engine), not something ECBP itself runs against
 * external counterparties in production, since that requires global
 * visibility ECBP as a single participant bank does not have.
 *
 * This exists for two legitimate reasons:
 *   1. Genuine understanding - implementing this is the clearest way
 *      to actually know how CHIPS/RTGS gridlock resolution works,
 *      rather than describing it abstractly.
 *   2. A real, honest extension point - if you want ECBP to
 *      demonstrate simulating a small closed network of counterparty
 *      banks (e.g. for a demo showing "here's how the clearing house
 *      ECBP participates in actually resolves gridlock"), this class
 *      IS that clearing house's logic, run as its own bounded
 *      simulation, clearly separated from ECBP-the-participant-bank's
 *      own code (BilateralNettingService, LiquiditySweepService).
 *
 * The algorithm, in two phases:
 *
 *   PHASE 1 - Cycle cancellation (always safe, zero liquidity needed)
 *     Find circular chains of obligations (A owes B, B owes C, C owes
 *     A) and cancel out the common amount across the whole cycle.
 *     This requires no liquidity from anyone - it's a pure netting
 *     identity, not a settlement.
 *
 *   PHASE 2 - Multilateral net feasibility batch release
 *     For whatever obligations remain after cycle cancellation
 *     (now a DAG, no cycles), compute each participant's NET position
 *     if the whole remaining batch settled simultaneously. If every
 *     net payer has enough liquidity to cover their net shortfall,
 *     release the entire batch at once. If not, iteratively remove
 *     the participant with the worst infeasible net position and
 *     recompute, until the remaining subset is feasible. This
 *     maximizes the value released in one pass rather than settling
 *     nothing just because one participant is short.
 */
public class NetworkClearingSimulator {

    public record Obligation(String fromParticipant, String toParticipant, BigDecimal amount) {}
    public record ClearingResult(
            List<Obligation> cycleCancel,
            List<Obligation> released,
            List<Obligation> stillQueued,
            Map<String, BigDecimal> netPositions) {}

    /**
     * Run one full clearing cycle. In a real network operator, this
     * runs periodically (e.g. every few seconds) against whatever is
     * currently queued.
     */
    public ClearingResult runClearingCycle(
            List<Obligation> queuedObligations,
            Map<String, BigDecimal> availableLiquidityByParticipant) {

        // --- PHASE 1: cycle cancellation ---
        List<Obligation> remaining = new ArrayList<>(queuedObligations);
        List<Obligation> cancelled = new ArrayList<>();

        boolean foundCycle = true;
        while (foundCycle) {
            Optional<List<Obligation>> cycle = findCycle(remaining);
            if (cycle.isEmpty()) {
                foundCycle = false;
                continue;
            }
            List<Obligation> cyclePath = cycle.get();
            BigDecimal minAmount = cyclePath.stream()
                    .map(Obligation::amount)
                    .min(Comparator.naturalOrder())
                    .orElseThrow();

            List<Obligation> updated = new ArrayList<>();
            for (Obligation o : remaining) {
                if (cyclePath.contains(o)) {
                    BigDecimal newAmount = o.amount().subtract(minAmount);
                    cancelled.add(new Obligation(o.fromParticipant(), o.toParticipant(), minAmount));
                    if (newAmount.signum() > 0) {
                        updated.add(new Obligation(o.fromParticipant(), o.toParticipant(), newAmount));
                    }
                } else {
                    updated.add(o);
                }
            }
            remaining = updated;
        }

        // --- PHASE 2: multilateral net feasibility ---
        List<Obligation> candidateSet = new ArrayList<>(remaining);
        Map<String, BigDecimal> netPositions;

        while (true) {
            netPositions = computeNetPositions(candidateSet);

            Optional<String> worstOffender = findWorstInfeasibleParticipant(
                    netPositions, availableLiquidityByParticipant);

            if (worstOffender.isEmpty()) {
                // Every net payer can cover their net shortfall -
                // this candidate set is feasible, release it entirely.
                break;
            }

            // Remove every obligation touching the worst offender and
            // try again. This is a greedy heuristic - not guaranteed
            // globally optimal (true optimal subset selection is
            // combinatorially expensive), but it's the same practical
            // tradeoff real clearing systems make: release SOMETHING
            // quickly rather than searching exhaustively for the
            // theoretically perfect release set.
            String offender = worstOffender.get();
            candidateSet.removeIf(o ->
                    o.fromParticipant().equals(offender) || o.toParticipant().equals(offender));
        }

        List<Obligation> stillQueued = new ArrayList<>(remaining);
        stillQueued.removeAll(candidateSet);

        return new ClearingResult(cancelled, candidateSet, stillQueued, netPositions);
    }

    /**
     * Simple cycle detection via DFS. For a real network with
     * thousands of participants, a more efficient algorithm
     * (Johnson's algorithm for finding all elementary cycles) would
     * be needed - this DFS version is intentionally the clear,
     * correct baseline, appropriate for a demo-scale participant
     * count, not a claim of production-scale performance.
     */
    private Optional<List<Obligation>> findCycle(List<Obligation> obligations) {
        Map<String, List<Obligation>> adjacency = new HashMap<>();
        for (Obligation o : obligations) {
            adjacency.computeIfAbsent(o.fromParticipant(), k -> new ArrayList<>()).add(o);
        }

        for (String start : adjacency.keySet()) {
            List<Obligation> path = new ArrayList<>();
            Set<String> visiting = new HashSet<>();
            Optional<List<Obligation>> cycle = dfs(start, start, adjacency, visiting, path);
            if (cycle.isPresent()) return cycle;
        }
        return Optional.empty();
    }

    private Optional<List<Obligation>> dfs(
            String current, String target,
            Map<String, List<Obligation>> adjacency,
            Set<String> visiting, List<Obligation> path) {

        visiting.add(current);
        for (Obligation edge : adjacency.getOrDefault(current, List.of())) {
            path.add(edge);
            if (edge.toParticipant().equals(target) && path.size() > 0) {
                return Optional.of(new ArrayList<>(path));
            }
            if (!visiting.contains(edge.toParticipant())) {
                Optional<List<Obligation>> result =
                        dfs(edge.toParticipant(), target, adjacency, visiting, path);
                if (result.isPresent()) return result;
            }
            path.remove(path.size() - 1);
        }
        visiting.remove(current);
        return Optional.empty();
    }

    private Map<String, BigDecimal> computeNetPositions(List<Obligation> obligations) {
        Map<String, BigDecimal> positions = new HashMap<>();
        for (Obligation o : obligations) {
            positions.merge(o.fromParticipant(), o.amount().negate(), BigDecimal::add);
            positions.merge(o.toParticipant(), o.amount(), BigDecimal::add);
        }
        return positions;
    }

    private Optional<String> findWorstInfeasibleParticipant(
            Map<String, BigDecimal> netPositions,
            Map<String, BigDecimal> availableLiquidity) {

        String worst = null;
        BigDecimal worstShortfall = BigDecimal.ZERO;

        for (Map.Entry<String, BigDecimal> entry : netPositions.entrySet()) {
            BigDecimal netPosition = entry.getValue();
            if (netPosition.signum() >= 0) continue; // net receiver, never infeasible

            BigDecimal available = availableLiquidity.getOrDefault(entry.getKey(), BigDecimal.ZERO);
            BigDecimal shortfall = netPosition.negate().subtract(available);

            if (shortfall.signum() > 0 && shortfall.compareTo(worstShortfall) > 0) {
                worst = entry.getKey();
                worstShortfall = shortfall;
            }
        }
        return Optional.ofNullable(worst);
    }
}
