package com.balasubramani.ecbp.settlement.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * BilateralNettingService — netting ECBP's own outgoing and incoming
 * queued instructions against a SINGLE counterparty. This is
 * genuinely, legitimately implementable by ECBP unilaterally, unlike
 * multilateral netting, because it only involves ECBP's own two-way
 * relationship with one settlement account - no third-party
 * visibility is required.
 *
 * Example this solves: ECBP owes Correspondent-A $10,000 (queued),
 * and separately has $7,000 incoming FROM Correspondent-A already
 * confirmed but not yet applied. Rather than settling the full
 * $10,000 gross (requiring $10,000 of liquidity) and separately
 * receiving $7,000, net them first: only $3,000 of actual liquidity
 * is needed to settle the net position, with both sides agreeing
 * this is equivalent (this requires the counterparty relationship to
 * support netting - not all do, e.g. some SWIFT correspondent
 * relationships settle gross-only by agreement; this must be checked
 * per SETTLEMENT_ACCOUNT, not assumed universally applicable).
 */
public class BilateralNettingService {

    private final SettlementInstructionRepository instructionRepository;

    public BilateralNettingService(SettlementInstructionRepository instructionRepository) {
        this.instructionRepository = instructionRepository;
    }

    /**
     * Attempt to net a queued outgoing instruction against any
     * confirmed-but-unapplied incoming instructions from the SAME
     * settlement account, before falling back to gross settlement.
     */
    public NettingResult attemptBilateralNet(String settlementAccountId) {

        BigDecimal outgoingTotal = instructionRepository
                .sumQueuedOutgoing(settlementAccountId);
        BigDecimal incomingTotal = instructionRepository
                .sumConfirmedUnappliedIncoming(settlementAccountId);

        if (outgoingTotal.signum() == 0 || incomingTotal.signum() == 0) {
            return NettingResult.noNettingPossible();
        }

        BigDecimal nettedAmount = outgoingTotal.min(incomingTotal);

        // Apply the netting: reduce both sides by the netted amount.
        // Only the REMAINDER needs to go through the normal gross
        // RTGS settlement path (SettlementDecisionEngine).
        instructionRepository.applyNetting(settlementAccountId, nettedAmount);

        BigDecimal remainingOutgoing = outgoingTotal.subtract(nettedAmount);

        return new NettingResult(nettedAmount, remainingOutgoing);
    }

    public record NettingResult(BigDecimal nettedAmount, BigDecimal remainingGrossOutgoing) {
        public static NettingResult noNettingPossible() {
            return new NettingResult(BigDecimal.ZERO, BigDecimal.ZERO);
        }
    }

    public interface SettlementInstructionRepository {
        BigDecimal sumQueuedOutgoing(String settlementAccountId);
        BigDecimal sumConfirmedUnappliedIncoming(String settlementAccountId);
        void applyNetting(String settlementAccountId, BigDecimal amount);
    }
}
