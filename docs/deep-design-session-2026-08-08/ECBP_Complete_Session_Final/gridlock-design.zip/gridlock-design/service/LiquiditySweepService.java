package com.balasubramani.ecbp.settlement.service;

import java.math.BigDecimal;
import java.util.List;

/**
 * LiquiditySweepService — moves ECBP's OWN available liquidity between
 * its OWN settlement accounts to cover a shortfall, when both accounts
 * hold the same currency and sweeping between them is operationally
 * permitted. This is real, standard treasury practice (often called
 * "cash concentration" or "liquidity pooling") - entirely within
 * ECBP's own control, requiring no third-party visibility, and
 * genuinely distinct from multilateral netting.
 *
 * Example: ECBP's FedNow-equivalent RTGS settlement account is short
 * $5,000, but its card-network settlement account (same currency)
 * currently holds $20,000 of headroom above its own low-liquidity
 * threshold. Rather than leaving the RTGS payment queued and drawing
 * on (potentially costly) intraday credit, sweep $5,000 internally
 * first.
 */
public class LiquiditySweepService {

    private final LiquidityRepository liquidityRepository;

    public LiquiditySweepService(LiquidityRepository liquidityRepository) {
        this.liquidityRepository = liquidityRepository;
    }

    /**
     * Attempt to cover a shortfall on the target account by sweeping
     * surplus liquidity from other same-currency ECBP settlement
     * accounts, ordered by largest available surplus first (minimizes
     * the number of accounts touched per sweep).
     */
    public SweepResult attemptSweep(String targetAccountId, BigDecimal shortfallAmount, String currency) {

        List<LiquidityPosition> candidateSources = liquidityRepository
                .getSweepCandidates(currency, targetAccountId);
        // Expected to be pre-sorted by surplus descending at the
        // repository layer - keeps this method focused on the
        // allocation logic, not query construction.

        BigDecimal remaining = shortfallAmount;
        BigDecimal totalSwept = BigDecimal.ZERO;

        for (LiquidityPosition source : candidateSources) {
            if (remaining.signum() <= 0) break;

            BigDecimal surplus = source.availableBalance()
                    .subtract(source.reservedAmount())
                    .subtract(source.lowLiquidityThreshold());
            // Never sweep BELOW a source account's own configured
            // threshold - a sweep should never create a new shortfall
            // somewhere else to fix one here.

            if (surplus.signum() <= 0) continue;

            BigDecimal sweepAmount = surplus.min(remaining);

            liquidityRepository.transferBetweenOwnAccounts(
                    source.settlementAccountId(), targetAccountId, sweepAmount);

            remaining = remaining.subtract(sweepAmount);
            totalSwept = totalSwept.add(sweepAmount);
        }

        boolean fullyCovered = remaining.signum() <= 0;
        return new SweepResult(totalSwept, remaining, fullyCovered);
    }

    public record SweepResult(BigDecimal totalSwept, BigDecimal stillShort, boolean fullyCovered) {}

    public record LiquidityPosition(
            String settlementAccountId, BigDecimal availableBalance,
            BigDecimal reservedAmount, BigDecimal lowLiquidityThreshold) {}

    public interface LiquidityRepository {
        List<LiquidityPosition> getSweepCandidates(String currency, String excludeAccountId);
        void transferBetweenOwnAccounts(String fromAccountId, String toAccountId, BigDecimal amount);
    }
}
