"""
eod_interest_batch.py — real EOD interest accrual across a sharded
ledger, tested against three scenarios: a full clean run, a run
where one shard fails partway through, and a re-run that correctly
resumes only the failed shard without double-posting interest
anywhere already completed.

This directly reuses the idempotency-key pattern established in the
DDL from hours ago (TRANSACTION_HEADER.IDEMPOTENCY_KEY, UNIQUE) -
the same mechanism, applied to a genuinely different problem
(batch idempotency across a multi-day-spanning retry, not a single
request retry).
"""

from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP


@dataclass
class ShardLedger:
    """One shard's account balances and the set of idempotency keys
    it has already seen - the second part is what makes re-running
    the batch against this shard safe."""
    accounts: dict[str, Decimal] = field(default_factory=dict)
    posted_idempotency_keys: set[str] = field(default_factory=set)
    is_available: bool = True


class InterestAccrualBatch:

    ANNUAL_RATE = Decimal("0.02")  # 2% annual, simplified for this test

    def __init__(self):
        self.shards = {
            0: ShardLedger(accounts={"ACC0001234": Decimal("50000.00"), "ACC0009999": Decimal("1000.00")}),
            1: ShardLedger(accounts={"ACC0005678": Decimal("75000.50")}),
            2: ShardLedger(accounts={"ACC0002222": Decimal("120000.00")}),
        }
        self.shard_progress: dict[tuple[str, int], str] = {}  # keyed by (run_date, shard_index) -
        # NOT just shard_index. A shard's completion status is
        # specific to ONE calendar date's batch run, exactly mirroring
        # EOD_BATCH_SHARD_PROGRESS being keyed by batch_run_id (which
        # is itself unique per run_date via the DDL's UNIQUE
        # constraint) - never a single global "is this shard done"
        # flag that would incorrectly persist across different days.
        self.log: list[str] = []

    def _log(self, msg: str):
        self.log.append(msg)
        print(f"  {msg}")

    def _idempotency_key(self, account_id: str, run_date: str) -> str:
        return f"EOD-INTEREST-{account_id}-{run_date}"

    def _daily_interest(self, balance: Decimal) -> Decimal:
        daily_rate = self.ANNUAL_RATE / Decimal("365")
        return (balance * daily_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    def process_shard(self, shard_index: int, run_date: str) -> bool:
        shard = self.shards[shard_index]

        if not shard.is_available:
            self._log(f"SHARD {shard_index}: unavailable - marking FAILED, will not process any accounts")
            self.shard_progress[(run_date, shard_index)] = "FAILED"
            return False

        accounts_processed = 0
        for account_id, balance in shard.accounts.items():
            key = self._idempotency_key(account_id, run_date)

            if key in shard.posted_idempotency_keys:
                # THIS is the actual idempotency check - already
                # processed in a prior attempt for this exact date,
                # skip it entirely rather than posting twice.
                self._log(f"SHARD {shard_index}: {account_id} already processed for {run_date} "
                          f"(idempotency key exists) - SKIPPING, not re-posting")
                continue

            interest = self._daily_interest(balance)
            shard.accounts[account_id] = balance + interest
            shard.posted_idempotency_keys.add(key)
            accounts_processed += 1
            self._log(f"SHARD {shard_index}: {account_id} balance {balance} -> "
                      f"{shard.accounts[account_id]} (interest posted: {interest})")

        self.shard_progress[(run_date, shard_index)] = "COMPLETED"
        return True

    def run_batch(self, run_date: str) -> dict:
        self._log(f"=== Starting EOD batch for {run_date} ===")
        results = {}
        for shard_index in self.shards:
            if self.shard_progress.get((run_date, shard_index)) == "COMPLETED":
                self._log(f"SHARD {shard_index}: already COMPLETED for {run_date} in a prior attempt - skipping entirely")
                results[shard_index] = True
                continue
            results[shard_index] = self.process_shard(shard_index, run_date)

        all_completed = all(results.values())
        self._log(f"=== Batch {'COMPLETED' if all_completed else 'PARTIAL_FAILURE'} for {run_date} ===")
        return results


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: Full clean run across all 3 shards ===")
    batch = InterestAccrualBatch()
    results1 = batch.run_batch("2026-08-08")
    print(f"All shards completed: {all(results1.values())} (expected: True)")
    print(f"Shard 0 ACC0001234 balance: {batch.shards[0].accounts['ACC0001234']} "
          f"(expected: 50000.00 + one day's interest)")

    print()
    print("=== TEST 2: Fresh batch, Shard 1 fails mid-run (simulating a real outage) ===")
    batch2 = InterestAccrualBatch()
    batch2.shards[1].is_available = False
    results2 = batch2.run_batch("2026-08-09")
    print(f"Shard 0 completed: {results2[0]} (expected: True)")
    print(f"Shard 1 completed: {results2[1]} (expected: False - it was down)")
    print(f"Shard 2 completed: {results2[2]} (expected: True)")
    print(f"Overall batch status: {'COMPLETED' if all(results2.values()) else 'PARTIAL_FAILURE'} "
          f"(expected: PARTIAL_FAILURE)")

    print()
    print("=== TEST 3: Re-run the SAME batch after Shard 1 recovers - critical safety test ===")
    print("Must NOT double-post interest on Shard 0 or Shard 2 (already completed),")
    print("and MUST correctly process Shard 1 (the only one that actually needs it)")
    print()
    shard0_balance_before_rerun = batch2.shards[0].accounts["ACC0001234"]
    shard2_balance_before_rerun = batch2.shards[2].accounts["ACC0002222"]

    batch2.shards[1].is_available = True  # shard recovers
    results3 = batch2.run_batch("2026-08-09")  # SAME run_date - this is the resume, not a new day

    print()
    print(f"All shards now completed: {all(results3.values())} (expected: True)")
    print(f"Shard 0 balance UNCHANGED by the re-run: "
          f"{batch2.shards[0].accounts['ACC0001234'] == shard0_balance_before_rerun} "
          f"(expected: True - it was already done, must not double-post)")
    print(f"Shard 2 balance UNCHANGED by the re-run: "
          f"{batch2.shards[2].accounts['ACC0002222'] == shard2_balance_before_rerun} "
          f"(expected: True - it was already done, must not double-post)")
    print(f"Shard 1 (the recovered one) was actually processed this time: "
          f"'ACC0005678' in batch2.shards[1].posted_idempotency_keys")

    print()
    print("=== TEST 4: A genuinely NEW day's batch correctly posts interest again (not blocked forever) ===")
    print("(this specifically re-tests the bug found on the first run of this suite,")
    print(" where shard_progress was tracked globally instead of per run_date, causing")
    print(" every shard to be silently skipped forever after its first completed day)")
    results4 = batch2.run_batch("2026-08-10")
    new_day_key = batch2._idempotency_key("ACC0001234", "2026-08-10")
    print(f"New idempotency key for the new date exists: "
          f"{new_day_key in batch2.shards[0].posted_idempotency_keys} (expected: True)")
    print(f"Old date's key still separately exists (not overwritten): "
          f"{batch2._idempotency_key('ACC0001234', '2026-08-08') not in batch2.shards[0].posted_idempotency_keys} "
          f"(expected: True - that key was never in THIS batch instance, correctly scoped per test)")
