# EOD Interest Accrual Batch — Design Package

## Why this closed a real, glaring gap

`batch-service` was one of the original 10 services from Day 1 — and had never been touched today, despite the entire ledger it depends on being sharded (Phase 1, hours ago). A batch job that walks accounts across 3 separate physical databases and must survive a partial failure without double-posting interest is genuinely non-trivial, and it was completely unaddressed.

## A real bug found through testing — the fourth one today, and a genuinely instructive one

The first version tracked each shard's completion status globally on the batch object (`self.shard_progress[shard_index]`), not scoped to the specific date being processed. The consequence: **once a shard completed its first day's run, it would silently skip processing forever on every subsequent day** — the exact opposite of the intended behavior, and a bug that would have meant interest simply stopped accruing after day one in production, with no error, no warning, nothing in the logs to flag it.

Test 4 caught it immediately: the assertion "new idempotency key for the new date exists" returned `False` when it should have been `True`. Fixed by keying `shard_progress` by `(run_date, shard_index)` instead of just `shard_index` — which, notably, is exactly what the DDL already specified (`EOD_BATCH_SHARD_PROGRESS` keyed by `batch_run_id`, itself unique per date via the DDL's own `UNIQUE (RUN_DATE)` constraint). The Python implementation simply hadn't honored its own schema's design — a good reminder that writing the DDL correctly doesn't guarantee the code built against it actually respects it, only testing does.

## Files

```
ddl/eod_batch_ddl.sql              - EOD_BATCH_RUN, EOD_BATCH_SHARD_PROGRESS
service/eod_interest_batch.py      - tested against 4 real scenarios, one real bug found and fixed
```

## Verified, working — 4 real scenarios

1. **Full clean run** across all 3 shards — correct interest calculated and posted everywhere
2. **Partial failure** — Shard 1 goes down mid-run, Shards 0 and 2 complete normally, overall batch correctly reports `PARTIAL_FAILURE`
3. **Safe resume** — re-running the exact same date after Shard 1 recovers correctly skips the two already-completed shards (zero double-posting, balances provably unchanged) and correctly processes only the shard that actually needed it
4. **A genuinely new day still works** — after the fix, the next calendar date's batch correctly processes every shard again, with interest correctly compounding on top of the prior day's balance

## How this ties into everything built today

The idempotency mechanism (`EOD-INTEREST-{account_id}-{run_date}` as the `TRANSACTION_HEADER.IDEMPOTENCY_KEY`) reuses the exact same `UNIQUE (IDEMPOTENCY_KEY)` constraint from the very first Phase 1 DDL this morning — the same pattern that protects a single payment request from being double-processed on retry now also protects a multi-day batch job from double-posting on resume. One mechanism, two genuinely different failure modes it defends against.

## Honest limitation

Interest calculation here is deliberately simplified (flat 2% annual, simple daily division) — a real EOD batch would need tiered rates, day-count conventions (actual/365 vs actual/360), and proper rounding rules that vary by jurisdiction. The **idempotency and partial-failure-recovery mechanics** proven correct here don't change regardless of how sophisticated the actual interest formula becomes — that separation is deliberate.
