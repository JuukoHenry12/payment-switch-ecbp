-- ============================================================
-- ECBP EOD Interest Accrual Batch — DDL
-- ============================================================
-- The real problem this solves: with a SHARDED ledger (3 separate
-- physical databases), an EOD batch job can no longer just "run
-- against the database" - it must walk each shard independently,
-- and MUST survive one shard failing without either (a) losing
-- track of what's already been processed, or (b) double-posting
-- interest for accounts already completed when the job is re-run.
-- ============================================================

CREATE TABLE EOD_BATCH_RUN (
    BATCH_RUN_ID           UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    RUN_DATE                 DATE          NOT NULL,
    STATUS                     VARCHAR(20) NOT NULL,  -- IN_PROGRESS, COMPLETED, PARTIAL_FAILURE
    STARTED_AT                   TIMESTAMPTZ NOT NULL DEFAULT now(),
    COMPLETED_AT                    TIMESTAMPTZ NULL,

    CONSTRAINT UQ_ONE_RUN_PER_DATE UNIQUE (RUN_DATE)
    -- Only one batch run per calendar date, ever - prevents an
    -- operator accidentally kicking off a second full run for a
    -- date already processed.
);

CREATE TABLE EOD_BATCH_SHARD_PROGRESS (
    BATCH_RUN_ID              UUID          NOT NULL REFERENCES EOD_BATCH_RUN(BATCH_RUN_ID),
    SHARD_INDEX                  SMALLINT   NOT NULL,
    STATUS                          VARCHAR(20) NOT NULL,  -- PENDING, COMPLETED, FAILED
    ACCOUNTS_PROCESSED                SMALLINT NOT NULL DEFAULT 0,
    TOTAL_INTEREST_POSTED               DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    LAST_ATTEMPTED_AT                     TIMESTAMPTZ NULL,
    ERROR_MESSAGE                           TEXT       NULL,

    PRIMARY KEY (BATCH_RUN_ID, SHARD_INDEX)
);

-- The actual idempotency mechanism: every interest posting uses a
-- deterministic idempotency key derived from (account_id, run_date).
-- This means re-running the batch after a partial failure is
-- genuinely safe - an account already processed will have its
-- interest-posting TRANSACTION_HEADER already exist with this exact
-- key, and the UNIQUE constraint on TRANSACTION_HEADER.IDEMPOTENCY_KEY
-- (from the very first Phase 1 DDL, hours ago) makes a duplicate
-- attempt a safe no-op rather than a double-posting.
--
-- Key format: 'EOD-INTEREST-{account_id}-{run_date}'
-- e.g. 'EOD-INTEREST-ACC0001234-2026-08-08'
