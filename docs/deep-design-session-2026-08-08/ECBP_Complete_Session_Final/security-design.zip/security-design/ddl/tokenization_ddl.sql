-- ============================================================
-- ECBP Tokenization Vault & Access Audit — DDL
-- ============================================================
-- Design decision, stated explicitly: this table is the ENTIRE
-- PCI-DSS cardholder data environment (CDE) boundary. Every other
-- service in ECBP (risk-service, audit-service, reporting, the
-- frontend) touches only TOKEN values, never the real PAN. This is
-- what "tokenize at first point of capture" actually means
-- architecturally - not a slogan, a specific table boundary that
-- everything else in the system is designed around.
-- ============================================================

CREATE TABLE TOKEN_VAULT (
    TOKEN                  VARCHAR(19)     PRIMARY KEY,   -- format-preserving, looks like a real PAN
    ENCRYPTED_PAN           BYTEA          NOT NULL,       -- the real PAN, AES-256-GCM encrypted, never stored plaintext
    ENCRYPTED_DEK            BYTEA         NOT NULL,       -- the Data Encryption Key, itself encrypted by the KEK (envelope encryption)
    DEK_NONCE                 BYTEA        NOT NULL,       -- AES-GCM nonce for the PAN encryption - unique per record, never reused
    KEK_KEY_ID                 VARCHAR(50) NOT NULL,       -- which Key Encryption Key (in HSM/KMS) wraps this record's DEK - supports key rotation
    PAN_LAST_FOUR                CHAR(4)   NOT NULL,       -- safe to store in clear - this alone never re-identifies a card
    CREATED_AT                    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Explicitly NO index on ENCRYPTED_PAN - it should never be
-- searched/joined on directly; all lookups happen via TOKEN.

-- ------------------------------------------------------------
-- TOKEN_ACCESS_LOG — every single detokenization request is
-- logged here, regardless of outcome. This IS the PCI-DSS
-- requirement for logging all access to cardholder data, made
-- concrete as an actual table, not a policy document.
-- ------------------------------------------------------------
CREATE TABLE TOKEN_ACCESS_LOG (
    ACCESS_ID               UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    TOKEN                    VARCHAR(19)    NOT NULL,
    REQUESTING_SERVICE        VARCHAR(50)   NOT NULL,   -- which microservice asked - mTLS client identity, not self-reported
    REQUEST_REASON              VARCHAR(100) NOT NULL,  -- e.g. "SWIFT_SETTLEMENT_SUBMISSION", "CARD_NETWORK_AUTH"
    OUTCOME                      VARCHAR(20) NOT NULL,  -- GRANTED, DENIED_UNAUTHORIZED, DENIED_TOKEN_NOT_FOUND
    REQUESTED_AT                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_TOKEN_ACCESS_TOKEN ON TOKEN_ACCESS_LOG (TOKEN);
CREATE INDEX IDX_TOKEN_ACCESS_SERVICE ON TOKEN_ACCESS_LOG (REQUESTING_SERVICE, REQUESTED_AT);
-- Both indexes support the two real operational questions:
-- "who has accessed THIS card" and "what has THIS service accessed,
-- and how often" - exactly what a PCI-DSS audit actually asks for.

-- ------------------------------------------------------------
-- SERVICE_TOKEN_PERMISSION — explicit allowlist of which
-- services may EVER detokenize, and for what stated reason.
-- Default-deny: a service not listed here is denied automatically.
-- ------------------------------------------------------------
CREATE TABLE SERVICE_TOKEN_PERMISSION (
    SERVICE_NAME             VARCHAR(50)    NOT NULL,
    ALLOWED_REASON            VARCHAR(100)  NOT NULL,
    GRANTED_AT                 TIMESTAMPTZ  NOT NULL DEFAULT now(),
    GRANTED_BY                  VARCHAR(50)  NOT NULL,
    PRIMARY KEY (SERVICE_NAME, ALLOWED_REASON)
);

-- Only these two services ever legitimately need the real PAN -
-- everything else in ECBP works with tokens only.
INSERT INTO SERVICE_TOKEN_PERMISSION (SERVICE_NAME, ALLOWED_REASON, GRANTED_BY) VALUES
    ('legacy-gateway-service', 'CARD_NETWORK_AUTH', 'security-admin'),
    ('swift-gateway-service', 'SWIFT_SETTLEMENT_SUBMISSION', 'security-admin');
