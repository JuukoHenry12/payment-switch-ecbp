package com.balasubramani.ecbp.security.service;

import java.time.Instant;
import java.util.Optional;

/**
 * TokenAccessControlService — the enforcement layer sitting in front
 * of the tokenization vault's detokenize() operation. This is
 * DEFAULT-DENY: a service not explicitly listed in
 * SERVICE_TOKEN_PERMISSION is refused automatically, and every single
 * attempt - granted or denied - is logged unconditionally.
 *
 * The "requesting service" identity here is intended to come from
 * the mTLS client certificate identity established by the service
 * mesh (Istio), NOT a self-reported header a caller could spoof -
 * that binding is what makes "REQUESTING_SERVICE" in the audit log
 * actually trustworthy rather than merely a claim.
 */
public class TokenAccessControlService {

    private final PermissionRepository permissionRepository;
    private final AccessLogRepository accessLogRepository;
    private final DetokenizeFunction detokenizeFunction;

    public TokenAccessControlService(
            PermissionRepository permissionRepository,
            AccessLogRepository accessLogRepository,
            DetokenizeFunction detokenizeFunction) {
        this.permissionRepository = permissionRepository;
        this.accessLogRepository = accessLogRepository;
        this.detokenizeFunction = detokenizeFunction;
    }

    public DetokenizeResult requestDetokenization(
            String token, String requestingService, String requestedReason) {

        boolean authorized = permissionRepository.isPermitted(requestingService, requestedReason);

        if (!authorized) {
            logAccess(token, requestingService, requestedReason, AccessOutcome.DENIED_UNAUTHORIZED);
            return DetokenizeResult.denied("Service '" + requestingService +
                    "' is not authorized for reason '" + requestedReason + "'");
        }

        try {
            String pan = detokenizeFunction.detokenize(token);
            logAccess(token, requestingService, requestedReason, AccessOutcome.GRANTED);
            return DetokenizeResult.granted(pan);
        } catch (Exception e) {
            logAccess(token, requestingService, requestedReason, AccessOutcome.DENIED_TOKEN_NOT_FOUND);
            return DetokenizeResult.denied("Token not found or invalid");
        }
    }

    private void logAccess(String token, String service, String reason, AccessOutcome outcome) {
        // Unconditional - runs on EVERY call, granted or denied.
        // A denied attempt is often more security-relevant than a
        // granted one, and must never be skipped from logging.
        accessLogRepository.record(token, service, reason, outcome, Instant.now());
    }

    public enum AccessOutcome { GRANTED, DENIED_UNAUTHORIZED, DENIED_TOKEN_NOT_FOUND }

    public record DetokenizeResult(boolean success, Optional<String> pan, Optional<String> denialReason) {
        public static DetokenizeResult granted(String pan) {
            return new DetokenizeResult(true, Optional.of(pan), Optional.empty());
        }
        public static DetokenizeResult denied(String reason) {
            return new DetokenizeResult(false, Optional.empty(), Optional.of(reason));
        }
    }

    public interface PermissionRepository {
        boolean isPermitted(String serviceName, String reason);
    }

    public interface AccessLogRepository {
        void record(String token, String service, String reason, AccessOutcome outcome, Instant when);
    }

    public interface DetokenizeFunction {
        String detokenize(String token) throws Exception;
    }
}
