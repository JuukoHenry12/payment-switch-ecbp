"""
tokenization_vault.py — real, working envelope encryption and
format-preserving tokenization for card PANs.

This implements the actual pattern every production KMS/HSM uses
(AWS KMS, SoftHSM, real hardware HSMs) — envelope encryption:

  1. Generate a random Data Encryption Key (DEK) PER RECORD.
  2. Encrypt the actual sensitive data (the PAN) with the DEK.
  3. Encrypt the DEK itself with a Key Encryption Key (KEK) that
     lives in the HSM/KMS and NEVER leaves it in plaintext.
  4. Store the encrypted PAN + the encrypted DEK together. The KEK
     itself is never stored alongside the data it protects.

Why this pattern specifically, not just "encrypt the PAN with one
key": if the KEK ever needs rotation (a real, required PCI-DSS
practice), you only need to re-wrap the small DEKs, not re-encrypt
every stored PAN — a genuinely important operational property at
any real scale.

In this design pass, SoftHSM (installed in the Phase 0 enterprise
tooling) would hold the actual KEK in production. Here, the KEK is
simulated in-memory to prove the envelope encryption logic itself
is correct — the real HSM integration is a configuration/connection
detail on top of this same correct cryptographic logic, not a
different algorithm.
"""

import os
import secrets
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class SimulatedHSM:
    """
    Stands in for SoftHSM/a real HSM's role: holds the Key Encryption
    Key and performs wrap/unwrap operations. In production this class
    would be replaced by a real HSM client — the DEK itself is never
    visible outside this boundary in either version.
    """

    def __init__(self):
        # In production, this key is generated inside the HSM and
        # NEVER extractable in plaintext, even by ECBP's own code.
        self._kek = AESGCM.generate_key(bit_length=256)
        self.key_id = "KEK-2026-001"

    def wrap_dek(self, dek: bytes) -> tuple[bytes, bytes]:
        """Encrypt (wrap) a Data Encryption Key with the KEK."""
        nonce = os.urandom(12)
        aesgcm = AESGCM(self._kek)
        wrapped = aesgcm.encrypt(nonce, dek, associated_data=None)
        return wrapped, nonce

    def unwrap_dek(self, wrapped_dek: bytes, nonce: bytes) -> bytes:
        """Decrypt (unwrap) a Data Encryption Key using the KEK."""
        aesgcm = AESGCM(self._kek)
        return aesgcm.decrypt(nonce, wrapped_dek, associated_data=None)


class TokenizationVault:

    def __init__(self, hsm: SimulatedHSM):
        self.hsm = hsm
        self._vault = {}  # simulates TOKEN_VAULT table

    def tokenize(self, pan: str) -> str:
        """
        Full envelope encryption flow:
        1. Generate a fresh DEK for this specific PAN.
        2. Encrypt the PAN with the DEK.
        3. Wrap the DEK with the HSM's KEK.
        4. Store: encrypted PAN + wrapped DEK + its nonce.
        5. Generate and return a format-preserving token.
        """
        dek = AESGCM.generate_key(bit_length=256)
        pan_nonce = os.urandom(12)
        aesgcm = AESGCM(dek)
        encrypted_pan = aesgcm.encrypt(pan_nonce, pan.encode(), associated_data=None)

        wrapped_dek, dek_nonce = self.hsm.wrap_dek(dek)

        token = self._generate_format_preserving_token(pan)

        self._vault[token] = {
            "encrypted_pan": encrypted_pan,
            "pan_nonce": pan_nonce,
            "wrapped_dek": wrapped_dek,
            "dek_nonce": dek_nonce,
            "kek_key_id": self.hsm.key_id,
            "pan_last_four": pan[-4:],
        }

        return token

    def detokenize(self, token: str) -> str:
        """
        Reverse the envelope: unwrap the DEK via the HSM, then use
        it to decrypt the actual PAN. This is the ONLY path back to
        the real PAN anywhere in the system - and in the real
        service, every call to this method is what gets logged to
        TOKEN_ACCESS_LOG, unconditionally.
        """
        record = self._vault.get(token)
        if record is None:
            raise ValueError("Token not found")

        dek = self.hsm.unwrap_dek(record["wrapped_dek"], record["dek_nonce"])
        aesgcm = AESGCM(dek)
        pan_bytes = aesgcm.decrypt(record["pan_nonce"], record["encrypted_pan"], associated_data=None)
        return pan_bytes.decode()

    def _generate_format_preserving_token(self, pan: str) -> str:
        """
        Generates a token that LOOKS like a valid card number (same
        length, passes Luhn check) but is NOT derivable back to the
        real PAN without the vault. This matters because some
        downstream systems (logging, display formatting, even some
        legacy validation logic) expect something PAN-shaped - a
        format-preserving token avoids breaking those integrations
        while still being cryptographically meaningless on its own.
        """
        bin_prefix = pan[:6]  # BIN/IIN often preserved for routing purposes
        random_digits_len = len(pan) - 6 - 1  # leave room for a Luhn check digit
        random_digits = "".join(secrets.choice("0123456789") for _ in range(random_digits_len))
        partial = bin_prefix + random_digits
        check_digit = self._luhn_check_digit(partial)
        return partial + str(check_digit)

    @staticmethod
    def _luhn_check_digit(partial_number: str) -> int:
        digits = [int(d) for d in partial_number]
        digits.reverse()
        total = 0
        for i, d in enumerate(digits):
            if i % 2 == 0:
                d *= 2
                if d > 9:
                    d -= 9
            total += d
        return (10 - (total % 10)) % 10

    @staticmethod
    def is_luhn_valid(number: str) -> bool:
        digits = [int(d) for d in number]
        digits.reverse()
        total = 0
        for i, d in enumerate(digits):
            if i % 2 == 1:
                d *= 2
                if d > 9:
                    d -= 9
            total += d
        return total % 10 == 0


# ------------------------------------------------------------
# REAL TESTS — not just a description, actual execution
# ------------------------------------------------------------
if __name__ == "__main__":
    hsm = SimulatedHSM()
    vault = TokenizationVault(hsm)

    print("=== TEST 1: Tokenize a real PAN, verify token is Luhn-valid ===")
    real_pan = "4532123456789012"
    token = vault.tokenize(real_pan)
    print(f"Original PAN:  {real_pan}")
    print(f"Token:         {token}")
    print(f"Token length matches original: {len(token) == len(real_pan)}")
    print(f"Token is Luhn-valid (looks like a real card number): {TokenizationVault.is_luhn_valid(token)}")
    print(f"Token != original PAN (genuinely different value): {token != real_pan}")
    print(f"Token preserves BIN prefix (first 6 digits): {token[:6] == real_pan[:6]}")

    print()
    print("=== TEST 2: Detokenize - full round trip through envelope encryption ===")
    recovered_pan = vault.detokenize(token)
    print(f"Recovered PAN: {recovered_pan}")
    print(f"Matches original exactly: {recovered_pan == real_pan}")

    print()
    print("=== TEST 3: Two different PANs never produce the same token ===")
    pan_a = "4532123456789012"
    pan_b = "4532123456789099"
    token_a = vault.tokenize(pan_a)
    token_b = vault.tokenize(pan_b)
    print(f"Token A: {token_a}")
    print(f"Token B: {token_b}")
    print(f"Tokens are different: {token_a != token_b}")

    print()
    print("=== TEST 4: Same PAN tokenized twice produces DIFFERENT tokens ===")
    print("(deliberate - prevents correlating two transactions via a shared token,")
    print(" a real privacy/security property, not an oversight)")
    token_c = vault.tokenize(pan_a)
    print(f"First token for pan_a:  {token_a}")
    print(f"Second token for pan_a: {token_c}")
    print(f"Different tokens for the same PAN: {token_a != token_c}")
    print(f"But both still detokenize correctly: {vault.detokenize(token_a) == vault.detokenize(token_c) == pan_a}")

    print()
    print("=== TEST 5: Attempting to detokenize a garbage/unknown token fails safely ===")
    try:
        vault.detokenize("0000000000000000")
        print("FAIL - should have raised an error")
    except ValueError as e:
        print(f"Correctly rejected: {e}")

    print()
    print("=== TEST 6: The encrypted PAN stored in the vault is genuinely unreadable ===")
    stored_record = vault._vault[token]
    print(f"Raw stored encrypted_pan bytes (should be meaningless): {stored_record['encrypted_pan'][:20]}...")
    print(f"Contains the real PAN digits in plaintext anywhere: {real_pan.encode() in stored_record['encrypted_pan']}")
