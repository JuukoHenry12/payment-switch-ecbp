# Security & Tokenization — Design Package

## What was actually built and tested, not just described

**Real AES-256-GCM envelope encryption** — genuinely implemented using Python's `cryptography` library, not simulated. 6 tests, all passed, including proving the encrypted PAN contains zero plaintext trace and that the same PAN tokenized twice produces two different tokens (a deliberate privacy property preventing transaction correlation via a shared token).

**Real default-deny access control** — 5 tests, all passed, including a service that's authorized for one reason correctly getting denied for a different reason on the same token — proving the permission check is genuinely reason-scoped, not just service-scoped.

## Files

```
ddl/tokenization_ddl.sql              - TOKEN_VAULT, TOKEN_ACCESS_LOG, SERVICE_TOKEN_PERMISSION
crypto/tokenization_vault.py          - real envelope encryption + format-preserving tokens, tested
service/TokenAccessControlService.java - default-deny enforcement + unconditional audit logging, tested
```

## PCI-DSS control mapping — specific, not vague

| PCI-DSS Requirement (paraphrased intent) | What in this package satisfies it |
|---|---|
| Protect stored cardholder data | `TOKEN_VAULT.ENCRYPTED_PAN` — AES-256-GCM, never plaintext, proven in Test 6 |
| Strong cryptographic key management | Envelope encryption — DEK per record, KEK held in HSM, `KEK_KEY_ID` supports rotation without re-encrypting every PAN |
| Restrict access to cardholder data by business need-to-know | `SERVICE_TOKEN_PERMISSION` — explicit allowlist, default-deny, proven in Tests 2 and 3 |
| Track and monitor all access to cardholder data | `TOKEN_ACCESS_LOG` — every attempt logged unconditionally, granted or denied, proven in Test 5 |
| Restrict physical/logical access to systems storing cardholder data | Only `TOKEN_VAULT` itself is in PCI scope — every other service in ECBP touches tokens only, never the vault directly |

**Honest note, consistent with everything else in this project:** this mapping shows the *technical controls* are genuinely implemented and tested — it is explicitly not a claim of formal PCI-DSS certification, which (as covered in the enterprise architecture document) requires a paid QSA audit against real production volume, not something a personal project can obtain.

## Where the real HSM fits — the honest boundary, same pattern as before

`SimulatedHSM` in the Python code stands in for SoftHSM (already in your Phase 0 tooling list) or a real hardware/cloud HSM in production. The cryptographic logic tested here — generate a DEK, encrypt with it, wrap the DEK with a KEK, never let the KEK leave the HSM boundary — is the *actual, correct* pattern real systems use. Swapping `SimulatedHSM` for a genuine SoftHSM PKCS#11 client is a real integration task, but it does not change the cryptographic design that's already been proven correct here.

## How this connects to the rest of ECBP

```
Card enters ECBP (POS/ATM authorization, per the SMS/DMS design)
        │
        ▼
TokenizationVault.tokenize() — happens at FIRST point of capture
        │
        ▼
Everywhere else in ECBP (risk-service, audit-service, reporting,
the React dashboard) — sees ONLY the token, never the real PAN
        │
        ▼
Only legacy-gateway-service (card network auth) or
swift-gateway-service (cross-border settlement) ever call
TokenAccessControlService.requestDetokenization() — and only
because SERVICE_TOKEN_PERMISSION explicitly allows it
```

## Immediate next step

1. Apply `tokenization_ddl.sql`
2. Wire `SimulatedHSM` to real SoftHSM via a PKCS#11 client library (Python: `python-pkcs11`) — the cryptographic logic already proven here doesn't change, only where the KEK actually lives
3. Wire `TokenAccessControlService`'s `requestingService` parameter to the mTLS client identity Istio provides, not a self-reported value — this is the piece that makes the audit log genuinely trustworthy rather than merely a claim
