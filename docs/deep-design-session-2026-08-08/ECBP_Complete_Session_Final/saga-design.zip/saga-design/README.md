# Saga Orchestrator — Design Package

## Why this was the right thing to build next

Every piece designed today referenced "the saga pattern with compensating transactions" — `ShardRouter.sameShardTransferPossible()` explicitly branches on it, the settlement engine's design assumes it, the enterprise architecture document names it repeatedly. **The actual engine that executes and compensates steps had never been written.** This was the single largest gap in an otherwise well-tested chain.

## A real, genuine bug found and fixed during testing — worth reading closely

The first version of `SagaOrchestrator` typed each step's action as `Supplier<StepFuture>`, and the orchestrator called `step.execute().get()`. That only unwraps the outer `Supplier` — it returns a `StepFuture` object but **never actually invokes that object's own logic**. The real step code, including the exception that should trigger compensation, never ran at all.

**This was invisible until real testing exposed it**: the first test run showed every scenario — including two deliberately designed to fail — reporting `success: true`. That mismatch was the signal. Traced to the double-indirection bug, fixed by collapsing to a single, direct `StepAction` functional interface (`void run() throws Exception`), re-tested, and now all three scenarios behave exactly as the saga pattern requires.

**This is genuinely the most valuable bug caught all day** — not because it's dramatic, but because it's exactly the class of bug that would have passed a shallow glance at the code (it reads as reasonable Java) and only surfaces when you actually run it against a real failure scenario.

## Files

```
ddl/saga_ddl.sql              - SAGA_INSTANCE, SAGA_STEP_LOG
service/SagaOrchestrator.java - the fixed, tested engine
```

## Verified, working — 3 real scenarios, all correct after the fix

1. **Full success** — hold funds, risk check, post credit, finalize — all four steps complete, saga marked `COMPLETED`
2. **Fails at step 3** (target shard unavailable) — steps 1-2 correctly compensate, in reverse order (RiskCheck undone before HoldFundsSourceShard)
3. **Fails at step 4** (finalize fails *after* credit already posted on the target shard) — all three prior steps correctly compensate, in reverse order, confirmed explicitly: PostCreditTargetShard undone first, then RiskCheck, then HoldFundsSourceShard last

Test 3 is the one that actually matters most for a cross-shard transfer specifically — it's the scenario where money has *already moved* on one shard before a later step fails, and the compensation correctly reverses it rather than leaving the system in an inconsistent state.

## How this plugs into everything designed today

```java
// Inside payment-service, when ShardRouter says cross-shard:
List<SagaStep> steps = List.of(
    new SagaStep("HoldFundsSourceShard",
        () -> accountService.placeHold(fromAccountId, amount),
        () -> accountService.releaseHold(fromAccountId, amount)),
    new SagaStep("RiskCheck",
        () -> riskService.evaluate(txnId),   // per the fraud detection package
        () -> {} /* no side effect to undo */),
    new SagaStep("PostCreditTargetShard",
        () -> accountService.postCredit(toAccountId, amount),
        () -> accountService.reverseCredit(toAccountId, amount)),
    new SagaStep("FinalizeSourceDebit",
        () -> accountService.finalizeDebit(fromAccountId, amount),
        () -> accountService.reverseDebit(fromAccountId, amount))
);

SagaResult result = sagaOrchestrator.execute(txnId, steps);
// result feeds directly into PaymentSettled or PaymentFailed,
// exactly the events the CQRS projector already knows how to consume
```

## Honest limitation

The `StepFuture`/async design was deliberately simplified to synchronous `StepAction.run()` for this design pass — a real production saga (especially one where a step involves a network call to another shard's database) would likely want genuine async execution with timeouts, not blocking calls. The compensation *logic and ordering* proven correct here doesn't change; only the execution model around it would need to evolve for true async operation.
