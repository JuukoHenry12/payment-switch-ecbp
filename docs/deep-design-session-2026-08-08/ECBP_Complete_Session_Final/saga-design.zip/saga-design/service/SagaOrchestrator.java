package com.balasubramani.ecbp.payment.saga;

import java.util.ArrayList;
import java.util.List;

/**
 * SagaOrchestrator — the actual engine that has been referenced
 * constantly across every piece designed today (ShardRouter,
 * settlement, the enterprise architecture doc) but never built until
 * now. This is the core mechanism for a cross-shard transfer: since
 * no local ACID transaction can span two separate shard databases,
 * this executes a sequence of steps, and if ANY step fails, runs
 * compensation for every ALREADY-COMPLETED step, in reverse order.
 *
 * Each step is a pair: (execute, compensate). The orchestrator
 * itself has no knowledge of what a step actually DOES - it only
 * knows how to run steps forward and unwind them backward, which is
 * exactly the right level of abstraction: the saga engine is
 * reusable across any multi-step distributed operation, not just
 * cross-shard transfers specifically.
 */
public class SagaOrchestrator {

    private final SagaRepository sagaRepository;

    public SagaOrchestrator(SagaRepository sagaRepository) {
        this.sagaRepository = sagaRepository;
    }

    public SagaResult execute(String txnId, List<SagaStep> steps) {

        String sagaId = sagaRepository.createSaga(txnId, "CROSS_SHARD_TRANSFER");
        List<SagaStep> completedSteps = new ArrayList<>();

        for (int i = 0; i < steps.size(); i++) {
            SagaStep step = steps.get(i);
            try {
                step.execute().run();
                sagaRepository.logStepCompleted(sagaId, i, step.name());
                completedSteps.add(step);

            } catch (Exception e) {
                // A step genuinely failed. This is NOT an unexpected
                // crash to be swallowed silently - it's the exact
                // scenario the saga pattern exists for. Compensate
                // everything already completed, in REVERSE order -
                // undoing step 2 before step 1 matters when step 2's
                // undo logic might depend on step 1 still being intact
                // (e.g. releasing a hold only makes sense if the
                // account record it references hasn't itself been
                // rolled back yet).
                sagaRepository.logStepFailed(sagaId, i, step.name());
                compensate(sagaId, completedSteps);
                return SagaResult.compensated(sagaId, step.name(), e.getMessage());
            }
        }

        sagaRepository.markCompleted(sagaId);
        return SagaResult.completed(sagaId);
    }

    private void compensate(String sagaId, List<SagaStep> completedSteps) {
        sagaRepository.markCompensating(sagaId);

        for (int i = completedSteps.size() - 1; i >= 0; i--) {
            SagaStep step = completedSteps.get(i);
            try {
                step.compensate().run();
                sagaRepository.logStepCompensated(sagaId, step.name());
            } catch (Exception compensationFailure) {
                // A compensation itself failing is the genuinely
                // dangerous case - this is exactly why every
                // compensation attempt is logged individually rather
                // than assumed to succeed. A real system would alert
                // operations immediately here, not silently continue -
                // an un-compensated step means real inconsistent
                // state exists and needs human intervention.
                sagaRepository.logCompensationFailed(sagaId, step.name(),
                        compensationFailure.getMessage());
            }
        }

        sagaRepository.markCompensated(sagaId);
    }

    // --- Supporting types ---

    /**
     * A single unit of work a saga step performs, either forward
     * (execute) or backward (compensate). Deliberately a single,
     * simple functional interface - a previous version of this
     * design wrapped this in an unnecessary Supplier<StepFuture>,
     * which silently broke step execution entirely (the orchestrator
     * only unwrapped the outer Supplier and never invoked the actual
     * action). Fixed here to one direct level of indirection.
     */
    public interface StepAction {
        void run() throws Exception;
    }

    public record SagaStep(String name, StepAction execute, StepAction compensate) {}

    public record SagaResult(boolean success, String sagaId, String failedAtStep, String failureReason) {
        public static SagaResult completed(String sagaId) {
            return new SagaResult(true, sagaId, null, null);
        }
        public static SagaResult compensated(String sagaId, String failedAtStep, String reason) {
            return new SagaResult(false, sagaId, failedAtStep, reason);
        }
    }

    public interface SagaRepository {
        String createSaga(String txnId, String sagaType);
        void logStepCompleted(String sagaId, int stepIndex, String stepName);
        void logStepFailed(String sagaId, int stepIndex, String stepName);
        void logStepCompensated(String sagaId, String stepName);
        void logCompensationFailed(String sagaId, String stepName, String reason);
        void markCompleted(String sagaId);
        void markCompensating(String sagaId);
        void markCompensated(String sagaId);
    }
}
