-- ============================================================
-- ECBP Saga Orchestrator — DDL
-- ============================================================
-- Every cross-shard transfer (per ShardRouter.sameShardTransferPossible()
-- returning false) MUST go through this, since no local ACID
-- transaction can span two separate physical shard databases. This
-- table set is what makes a saga's progress and compensation history
-- durable and auditable - not just an in-memory state machine that
-- vanishes if the orchestrating process crashes mid-saga.
-- ============================================================

CREATE TABLE SAGA_INSTANCE (
    SAGA_ID              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_ID                 UUID          NOT NULL,   -- the same txn_id correlating everything designed today
    SAGA_TYPE               VARCHAR(30)  NOT NULL,   -- CROSS_SHARD_TRANSFER
    STATUS                    VARCHAR(20) NOT NULL,   -- IN_PROGRESS, COMPLETED, COMPENSATING, COMPENSATED, FAILED
    CURRENT_STEP_INDEX          SMALLINT  NOT NULL DEFAULT 0,
    CREATED_AT                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UPDATED_AT                      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE SAGA_STEP_LOG (
    STEP_LOG_ID          UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    SAGA_ID                UUID          NOT NULL REFERENCES SAGA_INSTANCE(SAGA_ID),
    STEP_INDEX               SMALLINT    NOT NULL,
    STEP_NAME                  VARCHAR(50) NOT NULL,
    STEP_STATUS                  VARCHAR(20) NOT NULL,  -- COMPLETED, FAILED, COMPENSATED
    EXECUTED_AT                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    COMPENSATED_AT                   TIMESTAMPTZ NULL
);

CREATE INDEX IDX_SAGA_STEP_SAGA ON SAGA_STEP_LOG (SAGA_ID, STEP_INDEX);
-- This index is what lets a crashed/restarted orchestrator process
-- correctly resume: query completed steps for a saga still
-- IN_PROGRESS, and either continue forward or begin compensating
-- from the last known-good step - genuinely necessary for a saga
-- that must survive process restarts, not just in-memory failures.
