-- ============================================================
-- ECBP Transaction Journal — DDL
-- ============================================================
-- The gap this closes: everything built earlier today captures
-- EITHER high-level status (CQRS read model) OR failure-point
-- snapshots (failure_diagnostics.py) OR operational log lines
-- (Splunk). None of them, individually, answer "show me EVERY step
-- this transaction went through, with the actual values at each
-- point" - the exact thing a support engineer needs to root-cause
-- something WITHOUT reproducing it elsewhere.
--
-- This table is that single, complete record. One row per
-- (txn_id, step_sequence) - written by EVERY service at EVERY
-- meaningful step, success or failure, not just at failure points.
-- ============================================================

CREATE TABLE TRANSACTION_JOURNAL_ENTRY (
    JOURNAL_ENTRY_ID          BIGSERIAL      PRIMARY KEY,   -- ordered, cheap, append-only
    TXN_ID                       UUID        NOT NULL,      -- same correlation key as every package today
    STEP_SEQUENCE                   SMALLINT NOT NULL,       -- strict ordering within this transaction
    SERVICE_NAME                       VARCHAR(50) NOT NULL,
    STEP_NAME                            VARCHAR(100) NOT NULL,
    STATUS                                  VARCHAR(20) NOT NULL,  -- SUCCESS, FAILURE
    INPUT_SNAPSHOT                            JSONB     NOT NULL,   -- the ACTUAL values received at this step
    OUTPUT_SNAPSHOT                             JSONB    NULL,      -- the ACTUAL values produced, null if it failed
    REASON_CODE                                   VARCHAR(4) NULL,  -- populated on FAILURE, from REASON_CODE_REFERENCE
    DURATION_MS                                     INTEGER NOT NULL,
    RECORDED_AT                                       TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT UQ_TXN_STEP UNIQUE (TXN_ID, STEP_SEQUENCE)
);

CREATE INDEX IDX_JOURNAL_TXN ON TRANSACTION_JOURNAL_ENTRY (TXN_ID, STEP_SEQUENCE);
-- This single index is what makes "give me the complete story for
-- TXN-003" a fast, single-query operation - ORDER BY STEP_SEQUENCE
-- against this index returns the entire journey, already in order,
-- no manual correlation across five services' separate logs needed.

-- ------------------------------------------------------------
-- Note on what NEVER appears in INPUT_SNAPSHOT/OUTPUT_SNAPSHOT:
-- real PANs, passwords, or any raw sensitive value. Everything
-- captured here uses the TOKEN from the tokenization vault (built
-- earlier today), account IDs, amounts, and business state - genuine
-- debugging value with zero PCI-DSS scope expansion. This is
-- enforced at the application layer (JournalRecorder below refuses
-- to accept a raw PAN-shaped value), not left to developer discipline
-- alone.
-- ------------------------------------------------------------
