"""
card_auth_token_check_fix.py — closes the exact gap the
token-lifecycle-design README flagged and left undone: a REVOKED
token could still reach card_authorization_service.authorize()'s
fraud/credit checks, because nothing ever called
TokenLifecycleService.check_usable() first. A revoked card (lost,
stolen, PIN-locked) must be rejected before ANY other check runs -
not just eventually caught somewhere downstream.

This wraps the original authorize() method rather than editing it in
place, so both packages stay independently correct and testable -
the same integration pattern used by card-issuance-design and
onboarding-design earlier today.
"""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from enum import Enum


class TokenGatedAuthStatus(Enum):
    HELD = "HELD"
    DECLINED = "DECLINED"
    TOKEN_REVOKED = "TOKEN_REVOKED"   # a NEW, more specific outcome than a generic decline


@dataclass
class GatedAuthResult:
    status: TokenGatedAuthStatus
    reason: str | None


def authorize_with_token_gate(card_token: str, token_lifecycle_service,
                                original_authorize_fn, *authorize_args) -> GatedAuthResult:
    """
    THE fix: check_usable() runs first, unconditionally, before the
    original authorize() logic (fraud check, credit check) ever
    executes. A revoked token never reaches those checks at all -
    it's rejected at the very first gate, with a specific,
    distinguishable reason code rather than a generic decline that
    would look identical to an ordinary fraud/credit refusal.
    """
    if not token_lifecycle_service.check_usable(card_token):
        return GatedAuthResult(
            status=TokenGatedAuthStatus.TOKEN_REVOKED,
            reason="Card token is not usable (revoked or suspended) - rejected before any fraud or credit check ran",
        )

    # Only reached if the token gate passes - delegates to the
    # ALREADY-TESTED original authorize() logic, unchanged.
    original_result = original_authorize_fn(*authorize_args)
    return GatedAuthResult(
        status=TokenGatedAuthStatus.HELD if original_result.status.value == "HELD" else TokenGatedAuthStatus.DECLINED,
        reason=original_result.decline_reason,
    )


# ------------------------------------------------------------
# REAL TESTS - using the actual, unmodified classes from both
# original packages, not simplified stand-ins
# ------------------------------------------------------------
if __name__ == "__main__":

    import sys
    sys.path.insert(0, "/home/claude/card-design/service")
    sys.path.insert(0, "/home/claude/token-lifecycle-design/service")
    from card_authorization_service import CardAuthorizationService, Account
    from token_lifecycle_service import TokenLifecycleService

    now = datetime(2026, 8, 9, 10, 0, 0)
    card_service = CardAuthorizationService()
    token_service = TokenLifecycleService()

    print("=== TEST 1: A healthy, active token - authorization proceeds normally, reaches HELD ===")
    real_pan = "4532123456789012"
    token = token_service.get_or_create_persistent_token(real_pan, performed_by="card-service")
    account = Account(account_id="ACC0001234", available_credit=Decimal("5000.00"))

    result1 = authorize_with_token_gate(
        token, token_service, card_service.authorize,
        "TXN-FIX-001", token, account, "Grocery Store", Decimal("100.00"), now,
    )
    print(f"Status: {result1.status.value} (expected: HELD)")

    print()
    print("=== TEST 2: THE actual gap being closed - a REVOKED token is rejected BEFORE fraud/credit checks run ===")
    token_service.revoke(token, reason="Card reported stolen", performed_by="fraud-ops-team")

    fraud_check_would_have_run = {"called": False}
    original_fraud_check = card_service._fraud_check
    def spy_fraud_check(*args, **kwargs):
        fraud_check_would_have_run["called"] = True
        return original_fraud_check(*args, **kwargs)
    card_service._fraud_check = spy_fraud_check

    result2 = authorize_with_token_gate(
        token, token_service, card_service.authorize,
        "TXN-FIX-002", token, account, "Electronics Store", Decimal("200.00"), now,
    )
    print(f"Status: {result2.status.value} (expected: TOKEN_REVOKED - a NEW, specific status)")
    print(f"Reason: {result2.reason}")
    print(f"Fraud check was called: {fraud_check_would_have_run['called']} "
          f"(expected: False - THIS is the actual proof the gap is closed: the revoked token")
    print(f"never even reached the fraud/credit logic, not just that the final answer happened to be a decline)")

    print()
    print("=== TEST 3: A suspended (not revoked) token is ALSO correctly blocked at the same gate ===")
    other_pan = "5412345678901234"
    other_token = token_service.get_or_create_persistent_token(other_pan, performed_by="card-service")
    token_service.suspend(other_token, reason="Suspicious activity under review", performed_by="fraud-ops-team")

    result3 = authorize_with_token_gate(
        other_token, token_service, card_service.authorize,
        "TXN-FIX-003", other_token, account, "Restaurant", Decimal("50.00"), now,
    )
    print(f"Status: {result3.status.value} (expected: TOKEN_REVOKED - check_usable() treats SUSPENDED "
          f"the same as REVOKED for authorization purposes: not currently usable, regardless of reason)")

    print()
    print("=== TEST 4: After reactivation, the SAME token is usable again, normal authorization resumes ===")
    token_service.reactivate(other_token, performed_by="fraud-ops-team")
    result4 = authorize_with_token_gate(
        other_token, token_service, card_service.authorize,
        "TXN-FIX-004", other_token, account, "Restaurant", Decimal("50.00"), now,
    )
    print(f"Status: {result4.status.value} (expected: HELD - reactivation genuinely restores normal authorization)")
