"""
onboarding_screening_real_wire.py — closes a second gap of the exact
same shape as the card-auth/token-lifecycle fix: onboarding-design's
README claimed screening_fn "wraps kyc-aml-design's
SanctionsScreeningEngine," but every test in that package actually
used a hardcoded lambda (`lambda name: "CLEAR"`) instead of the real,
tested fuzzy-matching engine. The workflow's control-flow logic
(stop on CONFIRMED_MATCH, hold on POTENTIAL_MATCH) was proven correct
- but never against the real screening behavior it was supposed to
be gated by. Given kyc-aml-design was explicitly the highest-stakes
package built today, this is worth closing for real, not left as an
assumed connection.
"""

from datetime import datetime


def build_real_screening_fn(screening_engine):
    """
    Adapts kyc-aml-design's actual SanctionsScreeningEngine.screen()
    into the simple string-returning interface onboarding_workflow.py
    expects - a real adapter, not a re-implementation, so the exact,
    already-tested fuzzy-matching logic from kyc-aml-design is what
    actually runs during onboarding, not a re-approximation of it.
    """
    def real_screening_fn(applicant_name: str) -> str:
        # No account_id exists yet at this stage - screening happens
        # BEFORE account creation, which is the whole point of
        # gating it first. Using the applicant name as the lookup
        # key here is correct for a pre-account check.
        result = screening_engine.screen(applicant_name, applicant_name, list_type="SANCTIONS")
        return result.outcome
    return real_screening_fn


# ------------------------------------------------------------
# REAL TESTS - using the actual, unmodified classes from both
# original packages
# ------------------------------------------------------------
if __name__ == "__main__":

    import sys
    sys.path.insert(0, "/home/claude/onboarding-design/service")
    sys.path.insert(0, "/home/claude/kyc-aml-design/service")
    from onboarding_workflow import OnboardingWorkflow
    from screening_engine import SanctionsScreeningEngine, ListEntry

    # Same fictional sanctions list used in kyc-aml-design's own tests
    sanctions_list = [
        ListEntry("SANC-001", "AL-RASHIDI, KHALID MANSOUR", "OFAC"),
        ListEntry("SANC-002", "PETROV, DMITRI VLADIMIROVICH", "UN"),
        ListEntry("SANC-003", "OKONKWO, EMEKA CHUKWU", "EU"),
    ]
    real_engine = SanctionsScreeningEngine(sanctions_list, pep_list=[])
    real_screening_fn = build_real_screening_fn(real_engine)

    workflow = OnboardingWorkflow(
        screening_fn=real_screening_fn,   # THE fix - the real engine, not a lambda
        account_creation_fn=lambda name: {"success": True, "account_id": f"ACC-{name[:4].upper()}"},
        card_issuance_fn=lambda acc_id: {"success": True, "card_id": f"CARD-{acc_id}"},
    )

    print("=== TEST 1: A genuinely clean applicant - real fuzzy matching correctly clears them ===")
    workflow.start_application("APP-REAL-001", "Sarah Jennifer Thompson")
    result1 = workflow.run("APP-REAL-001")
    print(f"Status: {result1.status.value} (expected: COMPLETED)")

    print()
    print("=== TEST 2: A REORDERED name matching a real sanctions entry - the exact fuzzy-match")
    print("    case kyc-aml-design proved works - now proven to correctly halt ONBOARDING too, not")
    print("    just the standalone screening engine in isolation ===")
    workflow.start_application("APP-REAL-002", "Khalid Mansour Al-Rashidi")
    result2 = workflow.run("APP-REAL-002")
    print(f"Status: {result2.status.value} (expected: SCREENING_REJECTED or SCREENING_MANUAL_REVIEW - "
          f"NOT COMPLETED, using the REAL fuzzy match, not a hardcoded lambda that would have missed this)")

    print()
    print("=== TEST 3: The hard case from kyc-aml-design's own Test 5 - partial token overlap, correctly clears ===")
    workflow.start_application("APP-REAL-003", "Chukwu Emeka Adeyemi")
    result3 = workflow.run("APP-REAL-003")
    print(f"Status: {result3.status.value} (expected: COMPLETED - the real engine's 0.600 score, just under")
    print(f"the review threshold, correctly propagates through onboarding exactly as kyc-aml-design proved")
    print(f"it would on its own - this is the actual proof the SAME engine, not a re-approximation, is running)")

    print()
    print("=== TEST 4: An exact sanctions match - correctly and immediately halts onboarding ===")
    workflow.start_application("APP-REAL-004", "AL-RASHIDI, KHALID MANSOUR")
    result4 = workflow.run("APP-REAL-004")
    print(f"Status: {result4.status.value} (expected: SCREENING_REJECTED)")
    print(f"Account ID assigned: {result4.account_id} (expected: None - never reached account creation)")
