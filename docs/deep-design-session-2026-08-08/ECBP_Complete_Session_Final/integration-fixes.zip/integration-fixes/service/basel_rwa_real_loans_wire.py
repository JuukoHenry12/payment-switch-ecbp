"""
basel_rwa_real_loans_wire.py — closes gap #5: basel-capital-design's
calculate_rwa() was only ever tested against hand-constructed
Exposure objects, never against real balances from loan-design's
amortization schedules.

Honest note before the fix itself: this gap is not PURELY a wiring
problem like the first four. loan-design's ScheduleEntry has no
concept of asset class (residential mortgage vs. unsecured retail
vs. corporate) at all - that classification genuinely doesn't exist
anywhere in loan-design's data model. This integration layer adds
that classification as new metadata alongside each loan, rather than
pretending it was already captured. A real production system would
need this classification captured at loan origination time, not
bolted on afterward - flagged here plainly, not glossed over.
"""

from dataclasses import dataclass
from decimal import Decimal


@dataclass
class ClassifiedLoan:
    loan_id: str
    asset_class: str   # THE metadata loan-design never captured - added here explicitly
    remaining_balance: Decimal


def extract_current_exposures(classified_loans: list[ClassifiedLoan], Exposure):
    """
    THE fix: builds real Exposure objects from actual loan remaining
    balances (post-amortization, i.e. what's genuinely still owed
    right now), rather than hand-picked round numbers.
    """
    return [Exposure(loan.asset_class, loan.remaining_balance) for loan in classified_loans]


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    import sys
    sys.path.insert(0, "/home/claude/loan-design/service")
    sys.path.insert(0, "/home/claude/basel-capital-design/service")
    from loan_amortization import generate_amortization_schedule
    from basel_capital import calculate_rwa, Exposure, check_capital_adequacy, CET1_EFFECTIVE_MINIMUM

    print("=== TEST 1: Generate REAL amortization schedules for 3 genuinely different loans ===")
    loan_a = generate_amortization_schedule(Decimal("25000.00"), Decimal("0.065"), 60)   # matches loan-design's own test
    loan_b = generate_amortization_schedule(Decimal("400000.00"), Decimal("0.045"), 360)  # a real mortgage-scale loan
    loan_c = generate_amortization_schedule(Decimal("15000.00"), Decimal("0.12"), 24)     # unsecured retail-scale

    # Pull the REMAINING BALANCE after 12 real payments for each -
    # not the original principal, the actual current exposure
    balance_a_after_12 = loan_a[11].remaining_balance
    balance_b_after_12 = loan_b[11].remaining_balance
    balance_c_after_12 = loan_c[11].remaining_balance

    print(f"Loan A remaining balance after 12 payments: ${balance_a_after_12:,.2f}")
    print(f"Loan B remaining balance after 12 payments: ${balance_b_after_12:,.2f}")
    print(f"Loan C remaining balance after 12 payments: ${balance_c_after_12:,.2f}")

    print()
    print("=== TEST 2: Classify these REAL balances (the metadata loan-design itself doesn't capture) ===")
    classified = [
        ClassifiedLoan("LOAN-A", "UNSECURED_RETAIL", balance_a_after_12),
        ClassifiedLoan("LOAN-B", "RESIDENTIAL_MORTGAGE", balance_b_after_12),
        ClassifiedLoan("LOAN-C", "UNSECURED_RETAIL", balance_c_after_12),
    ]
    exposures = extract_current_exposures(classified, Exposure)
    for e in exposures:
        print(f"  {e.asset_class}: ${e.amount:,.2f}")

    print()
    print("=== TEST 3: Real RWA calculated from REAL, currently-outstanding loan balances ===")
    rwa = calculate_rwa(exposures)
    expected_rwa = (balance_a_after_12 * Decimal("0.75") + balance_b_after_12 * Decimal("0.35") +
                     balance_c_after_12 * Decimal("0.75")).quantize(Decimal("0.01"))
    print(f"RWA: ${rwa:,.2f}")
    print(f"Matches hand-calculated expected value from the SAME real balances: {rwa == expected_rwa} (expected: True)")

    print()
    print("=== TEST 4: Full capital adequacy check against these real, currently-outstanding exposures ===")
    checks = check_capital_adequacy(
        cet1=rwa * Decimal("0.08"), tier1=rwa * Decimal("0.09"), total_capital=rwa * Decimal("0.10"),
        rwa=rwa, total_exposure=rwa * Decimal("1.5"),
        hqla=Decimal("50000.00"), net_outflows_30d=Decimal("30000.00"),
    )
    for c in checks:
        print(f"  {c.metric}: {c.actual}% - {'PASS' if c.compliant else 'FAIL'}")
    print(f"CET1 correctly passes the real 7.0% buffer-inclusive requirement at 8% capitalization: "
          f"{checks[0].compliant}")
