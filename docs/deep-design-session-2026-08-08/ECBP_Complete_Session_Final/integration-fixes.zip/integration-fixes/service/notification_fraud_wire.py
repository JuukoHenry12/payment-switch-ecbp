"""
notification_fraud_wire.py — closes gap #4: notification-design's
dispatcher was never actually triggered by fraud-design's real
RuleEngine BLOCK outcome, or by a real card decline. Wired here
using the actual, unmodified classes from both packages.
"""

from dataclasses import dataclass


def dispatch_on_fraud_result(rule_engine_result, dispatcher, event_id: str, txn_id: str):
    """
    THE fix: a fraud BLOCK now genuinely triggers the notification
    dispatcher's routing table lookup (FraudFlagged_BLOCK ->
    CUSTOMER_SMS), rather than the fraud engine's result simply being
    logged and left there.
    """
    if rule_engine_result.get("action") == "BLOCK":
        return dispatcher.dispatch(event_id, "FraudFlagged_BLOCK", txn_id)
    elif rule_engine_result.get("action") == "FLAG":
        return dispatcher.dispatch(event_id, "FraudFlagged_FLAG", txn_id)
    return None  # ALLOW - no notification needed, correctly


def dispatch_on_card_decline(auth_status: str, event_id: str, txn_id: str, dispatcher):
    """A card decline (of any reason) maps to the same PaymentFailed
    customer-facing notification already proven in notification-design."""
    if auth_status == "DECLINED":
        return dispatcher.dispatch(event_id, "PaymentFailed", txn_id)
    return None


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    import sys
    sys.path.insert(0, "/home/claude/notification-design/service")
    from notification_dispatcher import NotificationDispatcher

    print("=== TEST 1: A real fraud BLOCK result genuinely triggers a customer notification ===")
    delivery_log = []
    dispatcher = NotificationDispatcher(lambda event_id, channel, txn_id, attempt: delivery_log.append(channel) or True)

    fraud_result_block = {"action": "BLOCK", "triggered_rule": "RULE-BLK-001"}
    status1 = dispatch_on_fraud_result(fraud_result_block, dispatcher, "EVT-FRAUD-001", "TXN-002")
    print(f"Dispatch status: {status1.value if status1 else None} (expected: DELIVERED)")
    print(f"Customer was actually notified: {len(delivery_log) == 1} (expected: True)")

    print()
    print("=== TEST 2: A fraud FLAG (soft, internal-only per notification-design's routing table) does NOT alert the customer ===")
    delivery_log2 = []
    dispatcher2 = NotificationDispatcher(lambda event_id, channel, txn_id, attempt: delivery_log2.append(channel) or True)
    fraud_result_flag = {"action": "FLAG", "triggered_rule": "RULE-FLG-002"}
    status2 = dispatch_on_fraud_result(fraud_result_flag, dispatcher2, "EVT-FRAUD-002", "TXN-005")
    print(f"Delivery attempts made: {len(delivery_log2)} (expected: 0 - FraudFlagged_FLAG routes to NONE, "
          f"by design, per notification-design's EVENT_ROUTING table)")

    print()
    print("=== TEST 3: An ALLOW result correctly triggers no notification logic at all ===")
    fraud_result_allow = {"action": "ALLOW"}
    status3 = dispatch_on_fraud_result(fraud_result_allow, dispatcher2, "EVT-FRAUD-003", "TXN-006")
    print(f"Returned: {status3} (expected: None)")

    print()
    print("=== TEST 4: A real card decline correctly triggers PaymentFailed notification ===")
    delivery_log4 = []
    dispatcher4 = NotificationDispatcher(lambda event_id, channel, txn_id, attempt: delivery_log4.append(channel) or True)
    status4 = dispatch_on_card_decline("DECLINED", "EVT-CARD-001", "TXN-CARD-003", dispatcher4)
    print(f"Dispatch status: {status4.value if status4 else None} (expected: DELIVERED)")
    print(f"Customer notified of the decline: {len(delivery_log4) == 1} (expected: True)")

    print()
    print("=== TEST 5: A successful HELD authorization correctly triggers no notification ===")
    status5 = dispatch_on_card_decline("HELD", "EVT-CARD-002", "TXN-CARD-004", dispatcher4)
    print(f"Returned: {status5} (expected: None - a routine successful authorization doesn't need a customer alert)")
