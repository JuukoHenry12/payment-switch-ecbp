"""
routing_card_auth_wire.py — closes gap #3: card authorization never
called the routing engine to determine domestic vs. international
handling. Wired here, with a genuinely important property proven
along the way: the token's preserved BIN prefix (first 6 digits of
the real PAN, confirmed in token_lifecycle_service._generate_token)
means routing can run directly on the TOKEN - detokenization is
never required for a routing decision, which is a real security
property worth proving explicitly, not just assuming it happens to
work.
"""

from dataclasses import dataclass


@dataclass
class RoutedAuthDecision:
    routing_destination: str
    is_domestic: bool
    card_network: str | None


def determine_routing_from_token(card_token: str, routing_engine) -> RoutedAuthDecision:
    """
    THE fix: card authorization now consults the routing engine
    BEFORE completing, using ONLY the token - never the real PAN.
    """
    result = routing_engine.route_card_transaction(card_token)
    if not result["matched"]:
        return RoutedAuthDecision(routing_destination="UNMATCHED", is_domestic=False, card_network=None)
    return RoutedAuthDecision(
        routing_destination=result["routing_destination"],
        is_domestic=result["is_domestic"],
        card_network=result["card_network"],
    )


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    import sys
    sys.path.insert(0, "/home/claude/routing-design/service")
    sys.path.insert(0, "/home/claude/token-lifecycle-design/service")
    from routing_engine import RoutingEngine
    from token_lifecycle_service import TokenLifecycleService

    bin_rows = [
        {"bin_range_start": "453212", "bin_range_end": "453212", "card_network": "VISA",
         "routing_destination": "SETL-CARD-VISA-01", "is_domestic": False},
        {"bin_range_start": "620000", "bin_range_end": "620099", "card_network": "LOCAL_DEBIT",
         "routing_destination": "INTERNAL", "is_domestic": True},
    ]
    routing_engine = RoutingEngine(bin_rows, correspondent_routing_rows=[])
    token_service = TokenLifecycleService()

    print("=== TEST 1: A real PAN is tokenized, then routing runs on the TOKEN alone - never the PAN ===")
    real_visa_pan = "4532123456789012"
    token = token_service.get_or_create_persistent_token(real_visa_pan, performed_by="card-issuance-service")
    print(f"Real PAN:  {real_visa_pan}")
    print(f"Token:     {token}")
    print(f"BIN preserved in token: {token[:6] == real_visa_pan[:6]} (expected: True - this is what makes")
    print(f"routing on the token alone possible without ever detokenizing)")

    decision1 = determine_routing_from_token(token, routing_engine)
    print(f"Routing decision: {decision1.routing_destination}, domestic={decision1.is_domestic}, "
          f"network={decision1.card_network}")
    print(f"Correctly routed to VISA settlement: {decision1.routing_destination == 'SETL-CARD-VISA-01'} "
          f"(expected: True, USING ONLY THE TOKEN)")

    print()
    print("=== TEST 2: ECBP's own-issued card token correctly routes INTERNAL - proven via token alone ===")
    own_card_pan = "6200001234567890"
    own_token = token_service.get_or_create_persistent_token(own_card_pan, performed_by="card-issuance-service")
    decision2 = determine_routing_from_token(own_token, routing_engine)
    print(f"Routing decision: {decision2.routing_destination}, domestic={decision2.is_domestic}")
    print(f"Correctly stays internal: {decision2.routing_destination == 'INTERNAL' and decision2.is_domestic} "
          f"(expected: True)")

    print()
    print("=== TEST 3: An unrecognized BIN correctly reports unmatched, not a silent guess ===")
    unknown_pan = "9999999999999999"
    unknown_token = token_service.get_or_create_persistent_token(unknown_pan, performed_by="card-issuance-service")
    decision3 = determine_routing_from_token(unknown_token, routing_engine)
    print(f"Routing decision: {decision3.routing_destination} (expected: UNMATCHED)")
