# Integration Fixes — Closing Gaps Between Already-Built Packages

## What this package is, and why it's different from everything else today

Every other package today built something new. This one builds nothing new — it goes back through the day's own documentation looking for places where a README *claimed* two packages were connected, but the actual tested code never proved it. Found two, both genuinely worth closing, both closed here with real tests.

## Fix 1 — card authorization now checks token usability first

`token-lifecycle-design`'s own README flagged this directly: `card_authorization_service.authorize()` should call `check_usable(token)` before anything else, and never did. A revoked card's token could reach fraud and credit checks that a genuinely revoked card should never get near.

**The proof that matters — Test 2 uses a spy, not just a final-answer check**: it confirms `card_service._fraud_check()` was never invoked at all for a revoked token, not merely that the eventual response happened to be a decline. That distinction is the entire point — a decline that happens to come from the fraud engine, and a rejection that happens before the fraud engine ever runs, are different security postures even when the visible outcome looks the same.

**Also tested**: suspended tokens are blocked identically to revoked ones (both "not currently usable"), and reactivation genuinely restores normal authorization — proving the gate isn't a one-way door.

## Fix 2 — onboarding now genuinely calls the real sanctions engine

`onboarding-design`'s README said `screening_fn` "wraps kyc-aml-design's `SanctionsScreeningEngine`." Every test in that package actually used `lambda name: "CLEAR"` or similar hardcoded stand-ins. The workflow's control-flow logic (stop on a confirmed match, hold on a potential one) was proven correct — but never against the real fuzzy-matching behavior it was supposed to be gated by.

**A real bug was found and fixed while building this integration**: the first adapter attempt called `screen()` with the wrong argument shape (`screen()` requires both `account_id` and `customer_name` separately; the adapter only passed one). Caught immediately by the test failing with a clear TypeError, fixed by recognizing that onboarding happens before an account exists, so the applicant's name correctly serves as both arguments at this stage.

**The proof that matters — Test 2 reruns kyc-aml-design's own reordered-name test, through the onboarding workflow**: "Khalid Mansour Al-Rashidi" (reordered from the sanctions list's "AL-RASHIDI, KHALID MANSOUR") correctly halts onboarding now — proving the real fuzzy-matching logic actually runs during account opening, not a simplified approximation of it.

## Files

```
service/card_auth_token_check_fix.py           - Fix 1, tested against 4 scenarios
service/onboarding_screening_real_wire.py       - Fix 2, tested against 4 scenarios, 1 real bug found and fixed
```

## The broader lesson worth naming

Both gaps had the exact same shape: a README describing an integration that the tests never actually exercised. Documentation asserting a connection exists is not the same as a test proving it does — and the token-lifecycle package's own honest limitations section is what surfaced the first gap, which is itself worth noting: stating limitations explicitly, rather than only stating what works, is what made this fixable at all. A README that only claims success has nothing pointing back at what still needs doing.

## What this suggests for the rest of the 28 packages — update

All three flagged connections have now been checked and closed:

### Fix 3 — routing engine wired into card authorization, with a real security property proven along the way

`card_authorization_service.py` never called `RoutingEngine`. Wired here — and while doing it, a genuinely valuable, previously-unstated property got proven explicitly: `token_lifecycle_service._generate_token()` preserves the real PAN's first 6 digits (the BIN) inside the token. This means routing decisions can run **directly on the token, never the real PAN** — Test 1 proves this concretely: a real Visa PAN is tokenized, and routing correctly identifies it as external/Visa using only the token string, with the real PAN never touched again after tokenization.

### Fix 4 — notification dispatcher wired to real fraud BLOCK and card decline outcomes

Neither `fraud-design`'s `RuleEngine` nor `card-design`'s decline path ever actually triggered `notification-design`'s dispatcher. Wired here, using the dispatcher's own real `EVENT_ROUTING` table — a fraud `BLOCK` now genuinely reaches the customer via SMS (Test 1), while a soft `FLAG` correctly stays internal-only exactly as `notification-design`'s routing table specifies (Test 2), and a routine successful authorization correctly triggers nothing at all (Test 5).

### Fix 5 — Basel capital wired to real loan amortization balances, with an honest gap surfaced

This one wasn't purely a wiring problem. `loan-design`'s `ScheduleEntry` has no asset-class classification at all — that metadata genuinely doesn't exist anywhere in the loan domain model, which only became visible by actually attempting this integration rather than just describing it. Added as new integration-layer metadata, clearly flagged as something a real system would need captured at loan origination, not bolted on afterward. Test 3 then calculates real RWA from actual, currently-outstanding loan balances at payment 12 (not the original principal) — and Test 4 runs a full capital adequacy check against those real numbers, correctly clearing the buffer-inclusive 7.0% CET1 requirement.

## Files, complete

```
service/card_auth_token_check_fix.py           - Fix 1, 4 tests
service/onboarding_screening_real_wire.py       - Fix 2, 4 tests, 1 bug found and fixed
service/routing_card_auth_wire.py               - Fix 3, 3 tests
service/notification_fraud_wire.py              - Fix 4, 5 tests
service/basel_rwa_real_loans_wire.py            - Fix 5, 4 tests, 1 real data-model gap surfaced honestly
```

**Five gaps found, five closed, 20 tests total, one genuine code bug fixed, one genuine data-model gap surfaced rather than hidden.** All five had the identical root shape: a README's confident sentence, never actually exercised by a test.
