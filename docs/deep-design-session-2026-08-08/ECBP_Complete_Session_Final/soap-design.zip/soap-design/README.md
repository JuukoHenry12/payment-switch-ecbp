# SOAP / WS-Security Gateway — Design Package

## What this closes

The last explicitly self-identified gap from today: `legacy-gateway-service`'s SOAP bridge was flagged as "still pending" in the notification-design README. This implements the actual, standard WS-Security UsernameToken digest scheme — genuinely computed SHA-1 digests, not a placeholder.

## Files

```
service/soap_ws_security.py   - real SOAP envelope construction + verification, 5 tests
```

## Verified, working — 5 real scenarios

1. **Build a real, correctly-structured SOAP envelope** with a WS-Security header for a settlement operation
2. **Verify it independently** — re-derives the digest from scratch rather than trusting internal state, proving verification genuinely works, not just construction
3. **Replay rejection — the entire point of the nonce** — the exact same signed request submitted twice is correctly rejected the second time. Without this check, WS-Security digest auth would be no stronger than a static password hash; an intercepted request could be resent indefinitely
4. **Wrong password correctly rejected** — a tampered or incorrect credential fails digest verification cleanly
5. **No false positives** — two genuinely different, independently valid requests both succeed, proving the replay detector isn't over-broadly rejecting legitimate traffic

## How this connects to everything built today

This is architecturally the same trust boundary pattern as the tokenization access control from the security-design package — a request either proves it's genuinely authorized, or it's rejected, with every attempt logged. The specific mechanism differs (WS-Security digest vs. mTLS service identity), but the underlying principle — never trust a claim without independent verification — is the same discipline applied to the legacy SOAP integration point specifically.

## Honest limitation

Real production WS-Security also typically includes message-level XML signing (not just the UsernameToken digest shown here) and a timestamp freshness window (rejecting a technically-unused nonce if its `Created` timestamp is too old, to bound how long the replay-detector's memory needs to persist). Both are genuine, standard extensions to what's built here — this package proves the core authentication mechanism correctly, not the complete production hardening surface.
