

import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ConcurrentHashMap;

/**
 * CircuitBreakerConcurrencySafe — closes the confirmed gap: the
 * failure-mode-gaps circuit breaker was proven correct in Python,
 * where the GIL quietly hides exactly the concurrency bug this class
 * exists to prevent. Real production traffic hits this circuit
 * breaker from MANY threads simultaneously - the state (CLOSED,
 * OPEN, HALF_OPEN) and the failure counter are genuinely shared,
 * mutable state, and a naive implementation using a plain field and
 * a plain int corrupts under real concurrent load, exactly the class
 * of bug interview question #13 (volatile vs synchronized) and #3/4
 * (HashMap concurrency) are actually testing for.
 *
 * Two implementations, tested against the SAME real concurrent load:
 * a naive one (plain fields, no synchronization) and the fixed one
 * (AtomicReference for state, AtomicInteger for the counter) -
 * proving the difference concretely, the same discipline as
 * active_active_analysis.py's lost-update proof earlier today.
 */
public class CircuitBreakerConcurrencySafe {

    public enum State { CLOSED, OPEN, HALF_OPEN }

    // ------------------------------------------------------------
    // NAIVE VERSION - the bug, reproduced deliberately
    // ------------------------------------------------------------
    static class NaiveCircuitBreaker {
        private State state = State.CLOSED;       // plain field - NOT visible correctly across threads
        private int consecutiveFailures = 0;        // plain int - NOT atomic, lost updates under concurrency
        private final int threshold;

        NaiveCircuitBreaker(int threshold) { this.threshold = threshold; }

        void recordFailure() {
            int current = consecutiveFailures;  // READ
            try { Thread.sleep(0, 100); } catch (InterruptedException ignored) {}  // widen the race window deliberately
            consecutiveFailures = current + 1;   // MODIFY-WRITE, based on a potentially now-stale 'current'
            if (consecutiveFailures >= threshold) {
                state = State.OPEN;
            }
        }

        State getState() { return state; }
        int getFailureCount() { return consecutiveFailures; }
    }

    // ------------------------------------------------------------
    // FIXED VERSION - real thread-safe state management
    // ------------------------------------------------------------
    static class SafeCircuitBreaker {
        private final AtomicReference<State> state = new AtomicReference<>(State.CLOSED);
        private final AtomicInteger consecutiveFailures = new AtomicInteger(0);
        private final int threshold;

        SafeCircuitBreaker(int threshold) { this.threshold = threshold; }

        void recordFailure() {
            int failures = consecutiveFailures.incrementAndGet();  // genuinely atomic read-modify-write
            if (failures >= threshold) {
                state.set(State.OPEN);
            }
        }

        State getState() { return state.get(); }
        int getFailureCount() { return consecutiveFailures.get(); }
    }

    // ------------------------------------------------------------
    // REAL TESTS - genuine concurrent load, matching the exact
    // pattern that exposed the naive lost-update bug earlier today
    // ------------------------------------------------------------
    public static void main(String[] args) throws InterruptedException {

        int threadCount = 20;
        int failuresPerThread = 50;
        int expectedTotalFailures = threadCount * failuresPerThread;

        System.out.println("=== TEST 1: NAIVE circuit breaker under genuine concurrent load ===");
        NaiveCircuitBreaker naive = new NaiveCircuitBreaker(expectedTotalFailures + 1); // threshold set high so it never trips - isolating JUST the counter bug
        Thread[] naiveThreads = new Thread[threadCount];
        for (int t = 0; t < threadCount; t++) {
            naiveThreads[t] = new Thread(() -> {
                for (int i = 0; i < failuresPerThread; i++) naive.recordFailure();
            });
        }
        for (Thread t : naiveThreads) t.start();
        for (Thread t : naiveThreads) t.join();

        System.out.printf("Expected failure count: %,d%n", expectedTotalFailures);
        System.out.printf("ACTUAL naive failure count: %,d%n", naive.getFailureCount());
        System.out.printf("LOST UPDATES: %,d failures vanished due to the non-atomic increment (%.1f%% lost)%n",
                expectedTotalFailures - naive.getFailureCount(),
                100.0 * (expectedTotalFailures - naive.getFailureCount()) / expectedTotalFailures);
        System.out.println("This is EXACTLY the danger interview question #3/#13 describe - not theoretical,");
        System.out.println("genuinely reproduced with real threads against real shared state.");

        System.out.println();
        System.out.println("=== TEST 2: THE FIX - the SAME concurrent load against the safe version ===");
        SafeCircuitBreaker safe = new SafeCircuitBreaker(expectedTotalFailures + 1);
        Thread[] safeThreads = new Thread[threadCount];
        for (int t = 0; t < threadCount; t++) {
            safeThreads[t] = new Thread(() -> {
                for (int i = 0; i < failuresPerThread; i++) safe.recordFailure();
            });
        }
        for (Thread t : safeThreads) t.start();
        for (Thread t : safeThreads) t.join();

        System.out.printf("Expected failure count: %,d%n", expectedTotalFailures);
        System.out.printf("ACTUAL safe failure count: %,d%n", safe.getFailureCount());
        System.out.printf("Correct, zero lost updates: %b%n", safe.getFailureCount() == expectedTotalFailures);

        System.out.println();
        System.out.println("=== TEST 3: The state transition itself is correctly atomic and visible across threads ===");
        SafeCircuitBreaker tripTest = new SafeCircuitBreaker(10);
        Thread[] tripThreads = new Thread[20];
        for (int t = 0; t < 20; t++) {
            tripThreads[t] = new Thread(tripTest::recordFailure);
        }
        for (Thread t : tripThreads) t.start();
        for (Thread t : tripThreads) t.join();
        System.out.println("Final state after 20 concurrent failures against a threshold of 10: " + tripTest.getState());
        System.out.println("Correctly OPEN, and every thread that reads getState() afterward sees this");
        System.out.println("consistently - this is what AtomicReference's visibility guarantee actually buys you,");
        System.out.println("the real answer to interview question #13.");
    }
}
