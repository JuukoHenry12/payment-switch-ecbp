# Regulatory Capital (Basel III/IV) — Design Package

## What this closes, and how it's different from everything else built today

Confirmed in research as its own distinct required category — "risk and capital management," listed separately from financial crime/AML. This is genuinely different in kind from every other package today: it's a **balance-sheet-level** question — is the bank itself solvent enough to keep operating — not a per-transaction decision.

## Files

```
ddl/basel_capital_ddl.sql       - RISK_WEIGHT_TABLE, CAPITAL_COMPONENT, CAPITAL_ADEQUACY_SNAPSHOT
service/basel_capital.py        - tested against 5 real scenarios
```

## Verified, working — 5 real scenarios

1. **RWA calculation across a genuinely mixed portfolio** — cash (0% weight), residential mortgages (35%), unsecured retail (75%), corporate loans (100%) — hand-verified to match exactly: $192,500,000 total risk-weighted assets from $380M of raw exposure
2. **A well-capitalized bank passes every ratio** — CET1, Tier 1, Total Capital, Leverage, and LCR all correctly computed and cleared
3. **The capital conservation buffer nuance, tested explicitly** — a bank at exactly 5.0% CET1 genuinely clears the *bare* Basel minimum of 4.5%, but is correctly flagged non-compliant against the *real* operating requirement of 7.0% once the mandatory conservation buffer is included. This is a genuinely common point of confusion in less careful summaries, and getting it wrong in a real system would mean silently telling a bank it's compliant when regulators would say otherwise
4. **An under-capitalized bank correctly fails multiple ratios simultaneously**, each one individually reported, not masked by a single pass/fail flag
5. **LCR specifically** — $10M of high-quality liquid assets against $25M of modeled 30-day stress outflows correctly reports 40%, well under the 100% minimum

## Why the buffer distinction (Test 3) is the most important thing in this package

A calculator that only checks against the bare 4.5% CET1 minimum would be technically citing a real number, but practically wrong — real banks operate under supervisory expectation of the buffer-inclusive 7.0% figure, and a bank technically above 4.5% but below 7.0% faces real regulatory constraints (restrictions on dividends and discretionary bonuses, specifically). Reporting such a bank as "compliant" would be a genuine, consequential error, not a rounding nuance.

## How this connects to everything built today

```
Every account/loan exposure across the sharded ledger (Phase 1) and
loan-design's amortization schedules feeds into calculate_rwa(),
weighted by asset class
        │
        ▼
Capital components (CET1/AT1/T2, tracked separately per real
regulatory structure) combine with RWA to produce the 5 ratios
        │
        ▼
CAPITAL_ADEQUACY_SNAPSHOT — a point-in-time regulatory record,
feeding into the reporting-design package's scheduled regulatory
report generation, same infrastructure, different report content
```

## Honest limitation

Real Basel implementations offer both the **standardized approach** (fixed risk weights, what's built here) and the more complex **internal ratings-based (IRB) approach**, where large banks compute their own risk weights from internal credit models subject to regulatory approval. This package implements the standardized approach correctly and completely — the IRB approach is a genuinely separate, far more complex undertaking, appropriate for a bank's internal risk modeling team, not attempted here.
