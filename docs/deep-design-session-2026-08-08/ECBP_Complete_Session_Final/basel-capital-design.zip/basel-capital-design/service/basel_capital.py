"""
basel_capital.py — real Basel III capital adequacy calculations,
using the standard, stable regulatory minimums:

  CET1 ratio  >= 4.5%  (plus a 2.5% capital conservation buffer,
                          making the EFFECTIVE requirement 7.0% -
                          a real, commonly conflated nuance tested
                          explicitly below)
  Tier 1 ratio >= 6.0%
  Total Capital ratio >= 8.0%
  Leverage ratio >= 3.0%
  LCR (Liquidity Coverage Ratio) >= 100%

This is a balance-sheet-level concern, genuinely different from
every per-transaction package built today - it answers "is the bank
itself solvent enough to operate," not "should this transaction be
allowed."
"""

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP


CET1_MINIMUM = Decimal("4.50")
CAPITAL_CONSERVATION_BUFFER = Decimal("2.50")
CET1_EFFECTIVE_MINIMUM = CET1_MINIMUM + CAPITAL_CONSERVATION_BUFFER  # 7.00% - the real operating requirement
TIER1_MINIMUM = Decimal("6.00")
TOTAL_CAPITAL_MINIMUM = Decimal("8.00")
LEVERAGE_MINIMUM = Decimal("3.00")
LCR_MINIMUM = Decimal("100.00")


@dataclass
class Exposure:
    asset_class: str
    amount: Decimal


RISK_WEIGHTS = {
    "CASH_AND_SOVEREIGN": Decimal("0.00"),
    "RESIDENTIAL_MORTGAGE": Decimal("35.00"),
    "UNSECURED_RETAIL": Decimal("75.00"),
    "CORPORATE_LOAN": Decimal("100.00"),
    "UNRATED_CORPORATE": Decimal("150.00"),
}


def calculate_rwa(exposures: list[Exposure]) -> Decimal:
    """Risk-Weighted Assets - each exposure weighted by its asset
    class's real Basel risk weight, not treated as uniformly risky."""
    total = Decimal("0.00")
    for exp in exposures:
        weight = RISK_WEIGHTS[exp.asset_class]
        total += exp.amount * (weight / Decimal("100"))
    return total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def calculate_ratio(capital: Decimal, rwa: Decimal) -> Decimal:
    if rwa == 0:
        return Decimal("0.00")
    return (capital / rwa * Decimal("100")).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)


@dataclass
class ComplianceCheck:
    metric: str
    actual: Decimal
    minimum: Decimal
    compliant: bool


def check_capital_adequacy(cet1: Decimal, tier1: Decimal, total_capital: Decimal, rwa: Decimal,
                             total_exposure: Decimal, hqla: Decimal, net_outflows_30d: Decimal) -> list[ComplianceCheck]:

    cet1_ratio = calculate_ratio(cet1, rwa)
    tier1_ratio = calculate_ratio(tier1, rwa)
    total_ratio = calculate_ratio(total_capital, rwa)
    leverage_ratio = calculate_ratio(tier1, total_exposure)
    lcr = calculate_ratio(hqla, net_outflows_30d) if net_outflows_30d > 0 else Decimal("999.99")

    return [
        ComplianceCheck("CET1 (incl. conservation buffer)", cet1_ratio, CET1_EFFECTIVE_MINIMUM,
                         cet1_ratio >= CET1_EFFECTIVE_MINIMUM),
        ComplianceCheck("Tier 1", tier1_ratio, TIER1_MINIMUM, tier1_ratio >= TIER1_MINIMUM),
        ComplianceCheck("Total Capital", total_ratio, TOTAL_CAPITAL_MINIMUM, total_ratio >= TOTAL_CAPITAL_MINIMUM),
        ComplianceCheck("Leverage Ratio", leverage_ratio, LEVERAGE_MINIMUM, leverage_ratio >= LEVERAGE_MINIMUM),
        ComplianceCheck("LCR", lcr, LCR_MINIMUM, lcr >= LCR_MINIMUM),
    ]


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: RWA calculation across a genuinely mixed, realistic asset portfolio ===")
    exposures = [
        Exposure("CASH_AND_SOVEREIGN", Decimal("50000000.00")),      # 0% weight -> contributes 0 to RWA
        Exposure("RESIDENTIAL_MORTGAGE", Decimal("200000000.00")),   # 35% weight -> 70,000,000
        Exposure("UNSECURED_RETAIL", Decimal("30000000.00")),        # 75% weight -> 22,500,000
        Exposure("CORPORATE_LOAN", Decimal("100000000.00")),         # 100% weight -> 100,000,000
    ]
    rwa = calculate_rwa(exposures)
    print(f"Total RWA: ${rwa:,.2f}")
    expected_rwa = Decimal("192500000.00")  # 0 + 70M + 22.5M + 100M
    print(f"Matches hand-calculated expected value exactly: {rwa == expected_rwa} (expected: True)")

    print()
    print("=== TEST 2: A well-capitalized bank - passes every ratio ===")
    checks2 = check_capital_adequacy(
        cet1=Decimal("15000000.00"), tier1=Decimal("17000000.00"), total_capital=Decimal("20000000.00"),
        rwa=rwa, total_exposure=Decimal("400000000.00"),
        hqla=Decimal("30000000.00"), net_outflows_30d=Decimal("25000000.00"),
    )
    for c in checks2:
        print(f"  {c.metric}: {c.actual}% (min {c.minimum}%) - {'PASS' if c.compliant else 'FAIL'}")
    print(f"All checks pass: {all(c.compliant for c in checks2)} (expected: True)")

    print()
    print("=== TEST 3: THE conservation buffer nuance - a bank above the BARE 4.5% minimum but below the REAL 7.0% requirement ===")
    print("(this is a genuinely common point of confusion worth testing explicitly - many summaries")
    print(" cite only the bare Basel minimum, not the buffer-inclusive operating requirement)")
    marginal_cet1 = rwa * Decimal("0.05")  # exactly 5.00% of RWA - above 4.5%, below the real 7.0% requirement
    checks3 = check_capital_adequacy(
        cet1=marginal_cet1, tier1=marginal_cet1 + Decimal("2000000"), total_capital=marginal_cet1 + Decimal("5000000"),
        rwa=rwa, total_exposure=Decimal("400000000.00"),
        hqla=Decimal("30000000.00"), net_outflows_30d=Decimal("25000000.00"),
    )
    cet1_check = checks3[0]
    print(f"CET1 ratio: {cet1_check.actual}% (bare Basel minimum is {CET1_MINIMUM}%, but the REAL "
          f"effective requirement including the conservation buffer is {CET1_EFFECTIVE_MINIMUM}%)")
    print(f"Above the bare minimum: {cet1_check.actual >= CET1_MINIMUM} (expected: True)")
    print(f"Still correctly flagged as NON-compliant against the real, buffer-inclusive requirement: "
          f"{not cet1_check.compliant} (expected: True)")

    print()
    print("=== TEST 4: An UNDER-capitalized bank - correctly fails multiple ratios, not silently passed ===")
    checks4 = check_capital_adequacy(
        cet1=Decimal("3000000.00"), tier1=Decimal("3500000.00"), total_capital=Decimal("5000000.00"),
        rwa=rwa, total_exposure=Decimal("400000000.00"),
        hqla=Decimal("10000000.00"), net_outflows_30d=Decimal("25000000.00"),
    )
    failed_checks = [c for c in checks4 if not c.compliant]
    print(f"Number of failed checks: {len(failed_checks)} (expected: > 0)")
    for c in failed_checks:
        print(f"  FAILED: {c.metric} at {c.actual}% (needs {c.minimum}%)")

    print()
    print("=== TEST 5: LCR specifically - insufficient liquid assets to cover 30-day stress outflows ===")
    lcr_check = checks4[-1]
    print(f"LCR: {lcr_check.actual}% (minimum 100%) - compliant: {lcr_check.compliant} (expected: False - "
          f"only $10M HQLA against $25M of modeled 30-day outflows)")
