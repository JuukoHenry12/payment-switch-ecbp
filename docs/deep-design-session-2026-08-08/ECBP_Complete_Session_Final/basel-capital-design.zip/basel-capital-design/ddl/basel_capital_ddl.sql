-- ============================================================
-- ECBP Regulatory Capital (Basel III/IV) — DDL
-- ============================================================
-- Confirmed as its own distinct required category in today's
-- research ("risk and capital management" listed separately from
-- financial crime/AML). This is a balance-sheet-level concern,
-- genuinely different in nature from every per-transaction package
-- built today - it answers "is the bank itself solvent enough to
-- operate," not "should this transaction be allowed."
-- ============================================================

CREATE TABLE RISK_WEIGHT_TABLE (
    ASSET_CLASS               VARCHAR(30)    PRIMARY KEY,
    RISK_WEIGHT_PERCENT           DECIMAL(5,2) NOT NULL,   -- Basel standardized approach weights
    DESCRIPTION                       VARCHAR(200) NOT NULL
);

-- Standard Basel III/IV standardized-approach risk weights, well-
-- established and stable regulatory figures, not something that
-- changes week to week.
INSERT INTO RISK_WEIGHT_TABLE (ASSET_CLASS, RISK_WEIGHT_PERCENT, DESCRIPTION) VALUES
    ('CASH_AND_SOVEREIGN', 0.00, 'Cash and highly-rated sovereign debt'),
    ('RESIDENTIAL_MORTGAGE', 35.00, 'Residential mortgage, loan-to-value within standard limits'),
    ('UNSECURED_RETAIL', 75.00, 'Unsecured retail lending (credit cards, personal loans)'),
    ('CORPORATE_LOAN', 100.00, 'Standard corporate lending exposure'),
    ('UNRATED_CORPORATE', 150.00, 'Higher-risk / unrated corporate exposure');

CREATE TABLE CAPITAL_COMPONENT (
    COMPONENT_ID               VARCHAR(20)   PRIMARY KEY,
    COMPONENT_TYPE                 VARCHAR(10) NOT NULL,   -- CET1, AT1, T2
    AMOUNT                            DECIMAL(18,2) NOT NULL,
    AS_OF_DATE                           DATE     NOT NULL
);

CREATE TABLE CAPITAL_ADEQUACY_SNAPSHOT (
    SNAPSHOT_ID                UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    AS_OF_DATE                     DATE      NOT NULL,
    TOTAL_RWA                         DECIMAL(18,2) NOT NULL,
    CET1_RATIO                           DECIMAL(6,4) NOT NULL,
    TIER1_RATIO                             DECIMAL(6,4) NOT NULL,
    TOTAL_CAPITAL_RATIO                        DECIMAL(6,4) NOT NULL,
    LEVERAGE_RATIO                                DECIMAL(6,4) NOT NULL,
    LCR                                              DECIMAL(6,4) NOT NULL,
    OVERALL_COMPLIANT                                  BOOLEAN NOT NULL,
    COMPUTED_AT                                          TIMESTAMPTZ NOT NULL DEFAULT now()
);
