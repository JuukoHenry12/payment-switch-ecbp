# OTP & Email Services — Closing Two Real, Confirmed Gaps

## Direct answer to the question asked

**Before this package: no.** Confirmed by checking, not assuming: CUSTOMER_EMAIL existed as a declared channel type but was never once actually used in any real routing rule or test. OTP didn't exist anywhere at all — no generation, no verification, zero references across all 40 prior components.

## Why this matters — not a generic "nice to have"

This directly closes a gap open-banking-design's own README flagged explicitly: Strong Customer Authentication at the moment of payment initiation, required under PSD2/PSD3, was never built. Open Banking was one of only two packages built today specifically because it was a legal requirement — leaving SCA unbuilt meant that requirement was only half-closed.

## Files

```
ddl/otp_ddl.sql                         - OTP_CHALLENGE, with rate-limit-enabling indexing
service/otp_service.py                  - real OTP generation/verification, 7 tests
service/email_and_integrations.py       - email adapter + 2 real integrations, 5 tests
```

## Verified, working — 12 real scenarios total

OTP core (7 tests): generation and correct verification; proof the stored hash never reveals the real code (same discipline as card PIN storage); a wrong code correctly rejected and counted; lockout after 3 failed attempts, matching the card PIN lockout pattern exactly; a locked OTP staying locked even against the correct code afterward; expiry correctly enforced; and rate limiting — a 4th generation attempt within the window is correctly refused, defending against an attacker flooding a victim's phone with codes.

Email and integrations (5 tests): a real send through an injected provider; a provider failure correctly surfaced, not swallowed; proof CUSTOMER_EMAIL is now a genuinely exercised channel; and the two integrations that justify the whole package — Open Banking SCA and fraud step-up authentication, both run against the actual, unmodified classes from earlier packages, not simplified stand-ins.

## Why Test 4 is the most important result in this package

It doesn't just prove OTP works in isolation — it proves a Payment Initiation Service Provider with valid, granted consent from open-banking-design is now correctly required to complete a separate SCA challenge before a payment can proceed. Consent alone used to be sufficient; now it correctly isn't. That's the actual gap closed, not a generic feature added.

## Why Test 5 matters for the customer experience, not just security

The fraud engine's AMOUNT_THRESHOLD_EXCEEDED check previously meant one thing: decline. This integration shows the same check now issuing a step-up OTP instead — a real, verifiable "prove it's really you" path that lets a legitimate large transaction complete, rather than forcing every customer over the threshold to call support. Better security and a better outcome for genuine customers, from the same underlying check.

## How this connects to everything built today

```
Open Banking payment initiation (open-banking-design's consent check)
        |
        v
Consent GRANTED alone is no longer sufficient
        |
        v
OTPService.generate(purpose=PAYMENT_SCA) - delivered via EmailAdapter
or SMS, same routing logic as notification-design
        |
        v
Customer completes the OTP -> payment proceeds

Separately: card-design's fraud check, AMOUNT_THRESHOLD_EXCEEDED
        |
        v
OTPService.generate(purpose=STEP_UP_AUTH) instead of a flat decline
        |
        v
Same OTPChallenge, same hash storage, same lockout discipline as
card-issuance-design's PIN system - one consistent security pattern
reused across three genuinely different use cases
```

## Honest limitations

Real SMS/email provider connectivity (Twilio, SES, an actual carrier gateway) is not built — the delivery interface is real and tested, the live connection is injected, same boundary drawn for every genuinely external dependency today. Voice-call OTP delivery (a real accessibility requirement for some customers) is not built. Biometric or app-based push authentication as SCA alternatives to OTP are not addressed — OTP is one valid SCA factor among several PSD2 permits, not the only one a complete implementation would eventually need.
