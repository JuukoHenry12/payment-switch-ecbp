-- ============================================================
-- ECBP OTP Service — DDL
-- ============================================================
-- Closes a real, self-flagged gap: open-banking-design's own README
-- named Strong Customer Authentication at payment initiation as not
-- built. This is that missing piece, plus the general-purpose OTP
-- capability login and fraud step-up authentication both need.
-- ============================================================

CREATE TABLE OTP_CHALLENGE (
    OTP_ID                    UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    ACCOUNT_ID                    VARCHAR(20) NOT NULL,
    PURPOSE                          VARCHAR(20) NOT NULL,  -- LOGIN, PAYMENT_SCA, STEP_UP_AUTH
    OTP_HASH                           VARCHAR(64) NOT NULL,  -- SHA-256, never plaintext - same principle as PIN storage
    DELIVERY_CHANNEL                      VARCHAR(10) NOT NULL,  -- SMS, EMAIL
    STATUS                                   VARCHAR(20) NOT NULL DEFAULT 'PENDING',  -- PENDING, VERIFIED, EXPIRED, LOCKED
    ATTEMPT_COUNT                              SMALLINT NOT NULL DEFAULT 0,
    CREATED_AT                                   TIMESTAMPTZ NOT NULL DEFAULT now(),
    EXPIRES_AT                                     TIMESTAMPTZ NOT NULL
);

CREATE INDEX IDX_OTP_ACCOUNT ON OTP_CHALLENGE (ACCOUNT_ID, CREATED_AT);
-- Enables rate-limit checks: "how many OTPs has this account
-- requested in the last N minutes" - a real, necessary defense
-- against OTP-spam abuse (flooding a victim's phone with codes).
