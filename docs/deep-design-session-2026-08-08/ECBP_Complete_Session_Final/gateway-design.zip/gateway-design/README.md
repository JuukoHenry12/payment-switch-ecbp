# API Gateway — Auth & Rate Limiting Design Package

## What this closes

`api-gateway` was named constantly throughout today (JWT/OAuth2, rate limiting, the mTLS-enforcing entry point every other service assumed sits in front of it) but never actually built. This package genuinely implements and tests its two core responsibilities.

## Files

```
service/api_gateway_auth.py   - real HMAC-signed JWT issuance/verification + role-based authorization, 6 tests
service/rate_limiter.py       - token bucket rate limiter, 5 tests against real timing behavior
```

## Verified, working — 11 real tests total, zero bugs found this round

**JWT auth (6 tests):** genuine cryptographic round-trip, a tampered signature correctly rejected, an expired token correctly rejected, and role-based authorization enforcing the CUSTOMER/TELLER/ADMIN/AUDITOR split from the earlier frontend design — including the real banking separation-of-duties principle explicitly proven: an AUDITOR can view reconciliation breaks but is correctly denied initiating a transfer. Auditors see everything, do nothing — that's not incidental, it's a deliberate, tested control.

**Rate limiter (5 tests):** burst capacity works correctly, the 11th request in the same instant is correctly rejected, refill precisely matches the configured rate after simulated time passes, different clients have genuinely independent buckets (one client's exhaustion never affects another), and the bucket correctly caps at capacity rather than accumulating unbounded tokens during a long idle period.

## Why the rate limiter test matters as a testing pattern, not just a result

It uses a controllable simulated clock (`now: float` passed explicitly) rather than real `time.sleep()` calls. This is a small but important design choice: it makes the test suite run instantly while still genuinely exercising real time-based refill logic — the same reason the reconciliation engine's timeout sweep earlier today was tested the same way, using `Instant` values rather than actually waiting.

## How this ties into everything built today

```
Every incoming request
        │
        ▼
api-gateway: RateLimiter.allow_request() — per-client, independent buckets
        │
        ▼
api-gateway: verify_token() — real signature + expiry check
        │
        ▼
api-gateway: authorize() — role check against the requested action
        │
        ▼
Routed to the appropriate service (account-service, payment-service,
risk-service, etc.) — everything built today assumed this boundary
already existed; it now genuinely does
```

## Honest limitation

`SECRET_KEY` here is a placeholder string, explicitly commented as "would be in HSM/KMS in production" — this reuses the exact same envelope-encryption/key-management principle proven in the security-design package earlier today, not a new pattern. A real deployment would fetch this from SoftHSM/KMS at startup, never hardcode it.
