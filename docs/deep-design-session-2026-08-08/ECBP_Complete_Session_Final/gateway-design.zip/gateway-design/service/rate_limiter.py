"""
rate_limiter.py — a token bucket rate limiter, the second core
responsibility of api-gateway named throughout today's design
(mentioned in the enterprise architecture document, never built).
Tested against genuine timing behavior using a controllable clock,
not just call-count assertions - a rate limiter that isn't tested
against real time passing hasn't actually been tested.
"""

from dataclasses import dataclass


@dataclass
class TokenBucket:
    capacity: int
    tokens: float
    refill_rate_per_second: float
    last_refill_time: float


class RateLimiter:
    """
    Per-client token bucket. Each client (identified by API key or
    JWT subject) gets its own bucket - this is deliberately NOT a
    single global rate limit, since the whole point is preventing one
    noisy or abusive client from affecting others' available
    throughput.
    """

    def __init__(self):
        self.buckets: dict[str, TokenBucket] = {}

    def _get_or_create_bucket(self, client_id: str, capacity: int, refill_rate: float, now: float) -> TokenBucket:
        if client_id not in self.buckets:
            self.buckets[client_id] = TokenBucket(
                capacity=capacity, tokens=capacity, refill_rate_per_second=refill_rate, last_refill_time=now)
        return self.buckets[client_id]

    def allow_request(self, client_id: str, now: float, capacity: int = 10, refill_rate: float = 2.0) -> bool:
        """
        Returns True if the request is allowed (and consumes a
        token), False if the client is currently rate-limited.
        capacity=10, refill_rate=2.0 means: burst up to 10 requests
        immediately, then sustain roughly 2 requests/second thereafter.
        """
        bucket = self._get_or_create_bucket(client_id, capacity, refill_rate, now)

        elapsed = now - bucket.last_refill_time
        bucket.tokens = min(bucket.capacity, bucket.tokens + elapsed * bucket.refill_rate_per_second)
        bucket.last_refill_time = now

        if bucket.tokens >= 1:
            bucket.tokens -= 1
            return True
        return False


# ------------------------------------------------------------
# REAL TESTS - using a controllable simulated clock, not wall-clock
# sleep(), so the test runs instantly but genuinely exercises real
# time-based refill behavior.
# ------------------------------------------------------------
if __name__ == "__main__":

    limiter = RateLimiter()
    client = "client-abc"

    print("=== TEST 1: Burst capacity - first 10 requests in the same instant all succeed ===")
    t = 0.0
    results = [limiter.allow_request(client, now=t, capacity=10, refill_rate=2.0) for _ in range(10)]
    print(f"All 10 burst requests allowed: {all(results)} (expected: True)")

    print()
    print("=== TEST 2: The 11th request, still at the same instant, is correctly rejected ===")
    result_11 = limiter.allow_request(client, now=t, capacity=10, refill_rate=2.0)
    print(f"11th request allowed: {result_11} (expected: False - bucket is empty)")

    print()
    print("=== TEST 3: After waiting 1 simulated second, exactly 2 more tokens have refilled ===")
    t += 1.0
    allowed_after_1s = [limiter.allow_request(client, now=t, capacity=10, refill_rate=2.0) for _ in range(3)]
    print(f"Results for 3 attempts after 1s: {allowed_after_1s} (expected: [True, True, False] - "
          f"refill_rate=2.0/sec means exactly 2 new tokens after 1 second)")

    print()
    print("=== TEST 4: Different clients have COMPLETELY independent buckets ===")
    other_client = "client-xyz"
    other_client_first_request = limiter.allow_request(other_client, now=t, capacity=10, refill_rate=2.0)
    print(f"A brand new client, even at the same instant client-abc is exhausted, is allowed: "
          f"{other_client_first_request} (expected: True - independent bucket)")

    print()
    print("=== TEST 5: After a long wait, the bucket refills up to its capacity but never beyond ===")
    t += 100.0  # way more than enough time to fully refill at 2/sec
    limiter.allow_request(client, now=t, capacity=10, refill_rate=2.0)  # trigger a refill calculation
    bucket_state = limiter.buckets[client]
    print(f"Tokens after a long wait (should cap at capacity, not grow unbounded): "
          f"{bucket_state.tokens} (expected: 9.0, since capacity=10 and we just consumed 1)")
    print(f"Correctly capped at capacity, not accumulated beyond it: {bucket_state.tokens <= 10}")
