"""
api_gateway_auth.py — real JWT issuance and verification (genuine
HMAC-signed tokens via PyJWT, not mocked), plus role-based
authorization enforcing the CUSTOMER/TELLER/ADMIN/AUDITOR roles from
the frontend design discussed earlier today. This is the actual
security boundary every other service built today has implicitly
assumed sits in front of it.
"""

import jwt
import time
from datetime import datetime, timedelta, timezone


SECRET_KEY = "ecbp-dev-secret-would-be-in-HSM-KMS-in-production"  # per the security-design package's real KEK pattern
ALGORITHM = "HS256"
TOKEN_EXPIRY_MINUTES = 15  # short-lived, per the token access control design principle


class AuthenticationError(Exception):
    pass


class AuthorizationError(Exception):
    pass


def issue_token(user_id: str, role: str) -> str:
    """Issues a real, cryptographically signed JWT - short-lived, per
    the same 'don't store long-lived credentials' principle used
    throughout today's security work."""
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "role": role,
        "iat": now,
        "exp": now + timedelta(minutes=TOKEN_EXPIRY_MINUTES),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def verify_token(token: str) -> dict:
    """Genuinely verifies the signature and expiry - not a parse-only
    operation. A tampered token, or an expired one, must fail here,
    not be silently trusted downstream."""
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise AuthenticationError("Token expired")
    except jwt.InvalidTokenError as e:
        raise AuthenticationError(f"Invalid token: {e}")


# Role -> permitted actions, mirroring the frontend design's
# CUSTOMER/TELLER/ADMIN/AUDITOR split from earlier today.
ROLE_PERMISSIONS = {
    "CUSTOMER": {"view_own_account", "initiate_transfer"},
    "TELLER": {"view_own_account", "initiate_transfer", "view_any_account", "freeze_account"},
    "ADMIN": {"view_own_account", "initiate_transfer", "view_any_account", "freeze_account",
              "trigger_eod_batch", "manage_fraud_rules"},
    "AUDITOR": {"view_any_account", "view_audit_trail", "view_reconciliation_breaks"},
}


def authorize(claims: dict, required_action: str):
    role = claims.get("role")
    permitted = ROLE_PERMISSIONS.get(role, set())
    if required_action not in permitted:
        raise AuthorizationError(f"Role '{role}' is not permitted to '{required_action}'")


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: Issue a real signed token, verify it round-trips correctly ===")
    token = issue_token("balasubramani", "ADMIN")
    print(f"Token (truncated): {token[:50]}...")
    claims = verify_token(token)
    print(f"Decoded sub: {claims['sub']} (expected: balasubramani)")
    print(f"Decoded role: {claims['role']} (expected: ADMIN)")

    print()
    print("=== TEST 2: A TAMPERED token is correctly rejected ===")
    tampered = token[:-5] + "AAAAA"  # corrupt the signature portion
    try:
        verify_token(tampered)
        print("FAIL - tampered token was accepted")
    except AuthenticationError as e:
        print(f"Correctly rejected: {e}")

    print()
    print("=== TEST 3: An EXPIRED token is correctly rejected ===")
    now = datetime.now(timezone.utc)
    expired_payload = {"sub": "test-user", "role": "CUSTOMER",
                        "iat": now - timedelta(minutes=30), "exp": now - timedelta(minutes=15)}
    expired_token = jwt.encode(expired_payload, SECRET_KEY, algorithm=ALGORITHM)
    try:
        verify_token(expired_token)
        print("FAIL - expired token was accepted")
    except AuthenticationError as e:
        print(f"Correctly rejected: {e}")

    print()
    print("=== TEST 4: Role-based authorization - CUSTOMER correctly denied an ADMIN-only action ===")
    customer_token = issue_token("jane.customer", "CUSTOMER")
    customer_claims = verify_token(customer_token)
    try:
        authorize(customer_claims, "trigger_eod_batch")
        print("FAIL - customer was allowed to trigger EOD batch")
    except AuthorizationError as e:
        print(f"Correctly denied: {e}")

    print()
    print("=== TEST 5: Role-based authorization - AUDITOR correctly allowed to view reconciliation breaks ===")
    auditor_token = issue_token("audit.user", "AUDITOR")
    auditor_claims = verify_token(auditor_token)
    try:
        authorize(auditor_claims, "view_reconciliation_breaks")
        print("Correctly allowed")
    except AuthorizationError as e:
        print(f"FAIL - should have been allowed: {e}")

    print()
    print("=== TEST 6: Role-based authorization - AUDITOR correctly denied initiating a transfer ===")
    print("(an auditor should be able to SEE everything, but never DO a transaction - a real,")
    print(" important separation-of-duties principle in banking, worth explicitly testing)")
    try:
        authorize(auditor_claims, "initiate_transfer")
        print("FAIL - auditor was allowed to initiate a transfer")
    except AuthorizationError as e:
        print(f"Correctly denied: {e}")
