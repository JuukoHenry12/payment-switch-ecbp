-- ============================================================
-- ECBP Card Issuance — DDL
-- ============================================================
-- Extends card-design (this afternoon, card AUTHORIZATION) with
-- card ISSUANCE - a genuinely distinct capability: creating a new
-- card in the first place, not using one that already exists.
-- ============================================================

CREATE TABLE CARD (
    CARD_ID                   VARCHAR(20)    PRIMARY KEY,
    ACCOUNT_ID                    VARCHAR(20) NOT NULL,   -- links to Phase 1's ACCOUNT table
    CARD_TOKEN                       VARCHAR(19) NOT NULL, -- the PERSISTENT token from token-lifecycle-design
    CARD_TYPE                           VARCHAR(10) NOT NULL,  -- VIRTUAL, PHYSICAL
    STATUS                                 VARCHAR(20) NOT NULL,  -- PENDING_ACTIVATION, ACTIVE, BLOCKED, EXPIRED
    PIN_HASH                                  VARCHAR(64) NULL,   -- SHA-256, never plaintext, never reversible
    FAILED_PIN_ATTEMPTS                          SMALLINT NOT NULL DEFAULT 0,
    ISSUED_AT                                       TIMESTAMPTZ NOT NULL DEFAULT now(),
    ACTIVATED_AT                                      TIMESTAMPTZ NULL,
    EXPIRES_AT                                          DATE     NOT NULL,
    BLOCKED_REASON                                        VARCHAR(100) NULL
);

CREATE INDEX IDX_CARD_ACCOUNT ON CARD (ACCOUNT_ID);
CREATE INDEX IDX_CARD_TOKEN ON CARD (CARD_TOKEN);

-- Real security requirement: PIN retry limit. After
-- MAX_PIN_ATTEMPTS consecutive failures, the card locks itself -
-- enforced in application logic (card_issuance_service.py), not
-- left as a soft convention.
