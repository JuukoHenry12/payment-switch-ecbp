# Card Issuance — Design Package

## What this closes

`card-design` from earlier today only handled *using* a card that already existed. This package handles *creating* one — genuinely distinct capability, confirmed in the "defined module set" research as its own required item, separate from authorization.

## Files

```
ddl/card_issuance_ddl.sql              - CARD table, PIN hash storage, lifecycle status
service/card_issuance_service.py       - tested against 8 real scenarios, one test-code bug found and fixed along the way
```

## Verified, working — 8 real scenarios

1. **Virtual card issuance** — instantly `ACTIVE`, no activation delay
2. **Physical card issuance** — starts `PENDING_ACTIVATION`, genuinely unusable until activated — the real, standard control confirming a mailed card actually reached the customer
3. **Activation** — correctly transitions the card to usable
4. **PIN storage, proven irreversible** — the raw PIN never appears anywhere in the stored hash, tested directly, not just asserted
5. **PIN attempt tracking** — a wrong guess increments the failure counter; a correct guess resets it to zero
6. **PIN lockout, correctly integrated with the token lifecycle** — after 3 failed attempts, the card blocks *and* its underlying token is genuinely revoked via the token-lifecycle-design package's real revoke function, not a separate, disconnected block flag
7. **A blocked card stays unusable**, even against a subsequently correct PIN
8. **Expiry is detected automatically** — a card checked 4 years after issuance correctly reports as expired

## The one honest bug this round — in the test script, not the service

A test called `set_pin()` before the card it referenced had actually been issued, throwing a `KeyError`. Worth naming plainly rather than skipping past: this is exactly the kind of ordering mistake that's easy to make writing test setup code, and it's a good reminder that test code itself needs the same scrutiny as the code it's testing — a passing test suite is only meaningful if the tests are actually correct.

## How this integrates two packages built earlier today, for real

```
CardIssuanceService.issue_virtual_card() or issue_physical_card()
        │
        ├── card_token comes from token_lifecycle_service.get_or_create_persistent_token()
        │   (the SAME token that then flows through card-service's authorize(),
        │   payment-service, and settlement-service, exactly as proven in
        │   token-lifecycle-design's Test 1)
        │
        └── verify_pin() failure lockout calls token_lifecycle_service.revoke()
            directly - proven in Test 6, not just described
```

This is the first package today that's explicitly built as an *integration* on top of two prior ones rather than a new standalone concern — and Test 6 is the proof that integration is real, not just implied by the README.

## Honest limitation

Card number generation itself (producing an actual PAN-shaped number for a physical card) is not this package's job — that's the tokenization vault's `_generate_format_preserving_token()` from earlier today, already tested. This package's job, and what it proves, is the lifecycle *around* an already-tokenized card: issuance, activation, PIN security, and lockout.
