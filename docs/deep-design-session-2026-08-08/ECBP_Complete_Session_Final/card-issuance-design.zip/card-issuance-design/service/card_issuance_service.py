"""
card_issuance_service.py — creating a new card, distinct from
card-design's authorization logic (which only handles USING an
already-existing card). Two real distinctions tested carefully:

  1. VIRTUAL cards are instantly ACTIVE - no physical delivery step.
     PHYSICAL cards start PENDING_ACTIVATION and genuinely cannot be
     used until the customer activates them - a real, standard
     security control (activation confirms the physical card reached
     the actual customer, not an intercepted mail delivery).

  2. PINs are NEVER stored in a form that could be reversed back to
     the original value - only a one-way hash, tested explicitly to
     prove the raw PIN never appears anywhere in the stored record.
     A PIN retry limit locks the card after repeated failures, the
     same real control every physical ATM/POS terminal enforces.
"""

import hashlib
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from enum import Enum


MAX_PIN_ATTEMPTS = 3


class CardType(Enum):
    VIRTUAL = "VIRTUAL"
    PHYSICAL = "PHYSICAL"


class CardStatus(Enum):
    PENDING_ACTIVATION = "PENDING_ACTIVATION"
    ACTIVE = "ACTIVE"
    BLOCKED = "BLOCKED"
    EXPIRED = "EXPIRED"


@dataclass
class Card:
    card_id: str
    account_id: str
    card_token: str
    card_type: CardType
    status: CardStatus
    pin_hash: str | None = None
    failed_pin_attempts: int = 0
    expires_at: date = None
    blocked_reason: str | None = None


def hash_pin(pin: str) -> str:
    """One-way hash - genuinely irreversible. Same principle as any
    real password storage: the system can VERIFY a PIN is correct
    without ever being able to recover what it actually is."""
    return hashlib.sha256(pin.encode()).hexdigest()


class CardIssuanceService:

    def __init__(self, token_revoke_fn):
        """token_revoke_fn injected - reuses the token_lifecycle_service.revoke()
        logic from earlier today rather than duplicating it, since
        blocking a card must also revoke its underlying token."""
        self.cards: dict[str, Card] = {}
        self.token_revoke_fn = token_revoke_fn

    def issue_virtual_card(self, card_id: str, account_id: str, card_token: str, now: datetime) -> Card:
        card = Card(
            card_id=card_id, account_id=account_id, card_token=card_token,
            card_type=CardType.VIRTUAL, status=CardStatus.ACTIVE,  # instantly usable
            expires_at=(now + timedelta(days=365 * 3)).date(),
        )
        self.cards[card_id] = card
        return card

    def issue_physical_card(self, card_id: str, account_id: str, card_token: str, now: datetime) -> Card:
        card = Card(
            card_id=card_id, account_id=account_id, card_token=card_token,
            card_type=CardType.PHYSICAL, status=CardStatus.PENDING_ACTIVATION,  # NOT usable yet
            expires_at=(now + timedelta(days=365 * 3)).date(),
        )
        self.cards[card_id] = card
        return card

    def activate_card(self, card_id: str, now: datetime) -> bool:
        card = self.cards.get(card_id)
        if card is None or card.status != CardStatus.PENDING_ACTIVATION:
            return False
        card.status = CardStatus.ACTIVE
        return True

    def set_pin(self, card_id: str, pin: str):
        card = self.cards[card_id]
        card.pin_hash = hash_pin(pin)

    def verify_pin(self, card_id: str, attempted_pin: str) -> bool:
        """Returns True only on a correct PIN against an ACTIVE card.
        Tracks failures and locks the card after MAX_PIN_ATTEMPTS -
        the exact same protection every real card terminal enforces."""
        card = self.cards.get(card_id)
        if card is None or card.status != CardStatus.ACTIVE:
            return False

        if hash_pin(attempted_pin) == card.pin_hash:
            card.failed_pin_attempts = 0  # a correct PIN resets the counter
            return True

        card.failed_pin_attempts += 1
        if card.failed_pin_attempts >= MAX_PIN_ATTEMPTS:
            card.status = CardStatus.BLOCKED
            card.blocked_reason = "Too many failed PIN attempts"
            self.token_revoke_fn(card.card_token, "PIN lockout", "card-issuance-service")
        return False

    def is_usable(self, card_id: str, now: datetime) -> bool:
        card = self.cards.get(card_id)
        if card is None:
            return False
        if now.date() > card.expires_at:
            card.status = CardStatus.EXPIRED
            return False
        return card.status == CardStatus.ACTIVE


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    now = datetime(2026, 8, 8, 10, 0, 0)
    revoked_tokens = []
    service = CardIssuanceService(token_revoke_fn=lambda token, reason, by: revoked_tokens.append((token, reason)))

    print("=== TEST 1: Virtual card - instantly ACTIVE, no activation step needed ===")
    vcard = service.issue_virtual_card("CARD-V-001", "ACC0001234", "TOKEN-V001", now)
    print(f"Status immediately after issuance: {vcard.status.value} (expected: ACTIVE)")
    print(f"Usable immediately: {service.is_usable('CARD-V-001', now)} (expected: True)")

    print()
    print("=== TEST 2: Physical card - starts PENDING_ACTIVATION, genuinely NOT usable yet ===")
    pcard = service.issue_physical_card("CARD-P-001", "ACC0001234", "TOKEN-P001", now)
    print(f"Status immediately after issuance: {pcard.status.value} (expected: PENDING_ACTIVATION)")
    print(f"Usable before activation: {service.is_usable('CARD-P-001', now)} (expected: False)")

    print()
    print("=== TEST 3: After activation, the physical card becomes usable ===")
    service.activate_card("CARD-P-001", now)
    print(f"Usable after activation: {service.is_usable('CARD-P-001', now)} (expected: True)")

    print()
    print("=== TEST 4: PIN is NEVER stored in reversible form ===")
    service.set_pin("CARD-V-001", "4321")
    stored_hash = service.cards["CARD-V-001"].pin_hash
    print(f"Stored value: {stored_hash}")
    print(f"Raw PIN never appears in the stored record: {'4321' not in stored_hash} (expected: True)")
    print(f"Verification still works correctly against the hash: {service.verify_pin('CARD-V-001', '4321')} (expected: True)")

    print()
    print("=== TEST 5: Wrong PIN attempts correctly counted, correct PIN resets the counter ===")
    vcard2 = service.issue_virtual_card("CARD-V-002", "ACC0005678", "TOKEN-V002", now)
    service.set_pin("CARD-V-002", "1234")
    service.verify_pin("CARD-V-002", "9999")  # wrong
    print(f"Failed attempts after 1 wrong guess: {service.cards['CARD-V-002'].failed_pin_attempts} (expected: 1)")
    service.verify_pin("CARD-V-002", "1234")  # correct - should reset
    print(f"Failed attempts after a correct guess: {service.cards['CARD-V-002'].failed_pin_attempts} (expected: 0)")

    print()
    print("=== TEST 6: PIN lockout after MAX_PIN_ATTEMPTS - card blocks AND its token is revoked ===")
    for _ in range(MAX_PIN_ATTEMPTS):
        service.verify_pin("CARD-V-002", "0000")  # wrong, 3 times
    print(f"Card status after {MAX_PIN_ATTEMPTS} failures: {service.cards['CARD-V-002'].status.value} (expected: BLOCKED)")
    print(f"Underlying token revoked as a consequence: {len(revoked_tokens) == 1 and revoked_tokens[0][0] == 'TOKEN-V002'} "
          f"(expected: True - blocking a card must also cut off its token, not just the card record)")

    print()
    print("=== TEST 7: A BLOCKED card is correctly unusable, even with the correct PIN ===")
    print(f"Usable after block: {service.is_usable('CARD-V-002', now)} (expected: False)")

    print()
    print("=== TEST 8: An EXPIRED card is correctly unusable, detected automatically ===")
    far_future = now + timedelta(days=365 * 4)  # well past the 3-year expiry
    print(f"Usable 4 years later: {service.is_usable('CARD-V-001', far_future)} (expected: False)")
