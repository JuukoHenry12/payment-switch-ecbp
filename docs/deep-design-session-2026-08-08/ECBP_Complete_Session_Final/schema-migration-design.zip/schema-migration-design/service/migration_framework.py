"""
migration_framework.py — closes the identified gap directly: no
version-number tracking existed, and the "widen a field, what could
go wrong" question was never actually tested. This does both: a real
MigrationRunner tracking versions and checksums, and two scenarios
run against the SAME realistic situation - a naive single-shot widen
that genuinely corrupts data downstream, and the correct
Expand-Contract pattern that doesn't.

The scenario: CARD.BLOCKED_REASON needs to widen from VARCHAR(100)
to VARCHAR(200) - the exact example used in the explanation - and a
downstream fixed-width CTR/SAR-style report export (built on the
same fixed-width principle as reporting-design earlier today)
depends on that column's width.
"""

import hashlib
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Migration:
    version: str
    description: str
    migration_type: str  # EXPAND, MIGRATE, CUTOVER, CONTRACT
    script: str


@dataclass
class MigrationRecord:
    version: str
    description: str
    migration_type: str
    checksum: str
    applied_at: datetime


class MigrationRunner:
    """
    The real version-tracking mechanism, applied in order, with
    checksum drift detection - if someone hand-edits a migration file
    AFTER it's already been recorded as applied, this catches it,
    rather than silently trusting the file on disk.
    """

    def __init__(self):
        self.applied: dict[str, MigrationRecord] = {}

    def _checksum(self, script: str) -> str:
        return hashlib.sha256(script.encode()).hexdigest()

    def apply(self, migration: Migration, applied_by: str, now: datetime) -> bool:
        if migration.version in self.applied:
            existing = self.applied[migration.version]
            new_checksum = self._checksum(migration.script)
            if existing.checksum != new_checksum:
                raise RuntimeError(
                    f"DRIFT DETECTED: migration {migration.version} was already applied with a "
                    f"different checksum. The migration file was edited after being applied - "
                    f"this is exactly the kind of silent inconsistency that must be caught, not ignored.")
            return False  # already applied, correctly a no-op

        record = MigrationRecord(
            version=migration.version, description=migration.description,
            migration_type=migration.migration_type,
            checksum=self._checksum(migration.script), applied_at=now,
        )
        self.applied[migration.version] = record
        return True

    def current_version(self) -> str | None:
        if not self.applied:
            return None
        return max(self.applied.keys())


# ------------------------------------------------------------
# The realistic downstream dependency: a fixed-width report export
# that assumes BLOCKED_REASON is exactly 100 characters
# ------------------------------------------------------------
def render_fixed_width_report_line(account_id: str, blocked_reason: str, field_width: int = 100) -> str:
    """
    Same principle as reporting-design's regulatory report generation -
    a real fixed-width export format, the kind commonly required for
    batch regulatory submissions. If blocked_reason exceeds field_width,
    THIS is where a naive DB widen shows up as real data corruption.
    """
    if len(blocked_reason) > field_width:
        truncated = blocked_reason[:field_width]
        return f"{account_id:<20}{truncated}"  # SILENT TRUNCATION - the real failure mode
    return f"{account_id:<20}{blocked_reason:<{field_width}}"


# ------------------------------------------------------------
# SCENARIO A: the naive, single-shot widen - proving the real failure
# ------------------------------------------------------------
class SimulatedDatabaseNaive:
    """Models a naive widen: the DB column is simply widened in one
    step, with no coordination for downstream consumers."""

    def __init__(self):
        self.blocked_reason_max_length = 100  # starts at the OLD width

    def widen_column_naive(self):
        self.blocked_reason_max_length = 200  # NAIVE: just changes it, nothing else coordinated

    def write_blocked_reason(self, value: str) -> str:
        if len(value) > self.blocked_reason_max_length:
            raise ValueError(f"Value exceeds column width {self.blocked_reason_max_length}")
        return value  # accepted as-is, full length


# ------------------------------------------------------------
# SCENARIO B: the correct Expand-Contract pattern
# ------------------------------------------------------------
class SimulatedDatabaseExpandContract:
    """Models the correct pattern: OLD column stays untouched during
    the transition, NEW column added alongside it, dual-write during
    MIGRATE, only CONTRACT removes the old column - and only once
    every consumer is confirmed migrated."""

    def __init__(self):
        self.blocked_reason_old = {}   # VARCHAR(100), untouched during transition
        self.blocked_reason_new = {}   # VARCHAR(200), the new column
        self.phase = "EXPAND"

    def expand(self):
        self.phase = "EXPAND"  # new column exists, nothing reads or writes it yet

    def migrate(self):
        self.phase = "MIGRATE"  # dual-write begins

    def cutover(self):
        self.phase = "CUTOVER"  # reads switch to new column

    def contract(self):
        self.phase = "CONTRACT"
        self.blocked_reason_old = {}  # old column genuinely dropped, only now

    def write_blocked_reason(self, account_id: str, value: str):
        if self.phase in ("EXPAND", "MIGRATE"):
            # OLD column ALWAYS gets a safely truncated value during
            # the transition - old consumers reading it are NEVER
            # exposed to an over-length value, by construction.
            self.blocked_reason_old[account_id] = value[:100]
        if self.phase in ("MIGRATE", "CUTOVER"):
            self.blocked_reason_new[account_id] = value  # full-length, new column

    def read_for_old_consumer(self, account_id: str) -> str:
        return self.blocked_reason_old.get(account_id, "")

    def read_for_new_consumer(self, account_id: str) -> str:
        if self.phase == "CUTOVER":
            return self.blocked_reason_new.get(account_id, "")
        return self.blocked_reason_old.get(account_id, "")


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    now = datetime(2026, 8, 9, 14, 0, 0)

    print("=== TEST 1: Migration runner - real version tracking ===")
    runner = MigrationRunner()
    m1 = Migration("V12", "Add BLOCKED_REASON_V2 column (EXPAND)", "EXPAND",
                    "ALTER TABLE CARD ADD COLUMN BLOCKED_REASON_V2 VARCHAR(200);")
    applied1 = runner.apply(m1, applied_by="ci-cd-pipeline", now=now)
    print(f"Migration applied: {applied1} (expected: True)")
    print(f"Current version: {runner.current_version()} (expected: V12)")

    print()
    print("=== TEST 2: Re-applying the SAME migration is a safe no-op ===")
    applied2 = runner.apply(m1, applied_by="ci-cd-pipeline", now=now)
    print(f"Re-applied: {applied2} (expected: False - already applied, correctly skipped)")

    print()
    print("=== TEST 3: DRIFT DETECTION - a hand-edited migration file is caught, not silently trusted ===")
    m1_edited = Migration("V12", "Add BLOCKED_REASON_V2 column (EXPAND)", "EXPAND",
                           "ALTER TABLE CARD ADD COLUMN BLOCKED_REASON_V2 VARCHAR(500);")  # someone changed 200->500 after the fact
    try:
        runner.apply(m1_edited, applied_by="someone-editing-a-file-later", now=now)
        print("FAIL - drift was not caught")
    except RuntimeError as e:
        print(f"Correctly caught: {e}")

    print()
    print("=== TEST 4: SCENARIO A - the naive widen, proving the real downstream failure ===")
    naive_db = SimulatedDatabaseNaive()
    print(f"Before widen, max length: {naive_db.blocked_reason_max_length}")

    naive_db.widen_column_naive()
    print(f"After naive widen, max length: {naive_db.blocked_reason_max_length}")

    long_reason = "Card reported stolen following a series of suspicious international transactions flagged by the fraud engine"
    print(f"New reason length: {len(long_reason)} chars")
    written = naive_db.write_blocked_reason(long_reason)
    print(f"DB accepted it fine: {len(written)} chars stored")

    report_line = render_fixed_width_report_line("ACC0001234", written, field_width=100)
    print(f"Downstream fixed-width report line: '{report_line[:40]}...'")
    print(f"REAL CORRUPTION: report line silently truncated the reason to 100 chars: "
          f"{len(report_line) - 20 == 100 and len(written) > 100} (expected: True - "
          f"the DB widen succeeded, but the DOWNSTREAM REPORT still assumed the old width, and")
    print(f"nobody coordinated that - this is the real, concrete failure a naive widen causes)")

    print()
    print("=== TEST 5: SCENARIO B - the SAME situation, done correctly via Expand-Contract ===")
    ec_db = SimulatedDatabaseExpandContract()

    print("--- EXPAND phase: new column exists, old consumers completely unaffected ---")
    ec_db.expand()
    ec_db.write_blocked_reason("ACC0005678", long_reason)
    old_read = ec_db.read_for_old_consumer("ACC0005678")
    print(f"Old consumer reads: '{old_read}' (length {len(old_read)}, expected: 100 - safely truncated, "
          f"never silently corrupted, because the OLD column was NEVER widened)")

    print()
    print("--- MIGRATE phase: dual-write begins, both old and new consumers work correctly ---")
    ec_db.migrate()
    ec_db.write_blocked_reason("ACC0005678", long_reason)
    old_read2 = ec_db.read_for_old_consumer("ACC0005678")
    new_read2 = ec_db.read_for_new_consumer("ACC0005678")
    print(f"Old consumer still reads: {len(old_read2)} chars (expected: 100, still safe)")
    print(f"New consumer reads OLD column still, since CUTOVER hasn't happened yet: {len(new_read2)} chars "
          f"(expected: 100 - genuinely proves the new consumer isn't exposed to the new data prematurely)")

    print()
    print("--- CUTOVER phase: new consumers switch to the full-length column ---")
    ec_db.cutover()
    new_read3 = ec_db.read_for_new_consumer("ACC0005678")
    print(f"New consumer now reads: {len(new_read3)} chars (expected: {len(long_reason)}, the FULL value)")
    old_read3 = ec_db.read_for_old_consumer("ACC0005678")
    print(f"Old consumer, if it's STILL running an old deploy, still safely reads: {len(old_read3)} chars "
          f"(expected: 100 - old consumers are NEVER broken during the entire transition)")

    print()
    print("--- CONTRACT phase: only now, once everything is confirmed migrated, the old column is dropped ---")
    ec_db.contract()
    print(f"Old column data after CONTRACT: {ec_db.blocked_reason_old} (expected: empty - genuinely removed, "
          f"but only after the transition window, never during it)")

    print()
    print("=== TEST 6: The actual comparison, side by side ===")
    print(f"Naive approach: DB widen succeeded, but downstream report SILENTLY corrupted data")
    print(f"Expand-Contract: every phase tested independently, old consumers NEVER see corrupted or")
    print(f"truncated-without-warning data, new consumers only see full data once explicitly cut over")
