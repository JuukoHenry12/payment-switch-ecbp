-- ============================================================
-- ECBP Schema Migration History — DDL
-- ============================================================
-- Closes the identified gap directly: no version-number mechanism
-- existed to identify which schema structure any given environment
-- is running. This is the relational-world equivalent of a version
-- discriminator in an Enscribe record - except here it tracks the
-- whole schema's evolution, not a single record's layout.
-- ============================================================

CREATE TABLE SCHEMA_MIGRATION_HISTORY (
    VERSION                    VARCHAR(20)   PRIMARY KEY,   -- e.g. 'V12'
    DESCRIPTION                    VARCHAR(200) NOT NULL,
    MIGRATION_TYPE                    VARCHAR(20) NOT NULL, -- EXPAND, MIGRATE, CUTOVER, CONTRACT
    CHECKSUM                             VARCHAR(64) NOT NULL,  -- SHA-256 of the migration script itself -
                                                                  -- detects drift if someone hand-edits a
                                                                  -- migration file after it's already been applied
    APPLIED_AT                             TIMESTAMPTZ NOT NULL DEFAULT now(),
    APPLIED_BY                               VARCHAR(50) NOT NULL,
    EXECUTION_TIME_MS                          INTEGER   NOT NULL
);

-- One query answers "what schema version is THIS environment
-- actually running right now" - genuinely useful during an incident
-- when you need to know immediately whether prod, staging, and a
-- given service instance are all on the same page.
CREATE INDEX IDX_MIGRATION_APPLIED ON SCHEMA_MIGRATION_HISTORY (APPLIED_AT);
