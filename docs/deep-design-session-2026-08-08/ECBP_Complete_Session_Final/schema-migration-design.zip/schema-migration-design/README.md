# Schema Migration Framework — Version Tracking & the Expand-Contract Pattern

## Direct answer to the questions asked

**Are we using version numbers so a database structure change can be identified? Before this package: no** — a genuine, honest gap, now closed by SCHEMA_MIGRATION_HISTORY, which tracks exactly which version any environment is running, with checksum drift detection catching a migration file edited after it was already applied.

**Does the design already handle old-and-new coexisting during a change, the way a NonStop/Base24 flag-day cutover has to? Not by accident — but the underlying property that makes it possible was already true, just never proven.** Relational storage (what ECBP actually uses) addresses fields by catalog metadata, not physical byte offset — so widening a column that isn't at the end of a table is structurally not the same danger it is in an Enscribe record, where every field after it is defined by its offset from the start. That removes the physical corruption risk NonStop has to coordinate around. It does not remove application-level coordination risk, which is real and is what this package actually tests.

## The real failure, proven — not just described

Test 4 shows exactly what goes wrong with a naive, single-shot widen: the database happily accepts a 108-character value into a newly-widened column — no error, no warning, complete success from the database's point of view. But a downstream fixed-width report export (the same principle as real regulatory batch submissions) still assumes the old 100-character width, and silently truncates the value. The database reports success. The report is wrong. Nothing anywhere flags this as a failure — that's what makes it dangerous.

## The fix, proven at every phase — not just the end state

Scenario B runs the exact same situation through Expand-Contract, and Test 5 checks each phase independently, not just the final result:

- EXPAND: the new column exists, but the old column is deliberately never touched — old consumers are provably unaffected
- MIGRATE: dual-write begins, but reads for "new" consumers still come from the old (safe) column until an explicit cutover — proving no consumer is exposed to the new data prematurely, even accidentally
- CUTOVER: new consumers switch over, and — this is the part worth noting specifically — an old consumer still running a stale deployment continues reading correctly, safely truncated, never broken
- CONTRACT: the old column is only ever removed after this entire window, once every consumer is confirmed migrated

## Files

```
ddl/migration_history_ddl.sql        - SCHEMA_MIGRATION_HISTORY, the version-tracking mechanism
service/migration_framework.py       - MigrationRunner + both scenarios, 6 tests
```

## Verified, working — 6 real scenarios

1. Migration applies and records a real version
2. Re-applying the same migration is a safe no-op
3. Drift detection — a migration file edited after being applied is caught with a clear error, not silently trusted
4. The naive widen's real failure — proven, not asserted: a downstream report silently truncates real data despite the database reporting complete success
5. Expand-Contract, phase by phase — every stage independently verified safe for both old and new consumers
6. Direct side-by-side comparison of both outcomes

## The one piece already in place that solves half of this — Schema Registry

Everything above concerns the relational side. For the event side — Kafka messages, the Avro schemas from Phase 1 onward — this problem already has a real, working answer installed today: the Schema Registry, with its schema compatibility enforcement. A consumer can check compatibility before ever deserializing a message, and the registry actively refuses an incompatible schema change. That's the direct event-driven equivalent of a version discriminator in an Enscribe record, and it was already sitting there from this afternoon's installation work — just never explicitly connected to this question until now.

## How this maps to the NonStop/Base24 experience directly

| NonStop/Base24 | ECBP (relational + event-driven) |
|---|---|
| Fixed-offset Enscribe record — widening a mid-record field shifts every field after it | Catalog-addressed columns — widening is metadata-only, position-independent |
| Every consumer must recompile and redeploy in lockstep, or read garbage | Old and new application code can coexist safely during a transition, IF Expand-Contract is followed |
| No native concept of "which record version is this" | SCHEMA_MIGRATION_HISTORY (relational) + Schema Registry compatibility checking (event-driven) |
| Flag-day cutover — a high-risk, all-at-once moment | Expand -> Migrate -> Cutover -> Contract — the same underlying discipline, spread across bounded, individually-safe phases |

The physical mechanism is genuinely different. The underlying engineering discipline — never let two versions of reality collide without a coordinated transition — is exactly the same one you already know.
