"""
active_active_analysis.py — two real, tested demonstrations:

  1. SYSTEM-LEVEL ACTIVE-ACTIVE IS ACHIEVABLE: different shards,
     owned by different regions, genuinely processing live writes
     CONCURRENTLY - proving this is a real, working pattern given
     the sharding design already in place, not a theoretical claim.

  2. WHY SINGLE-ACCOUNT MULTI-MASTER IS DELIBERATELY AVOIDED: a
     genuine, concrete simulation of two "regions" both accepting a
     concurrent debit against the SAME account with no coordination -
     proving the actual financial corruption this causes, not just
     asserting it's risky. This is the real reason single-writer-
     per-shard is a deliberate design choice for a ledger, not a
     limitation to apologize for.
"""

import threading
import time
from dataclasses import dataclass, field
from decimal import Decimal


# ------------------------------------------------------------
# PART 1: System-level active-active, genuinely concurrent
# ------------------------------------------------------------
class RegionOwnedShard:
    """One shard, with a clear single owning region for writes -
    avoiding the conflict problem by construction, not by luck."""

    def __init__(self, shard_id: str, owning_region: str):
        self.shard_id = shard_id
        self.owning_region = owning_region
        self.balance = Decimal("10000.00")
        self.write_count = 0
        self.lock = threading.Lock()

    def write(self, region: str, amount: Decimal) -> bool:
        if region != self.owning_region:
            return False  # a non-owning region must forward, never write directly
        with self.lock:
            self.balance += amount
            self.write_count += 1
        return True


def simulate_concurrent_regional_traffic(shard_a: RegionOwnedShard, shard_b: RegionOwnedShard,
                                           writes_per_region: int):
    """Region A hammers shard A, Region B hammers shard B, AT THE
    SAME TIME, on separate threads - genuine concurrency, not
    sequential simulation dressed up as parallel."""

    def region_a_traffic():
        for _ in range(writes_per_region):
            shard_a.write("REGION-A", Decimal("1.00"))

    def region_b_traffic():
        for _ in range(writes_per_region):
            shard_b.write("REGION-B", Decimal("1.00"))

    thread_a = threading.Thread(target=region_a_traffic)
    thread_b = threading.Thread(target=region_b_traffic)

    start = time.perf_counter()
    thread_a.start()
    thread_b.start()
    thread_a.join()
    thread_b.join()
    elapsed = time.perf_counter() - start
    return elapsed


# ------------------------------------------------------------
# PART 2: The real danger of naive single-account multi-master
# ------------------------------------------------------------
@dataclass
class NaiveMultiMasterAccount:
    """NO single writer, NO coordination - two 'regions' can both
    read-modify-write the SAME account concurrently. This is
    deliberately built WITHOUT protection, to prove what actually
    goes wrong, not to recommend building it this way."""
    balance: Decimal = Decimal("1000.00")


def naive_concurrent_debit(account: NaiveMultiMasterAccount, amount: Decimal, delay_between_read_and_write: float):
    """Simulates the classic lost-update race: read balance, pause
    (representing real network/processing latency between two
    distant sites), then write back based on the STALE read."""
    current = account.balance          # READ
    time.sleep(delay_between_read_and_write)  # the real-world gap between read and write across two sites
    account.balance = current - amount  # WRITE - based on a potentially now-stale 'current'


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: SYSTEM-LEVEL ACTIVE-ACTIVE - two regions, two shards, genuinely concurrent ===")
    shard_a = RegionOwnedShard("shard-1", "REGION-A")
    shard_b = RegionOwnedShard("shard-2", "REGION-B")

    elapsed = simulate_concurrent_regional_traffic(shard_a, shard_b, writes_per_region=1000)
    print(f"Region A wrote {shard_a.write_count} times to its own shard")
    print(f"Region B wrote {shard_b.write_count} times to its own shard")
    print(f"Both completed CONCURRENTLY (real threads, not sequential) in {elapsed*1000:.1f}ms total")
    print(f"Both regions genuinely active, genuinely writing, at the same time: "
          f"{shard_a.write_count == 1000 and shard_b.write_count == 1000} (expected: True)")

    print()
    print("=== TEST 2: A non-owning region attempting to write directly is correctly refused ===")
    result = shard_b.write("REGION-A", Decimal("5.00"))  # Region A trying to write shard B's data directly
    print(f"Region A writing directly to shard B (which Region B owns): {result} (expected: False)")
    print("(this is exactly what PREVENTS the conflict problem - not luck, a deliberate rule)")

    print()
    print("=== TEST 3: THE REAL DANGER - naive multi-master, two concurrent debits, no coordination ===")
    print("Starting balance: $1000.00. TWO regions each try to debit $100.00 'simultaneously',")
    print("with a real gap between reading the balance and writing it back - representing genuine")
    print("network latency between two distant sites, exactly the condition true multi-master creates.")

    naive_account = NaiveMultiMasterAccount()
    thread_1 = threading.Thread(target=naive_concurrent_debit, args=(naive_account, Decimal("100.00"), 0.05))
    thread_2 = threading.Thread(target=naive_concurrent_debit, args=(naive_account, Decimal("100.00"), 0.05))

    thread_1.start()
    thread_2.start()
    thread_1.join()
    thread_2.join()

    print()
    print(f"Expected final balance if BOTH debits were correctly applied: $800.00")
    print(f"ACTUAL final balance: ${naive_account.balance}")
    print(f"LOST UPDATE: a real $100.00 debit vanished: {naive_account.balance != Decimal('800.00')} "
          f"(expected: True - this is the actual, concrete corruption naive multi-master causes,")
    print(f"not a theoretical risk - one region's read-modify-write silently overwrote the other's)")

    print()
    print("=== TEST 4: The SAME two concurrent debits, run through the single-writer-per-shard design instead ===")
    protected_shard = RegionOwnedShard("shard-protected", "REGION-A")
    protected_shard.balance = Decimal("1000.00")

    def protected_debit():
        protected_shard.write("REGION-A", Decimal("-100.00"))

    t3 = threading.Thread(target=protected_debit)
    t4 = threading.Thread(target=protected_debit)
    t3.start(); t4.start()
    t3.join(); t4.join()

    print(f"Final balance with single-writer-per-shard protection: ${protected_shard.balance}")
    print(f"BOTH debits correctly applied, nothing lost: {protected_shard.balance == Decimal('800.00')} "
          f"(expected: True - the lock inside RegionOwnedShard.write() genuinely prevents the exact")
    print(f"corruption Test 3 just demonstrated)")
