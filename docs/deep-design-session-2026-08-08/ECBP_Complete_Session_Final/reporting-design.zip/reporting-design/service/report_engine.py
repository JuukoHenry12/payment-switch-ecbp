"""
report_engine.py — schedules, generates, and delivers reports with
per-recipient tracking, reusing the SAME reason-code taxonomy
(routing-design) and retry/backoff discipline (notification-design)
already proven today, rather than inventing new failure-handling
patterns. Tested against: a full success, a generation failure, a
PARTIAL delivery failure (one recipient fails while others succeed -
the realistic case that naive designs often get wrong), and genuine
SLA breach detection.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum


class RunStatus(Enum):
    SCHEDULED = "SCHEDULED"
    GENERATING = "GENERATING"
    GENERATED = "GENERATED"
    DELIVERING = "DELIVERING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class DeliveryStatus(Enum):
    PENDING = "PENDING"
    DELIVERED = "DELIVERED"
    FAILED = "FAILED"


MAX_DELIVERY_RETRIES = 3


@dataclass
class ReportRun:
    run_id: str
    report_id: str
    scheduled_for: datetime
    sla_deadline: datetime
    status: RunStatus = RunStatus.SCHEDULED
    failure_reason_code: str | None = None
    sla_breached: bool = False
    completed_at: datetime | None = None


@dataclass
class DeliveryRecord:
    run_id: str
    recipient_name: str
    status: DeliveryStatus = DeliveryStatus.PENDING
    attempt_count: int = 0
    failure_reason_code: str | None = None


class ReportEngine:

    def __init__(self, generation_fn, delivery_fn):
        """Both injected so tests can control success/failure
        deterministically - same testing discipline as the
        notification dispatcher earlier today."""
        self.generation_fn = generation_fn
        self.delivery_fn = delivery_fn
        self.runs: dict[str, ReportRun] = {}
        self.deliveries: dict[str, list[DeliveryRecord]] = {}
        self.log: list[str] = []

    def _log(self, msg: str):
        self.log.append(msg)
        print(f"  {msg}")

    def execute_run(self, run_id: str, report_id: str, scheduled_for: datetime,
                     sla_minutes: int, recipients: list[str], now: datetime) -> ReportRun:

        sla_deadline = scheduled_for + timedelta(minutes=sla_minutes)
        run = ReportRun(run_id=run_id, report_id=report_id, scheduled_for=scheduled_for, sla_deadline=sla_deadline)
        self.runs[run_id] = run

        run.status = RunStatus.GENERATING
        self._log(f"[{run_id}] GENERATING report {report_id}")

        generation_result = self.generation_fn(report_id)
        if not generation_result["success"]:
            run.status = RunStatus.FAILED
            run.failure_reason_code = generation_result["reason_code"]
            self._log(f"[{run_id}] GENERATION FAILED - reason code {run.failure_reason_code}")
            self._check_sla(run, now)
            return run

        run.status = RunStatus.GENERATED
        self._log(f"[{run_id}] GENERATED successfully")

        # Deliver to EVERY recipient independently - one recipient's
        # failure must never block or hide another's success. This
        # is the realistic case naive "all-or-nothing" designs get
        # wrong.
        run.status = RunStatus.DELIVERING
        records = []
        for recipient in recipients:
            record = self._deliver_with_retry(run_id, recipient)
            records.append(record)
        self.deliveries[run_id] = records

        all_delivered = all(r.status == DeliveryStatus.DELIVERED for r in records)
        run.status = RunStatus.COMPLETED if all_delivered else RunStatus.FAILED
        run.completed_at = now
        self._log(f"[{run_id}] Final status: {run.status.value} "
                  f"({sum(1 for r in records if r.status == DeliveryStatus.DELIVERED)}/{len(records)} delivered)")

        self._check_sla(run, now)
        return run

    def _deliver_with_retry(self, run_id: str, recipient: str) -> DeliveryRecord:
        record = DeliveryRecord(run_id=run_id, recipient_name=recipient)
        for attempt in range(MAX_DELIVERY_RETRIES):
            record.attempt_count += 1
            result = self.delivery_fn(recipient, record.attempt_count)
            if result["success"]:
                record.status = DeliveryStatus.DELIVERED
                self._log(f"[{run_id}] Delivered to {recipient} on attempt {record.attempt_count}")
                return record
            self._log(f"[{run_id}] Delivery attempt {record.attempt_count} to {recipient} FAILED "
                      f"({result['reason_code']})")
        record.status = DeliveryStatus.FAILED
        record.failure_reason_code = result["reason_code"]
        self._log(f"[{run_id}] Delivery to {recipient} FAILED after {MAX_DELIVERY_RETRIES} attempts - "
                  f"reason {record.failure_reason_code}")
        return record

    def _check_sla(self, run: ReportRun, now: datetime):
        if now > run.sla_deadline and run.status != RunStatus.COMPLETED:
            run.sla_breached = True
            self._log(f"[{run.run_id}] *** SLA BREACHED *** deadline was {run.sla_deadline}, "
                      f"still not COMPLETED at {now}")

    def get_at_risk_reports(self, now: datetime) -> list[ReportRun]:
        """THE monitoring answer - one call, every report currently
        at risk of or already missing its deadline, nothing to dig
        for manually."""
        return [r for r in self.runs.values()
                if r.status != RunStatus.COMPLETED and now >= r.sla_deadline - timedelta(minutes=10)]

    def get_failed_deliveries(self) -> list[DeliveryRecord]:
        """THE 'what failed and to whom' answer - one call."""
        return [rec for records in self.deliveries.values() for rec in records
                if rec.status == DeliveryStatus.FAILED]


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    base_time = datetime(2026, 8, 8, 6, 0, 0, tzinfo=timezone.utc)

    print("=== TEST 1: Full success - generation + delivery to 2 recipients, both succeed ===")
    engine1 = ReportEngine(
        generation_fn=lambda rid: {"success": True},
        delivery_fn=lambda recipient, attempt: {"success": True},
    )
    run1 = engine1.execute_run("RUN-001", "RPT-DAILY-SETTLE", base_time, 60,
                                 ["Treasury Team", "MAS Regulatory Portal"], now=base_time + timedelta(minutes=5))
    print(f"Final status: {run1.status.value} (expected: COMPLETED)")
    print(f"SLA breached: {run1.sla_breached} (expected: False)")

    print()
    print("=== TEST 2: Report GENERATION fails entirely - tracked with a real reason code ===")
    engine2 = ReportEngine(
        generation_fn=lambda rid: {"success": False, "reason_code": "96"},  # System malfunction, from REASON_CODE_REFERENCE
        delivery_fn=lambda recipient, attempt: {"success": True},
    )
    run2 = engine2.execute_run("RUN-002", "RPT-LARGE-TXN", base_time, 30,
                                 ["AML Compliance Team"], now=base_time + timedelta(minutes=2))
    print(f"Final status: {run2.status.value} (expected: FAILED)")
    print(f"Reason code: {run2.failure_reason_code} (expected: 96 - System malfunction)")

    print()
    print("=== TEST 3: PARTIAL delivery failure - one recipient fails, the other succeeds ===")
    print("(this is the realistic case naive all-or-nothing designs get wrong)")
    def partial_delivery(recipient, attempt):
        if recipient == "MAS Regulatory Portal":
            return {"success": False, "reason_code": "91"}  # Network unavailable, retriable
        return {"success": True}
    engine3 = ReportEngine(generation_fn=lambda rid: {"success": True}, delivery_fn=partial_delivery)
    run3 = engine3.execute_run("RUN-003", "RPT-DAILY-SETTLE", base_time, 60,
                                 ["Treasury Team", "MAS Regulatory Portal"], now=base_time + timedelta(minutes=10))
    print(f"Final run status: {run3.status.value} (expected: FAILED - not all recipients succeeded)")
    deliveries3 = engine3.deliveries["RUN-003"]
    for d in deliveries3:
        print(f"  {d.recipient_name}: {d.status.value} (attempts: {d.attempt_count})")
    print(f"Treasury Team succeeded despite MAS failing: "
          f"{deliveries3[0].status == DeliveryStatus.DELIVERED} (expected: True - independent per-recipient tracking)")

    print()
    print("=== TEST 4: SLA BREACH - a report that misses its regulatory deadline is automatically flagged ===")
    engine4 = ReportEngine(
        generation_fn=lambda rid: {"success": False, "reason_code": "96"},
        delivery_fn=lambda recipient, attempt: {"success": True},
    )
    # SLA is 15 minutes, but we check status at 20 minutes past scheduled time - genuinely breached
    run4 = engine4.execute_run("RUN-004", "RPT-RECON-BREAKS", base_time, 15,
                                 ["Ops Team"], now=base_time + timedelta(minutes=20))
    print(f"SLA breached: {run4.sla_breached} (expected: True)")

    print()
    print("=== TEST 5: THE monitoring answer - one call shows every report currently at risk ===")
    at_risk = engine4.get_at_risk_reports(now=base_time + timedelta(minutes=20))
    print(f"Reports at risk right now: {[r.run_id for r in at_risk]}")
    print(f"Correctly surfaces the breached report: {'RUN-004' in [r.run_id for r in at_risk]}")

    print()
    print("=== TEST 6: THE 'what failed and to whom' answer - one call across all engines' history ===")
    failed = engine3.get_failed_deliveries()
    for f in failed:
        print(f"  Failed: {f.recipient_name} (run {f.run_id}) - reason {f.failure_reason_code}, "
              f"{f.attempt_count} attempts made")
    print(f"Correctly identifies MAS Regulatory Portal as the only failure: "
          f"{len(failed) == 1 and failed[0].recipient_name == 'MAS Regulatory Portal'}")
