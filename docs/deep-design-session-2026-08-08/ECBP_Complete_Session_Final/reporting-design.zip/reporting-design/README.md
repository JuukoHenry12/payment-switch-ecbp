# Report Generation, Delivery & SLA Monitoring — Design Package

## Direct answer to the question asked

**Before this package: no.** The CQRS read model gave reports something to query, but nothing scheduled generation, tracked delivery per recipient, detected a missed regulatory deadline, or made a failure fast to find. This closes that gap, reusing two things already proven today rather than inventing new patterns: the reason-code taxonomy from `routing-design`, and the retry/backoff discipline from `notification-design`.

## Files

```
ddl/reporting_ddl.sql          - REPORT_DEFINITION, REPORT_RUN, REPORT_RECIPIENT, REPORT_DELIVERY
service/report_engine.py       - tested against 6 real scenarios
```

## Verified, working — 6 real scenarios, addressing every part of the question

1. **Full success** — generation and delivery to multiple recipients, all tracked, all confirmed
2. **Generation failure, with a real reason code** — not a generic "report failed," a specific, standardized code (`96` — System malfunction), the same vocabulary used everywhere else in the system
3. **Partial delivery failure — the realistic case naive designs get wrong.** One recipient (a regulator's portal) fails after 3 genuine retry attempts while a second recipient succeeds cleanly on the first try. Both outcomes are tracked completely independently — one failure never hides or blocks the other's success
4. **SLA breach detection** — a report that misses its regulatory deadline is automatically flagged, not silently late
5. **The monitoring answer** — `get_at_risk_reports()` is one call that surfaces every report currently breached or approaching its deadline, exactly the "easy monitoring" requirement
6. **The failure-tracking answer** — `get_failed_deliveries()` is one call that shows exactly which recipient, on which report, failed, and how many attempts were made before giving up

## Why per-recipient tracking specifically matters here

Look closely at Test 3's actual log: `MAS Regulatory Portal` genuinely retried three times with real backoff before being marked failed, while `Treasury Team` was already `DELIVERED`. A weaker design that tracked delivery as one boolean for the whole report would either (a) mark the entire report failed and cause Treasury to be needlessly re-sent a duplicate, or (b) mark it successful and silently never notice the regulator never received it — the second failure mode being genuinely dangerous for a compliance-critical report.

## How this connects to everything built today

```
REPORT_DEFINITION's schedule fires (a real cron trigger, e.g. Spring's
@Scheduled - same pattern as the EOD batch job from earlier)
        │
        ▼
ReportEngine.execute_run() queries the CQRS read model
(TRANSACTION_LIFECYCLE_VIEW / DAILY_SETTLEMENT_SUMMARY from
observability-design) - the data source was already correct,
this engine just makes USING it scheduled, tracked, and monitored
        │
        ▼
Delivers independently per recipient, with retry/backoff
(identical discipline to notification-design's dispatcher)
        │
        ▼
Any failure - generation or delivery - uses the SAME reason codes
as routing-design's REASON_CODE_REFERENCE, so a support engineer
investigating a failed report speaks the exact same vocabulary as
someone investigating a failed transaction
```

## Honest limitation

The actual report *content* generation (querying the CQRS view and formatting it into a real CSV/PDF/XML file per recipient's expected format) is represented here by an injected function, tested for its success/failure behavior rather than its formatting logic — that's a genuinely separate, format-specific concern per report type, not something this package's job was to solve. This package's job — and what it proves — is the scheduling, tracking, retry, and monitoring layer around report generation, regardless of what any individual report actually contains.
