-- ============================================================
-- ECBP Report Generation, Delivery & SLA Monitoring — DDL
-- ============================================================
-- The gap this closes: the CQRS read model (observability-design,
-- earlier today) gives reports DATA to pull from, but nothing
-- schedules generation, tracks per-recipient delivery, detects a
-- missed regulatory deadline, or makes a failure easy to find and
-- retry. This is that missing layer.
-- ============================================================

CREATE TABLE REPORT_DEFINITION (
    REPORT_ID                VARCHAR(30)     PRIMARY KEY,
    REPORT_NAME                  VARCHAR(100) NOT NULL,
    SCHEDULE_CRON                    VARCHAR(50) NOT NULL,   -- e.g. '0 6 * * *' = daily 6am
    SLA_DEADLINE_MINUTES                INTEGER  NOT NULL,   -- must complete + deliver within this many minutes of scheduled time
    DATA_SOURCE                           VARCHAR(50) NOT NULL, -- which CQRS view/table it queries
    IS_ACTIVE                               BOOLEAN  NOT NULL DEFAULT true
);

INSERT INTO REPORT_DEFINITION (REPORT_ID, REPORT_NAME, SCHEDULE_CRON, SLA_DEADLINE_MINUTES, DATA_SOURCE) VALUES
    ('RPT-DAILY-SETTLE', 'Daily Settlement Summary', '0 6 * * *', 60, 'DAILY_SETTLEMENT_SUMMARY'),
    ('RPT-LARGE-TXN', 'Large Transaction Report (AML)', '0 7 * * *', 30, 'TRANSACTION_LIFECYCLE_VIEW'),
    ('RPT-RECON-BREAKS', 'Open Reconciliation Breaks', '0 8 * * *', 15, 'TRANSACTION_LIFECYCLE_VIEW');

CREATE TABLE REPORT_RECIPIENT (
    REPORT_ID                VARCHAR(30)     NOT NULL REFERENCES REPORT_DEFINITION(REPORT_ID),
    RECIPIENT_NAME               VARCHAR(100) NOT NULL,
    DELIVERY_METHOD                  VARCHAR(20) NOT NULL,   -- EMAIL, SFTP, API_PUSH
    DELIVERY_ADDRESS                    VARCHAR(200) NOT NULL,

    PRIMARY KEY (REPORT_ID, RECIPIENT_NAME)
);

INSERT INTO REPORT_RECIPIENT (REPORT_ID, RECIPIENT_NAME, DELIVERY_METHOD, DELIVERY_ADDRESS) VALUES
    ('RPT-DAILY-SETTLE', 'Treasury Team', 'EMAIL', 'treasury@ecbp.internal'),
    ('RPT-DAILY-SETTLE', 'MAS Regulatory Portal', 'API_PUSH', 'https://mas-portal.gov.sg/api/submit'),
    ('RPT-LARGE-TXN', 'AML Compliance Team', 'SFTP', 'sftp://compliance.ecbp.internal/inbound'),
    ('RPT-RECON-BREAKS', 'Ops Team', 'EMAIL', 'ops@ecbp.internal');

CREATE TABLE REPORT_RUN (
    RUN_ID                    UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    REPORT_ID                    VARCHAR(30)  NOT NULL REFERENCES REPORT_DEFINITION(REPORT_ID),
    SCHEDULED_FOR                   TIMESTAMPTZ NOT NULL,
    STATUS                             VARCHAR(20) NOT NULL,  -- SCHEDULED, GENERATING, GENERATED, DELIVERING, COMPLETED, FAILED
    GENERATION_STARTED_AT                 TIMESTAMPTZ NULL,
    GENERATION_COMPLETED_AT                 TIMESTAMPTZ NULL,
    FAILURE_REASON_CODE                       VARCHAR(4) NULL,  -- reuses REASON_CODE_REFERENCE from routing-design
    RETRY_COUNT                                 SMALLINT NOT NULL DEFAULT 0,
    SLA_DEADLINE                                  TIMESTAMPTZ NOT NULL,
    SLA_BREACHED                                    BOOLEAN  NOT NULL DEFAULT false
);

CREATE INDEX IDX_REPORT_RUN_STATUS ON REPORT_RUN (STATUS, SLA_DEADLINE) WHERE STATUS != 'COMPLETED';
-- This index is what makes "show me every report at risk of missing
-- its deadline right now" a fast, single query - exactly the
-- monitoring requirement asked for.

CREATE TABLE REPORT_DELIVERY (
    DELIVERY_ID               UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    RUN_ID                       UUID         NOT NULL REFERENCES REPORT_RUN(RUN_ID),
    RECIPIENT_NAME                   VARCHAR(100) NOT NULL,
    STATUS                              VARCHAR(20) NOT NULL,  -- PENDING, DELIVERED, FAILED
    ATTEMPT_COUNT                         SMALLINT NOT NULL DEFAULT 0,
    FAILURE_REASON_CODE                     VARCHAR(4) NULL,
    DELIVERED_AT                              TIMESTAMPTZ NULL
);

CREATE INDEX IDX_DELIVERY_RUN ON REPORT_DELIVERY (RUN_ID);
CREATE INDEX IDX_DELIVERY_FAILED ON REPORT_DELIVERY (STATUS) WHERE STATUS = 'FAILED';
-- One query answers "which specific deliveries failed and to whom" -
-- the exact thing that needs to be fast and obvious, per the ask.
