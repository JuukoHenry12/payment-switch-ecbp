"""
resource_limits_fix.py — closes the confirmed gap: today's Kubernetes
config had 'requests' (a reserved minimum) but no 'limits' (a hard
maximum), meaning nothing actually prevented one runaway pod from
starving every other pod on its node - including, notably, the OTHER
replicas of the same service that pod-antiaffinity-design just spread
across nodes specifically to protect from a single node failure.
A memory leak in ONE replica, unbounded, could still take down its
whole node's other tenants without ever triggering a "node failure."
"""

from dataclasses import dataclass


@dataclass
class Pod:
    pod_id: str
    memory_used_mb: float
    memory_limit_mb: float | None  # None = no limit configured, matching today's real gap


class NodeMemoryModel:
    """Models a single node's total available memory, shared across
    every pod scheduled on it."""

    def __init__(self, total_memory_mb: float):
        self.total_memory_mb = total_memory_mb
        self.pods: list[Pod] = []

    def available_memory(self) -> float:
        used = sum(p.memory_used_mb for p in self.pods)
        return self.total_memory_mb - used

    def simulate_leak(self, pod_id: str, growth_per_tick_mb: float, ticks: int) -> list[float]:
        """Simulates a real memory leak - unbounded growth over time,
        capped only if the pod has an actual limit configured."""
        pod = next(p for p in self.pods if p.pod_id == pod_id)
        history = []
        for _ in range(ticks):
            pod.memory_used_mb += growth_per_tick_mb
            if pod.memory_limit_mb is not None and pod.memory_used_mb > pod.memory_limit_mb:
                pod.memory_used_mb = pod.memory_limit_mb  # THE FIX in effect: capped, would be OOMKilled and restarted in reality
            history.append(pod.memory_used_mb)
        return history


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: WITHOUT limits (today's actual gap) - a leaking pod consumes unbounded memory ===")
    node_unlimited = NodeMemoryModel(total_memory_mb=4096)
    node_unlimited.pods = [
        Pod("payment-service-1", memory_used_mb=512, memory_limit_mb=None),  # no limit - the real gap
        Pod("fraud-service-1", memory_used_mb=512, memory_limit_mb=None),
        Pod("routing-service-1", memory_used_mb=512, memory_limit_mb=None),
    ]
    print(f"Node total memory: {node_unlimited.total_memory_mb}MB")
    print(f"Available before the leak: {node_unlimited.available_memory()}MB")

    history_unlimited = node_unlimited.simulate_leak("payment-service-1", growth_per_tick_mb=300, ticks=10)
    print(f"payment-service-1's memory after the leak runs: {history_unlimited[-1]}MB")
    print(f"Available memory remaining for its NEIGHBORS (fraud-service, routing-service): "
          f"{node_unlimited.available_memory()}MB")
    print(f"NEIGHBORS ARE NOW STARVED - negative or near-zero available memory: "
          f"{node_unlimited.available_memory() <= 0} (expected: True - this is the real, confirmed")
    print(f"gap: a leak in ONE service can starve completely unrelated services on the same node)")

    print()
    print("=== TEST 2: THE FIX - the SAME leak, but with a real resource limit configured ===")
    node_limited = NodeMemoryModel(total_memory_mb=4096)
    node_limited.pods = [
        Pod("payment-service-1", memory_used_mb=512, memory_limit_mb=1024),  # THE FIX: a real cap
        Pod("fraud-service-1", memory_used_mb=512, memory_limit_mb=1024),
        Pod("routing-service-1", memory_used_mb=512, memory_limit_mb=1024),
    ]
    history_limited = node_limited.simulate_leak("payment-service-1", growth_per_tick_mb=300, ticks=10)
    print(f"payment-service-1's memory after the SAME leak: {history_limited[-1]}MB "
          f"(expected: capped at 1024MB, not allowed to keep growing)")
    print(f"Available memory remaining for its neighbors: {node_limited.available_memory()}MB")
    print(f"Neighbors CORRECTLY protected: {node_limited.available_memory() > 0} (expected: True)")

    print()
    print("=== TEST 3: The honest cost of the fix - the leaking pod itself still gets killed, just contained ===")
    print("In a real cluster, hitting the memory limit triggers an OOMKill and restart of JUST that pod -")
    print("payment-service-1 still goes down and needs to recover (the same restart-time cost discussed")
    print("in the earlier process-failure comparison), but its neighbors on the same node are never")
    print("affected. This is real containment, not a claim that the leak itself becomes harmless.")
