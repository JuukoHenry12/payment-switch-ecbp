"""
saga_compensation_failure_fix.py — a faithful Python re-test of the
REAL logic in SagaOrchestrator.java's compensate() method (built
this morning), proving a genuine bug: the final markCompensated()
call runs unconditionally, even when one or more individual
compensation attempts failed and were correctly logged as failures.
This means a saga with real, unresolved inconsistent state reports
itself as cleanly COMPENSATED - exactly the wrong terminal status,
and exactly the kind of thing that would mislead an operator querying
saga status weeks later while investigating an unrelated discrepancy.
"""

from dataclasses import dataclass, field
from enum import Enum


class SagaStatus(Enum):
    COMPLETED = "COMPLETED"
    COMPENSATING = "COMPENSATING"
    COMPENSATED = "COMPENSATED"
    COMPENSATION_FAILED = "COMPENSATION_FAILED"  # THE missing status the fix adds


@dataclass
class SagaRecord:
    saga_id: str
    status: SagaStatus | None = None
    compensated_steps: list = field(default_factory=list)
    failed_compensations: list = field(default_factory=list)


class BuggyOrchestrator:
    """Faithfully reproduces the REAL bug from SagaOrchestrator.java's
    compensate() method - catches and logs each failure individually,
    but marks the saga COMPENSATED unconditionally at the end,
    regardless of whether anything actually failed."""

    def __init__(self):
        self.saga_repository: dict[str, SagaRecord] = {}

    def compensate(self, saga_id: str, completed_steps: list):
        self.saga_repository[saga_id] = SagaRecord(saga_id, status=SagaStatus.COMPENSATING)
        record = self.saga_repository[saga_id]

        for step_name, compensate_fn in reversed(completed_steps):
            try:
                compensate_fn()
                record.compensated_steps.append(step_name)
            except Exception as e:
                record.failed_compensations.append((step_name, str(e)))
                # correctly logged - but nothing stops here, matching
                # the real Java code exactly

        # THE BUG, faithfully reproduced: this runs UNCONDITIONALLY,
        # exactly matching the real Java code's structure.
        record.status = SagaStatus.COMPENSATED


class FixedOrchestrator:
    """THE fix: the terminal status genuinely reflects whether
    compensation actually, fully succeeded."""

    def __init__(self):
        self.saga_repository: dict[str, SagaRecord] = {}

    def compensate(self, saga_id: str, completed_steps: list):
        self.saga_repository[saga_id] = SagaRecord(saga_id, status=SagaStatus.COMPENSATING)
        record = self.saga_repository[saga_id]

        for step_name, compensate_fn in reversed(completed_steps):
            try:
                compensate_fn()
                record.compensated_steps.append(step_name)
            except Exception as e:
                record.failed_compensations.append((step_name, str(e)))

        # THE FIX: check whether anything actually failed before
        # deciding the terminal status.
        if record.failed_compensations:
            record.status = SagaStatus.COMPENSATION_FAILED
        else:
            record.status = SagaStatus.COMPENSATED


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: All compensations succeed - both orchestrators correctly agree ===")
    def ok_step(): pass
    buggy1 = BuggyOrchestrator()
    fixed1 = FixedOrchestrator()
    steps_all_ok = [("HoldFunds", ok_step), ("RiskCheck", ok_step)]
    buggy1.compensate("SAGA-001", steps_all_ok)
    fixed1.compensate("SAGA-001", steps_all_ok)
    print(f"Buggy status: {buggy1.saga_repository['SAGA-001'].status.value}")
    print(f"Fixed status: {fixed1.saga_repository['SAGA-001'].status.value}")
    print(f"Both agree when everything genuinely succeeds: "
          f"{buggy1.saga_repository['SAGA-001'].status == fixed1.saga_repository['SAGA-001'].status}")

    print()
    print("=== TEST 2: THE REAL BUG - one compensation genuinely fails ===")
    def failing_step():
        raise ConnectionError("ledger-service unreachable during compensation")
    def ok_step2(): pass

    steps_with_failure = [("HoldFunds", ok_step2), ("CreditPosting", failing_step)]

    buggy2 = BuggyOrchestrator()
    buggy2.compensate("SAGA-002", steps_with_failure)
    buggy_record = buggy2.saga_repository["SAGA-002"]
    print(f"BUGGY orchestrator's final status: {buggy_record.status.value}")
    print(f"Failed compensations actually logged: {buggy_record.failed_compensations}")
    print(f"THE BUG: status says COMPENSATED despite a real, logged failure: "
          f"{buggy_record.status == SagaStatus.COMPENSATED and len(buggy_record.failed_compensations) > 0} "
          f"(expected: True - this is genuinely misleading to anyone querying saga status)")

    print()
    print("=== TEST 3: THE FIX - the identical scenario, correct terminal status ===")
    fixed2 = FixedOrchestrator()
    fixed2.compensate("SAGA-002", steps_with_failure)
    fixed_record = fixed2.saga_repository["SAGA-002"]
    print(f"FIXED orchestrator's final status: {fixed_record.status.value}")
    print(f"Correctly reports COMPENSATION_FAILED, not a false COMPENSATED: "
          f"{fixed_record.status == SagaStatus.COMPENSATION_FAILED} (expected: True)")
    print(f"The failure is still fully visible for investigation: {fixed_record.failed_compensations}")

    print()
    print("=== TEST 4: A saga in COMPENSATION_FAILED state can be queried and correctly filtered for ops attention ===")
    all_sagas = {**buggy2.saga_repository, **fixed2.saga_repository}
    needs_attention = [s for s in [fixed_record] if s.status == SagaStatus.COMPENSATION_FAILED]
    print(f"Sagas correctly flagged as needing manual intervention: {[s.saga_id for s in needs_attention]}")
    print("(this is the actual, practical value of the fix - an operations dashboard querying for")
    print(" COMPENSATION_FAILED sagas specifically would have found NOTHING under the buggy version,")
    print(" because every saga, however badly compensated, reported itself as cleanly COMPENSATED)")
