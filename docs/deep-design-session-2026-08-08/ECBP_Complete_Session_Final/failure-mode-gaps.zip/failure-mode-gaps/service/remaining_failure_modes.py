"""
remaining_failure_modes.py — closes the final four of the eight
identified failure modes: thundering herd on recovery, silent data
corruption, clock skew between nodes, and gray failure. Same
discipline as every prior fix today: prove the real problem
concretely before proving the fix, not just describe either.
"""

import hashlib
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta


# ============================================================
# PART 1: Thundering herd on recovery
# ============================================================
def fixed_interval_retry_times(num_clients: int, fixed_delay_seconds: float) -> list[float]:
    """THE NAIVE APPROACH: every client retries after the exact same
    fixed delay - meaning they ALL hit the just-recovered service at
    the exact same instant, potentially crashing it again immediately."""
    return [fixed_delay_seconds for _ in range(num_clients)]


def jittered_backoff_retry_times(num_clients: int, base_delay_seconds: float) -> list[float]:
    """THE FIX: exponential backoff WITH random jitter - each client's
    retry time is randomized within a window, spreading the recovery
    load out over time instead of concentrating it into one instant."""
    return [base_delay_seconds + random.uniform(0, base_delay_seconds) for _ in range(num_clients)]


# ============================================================
# PART 2: Silent data corruption - checksummed reconciliation
# ============================================================
@dataclass
class ReplicatedRecord:
    key: str
    value: str

    def checksum(self) -> str:
        return hashlib.sha256(self.value.encode()).hexdigest()


def reconcile_primary_and_replica(primary_data: dict, replica_data: dict) -> list[str]:
    """
    THE FIX: compares checksums between primary and replica for every
    shared key, catching SILENT corruption - cases where the replica
    genuinely has different data than the primary despite replication
    having reported success. This is exactly what real disk mirroring
    reconciliation (and Postgres's pg_checksums) exists to catch -
    corruption that a clean "the write succeeded" status would never
    reveal on its own.
    """
    mismatches = []
    for key, primary_value in primary_data.items():
        if key not in replica_data:
            mismatches.append(f"{key}: MISSING on replica")
            continue
        primary_checksum = ReplicatedRecord(key, primary_value).checksum()
        replica_checksum = ReplicatedRecord(key, replica_data[key]).checksum()
        if primary_checksum != replica_checksum:
            mismatches.append(f"{key}: CHECKSUM MISMATCH (primary and replica silently diverged)")
    return mismatches


# ============================================================
# PART 3: Clock skew between nodes
# ============================================================
def naive_token_expiry_check(expires_at: datetime, node_local_time: datetime) -> bool:
    """THE NAIVE APPROACH: trusts each node's own local clock directly -
    if that node's clock is skewed, the expiry decision is simply wrong,
    and DIFFERENT nodes can disagree about whether the SAME token is
    still valid, purely due to clock drift, not any real state change."""
    return node_local_time < expires_at


def skew_tolerant_token_expiry_check(expires_at: datetime, node_local_time: datetime,
                                       max_tolerated_skew_seconds: int = 5) -> bool:
    """THE FIX: applies a bounded tolerance window (matching real NTP-
    style clock synchronization tolerances) - a token isn't treated as
    expired unless it's expired BEYOND what reasonable clock drift
    could explain. This doesn't eliminate skew, it bounds its impact."""
    adjusted_time = node_local_time - timedelta(seconds=max_tolerated_skew_seconds)
    return adjusted_time < expires_at


# ============================================================
# PART 4: Gray failure - health check passes, real calls don't
# ============================================================
class ServiceWithGrayFailure:
    """Models a service that's technically 'alive' (a lightweight
    ping succeeds) but whose real business-logic calls are genuinely
    failing or badly degraded - the classic gray failure a naive
    liveness probe completely misses."""

    def __init__(self):
        self.is_process_alive = True  # the process itself never crashed
        self.real_calls_succeed = False  # but real business logic is broken

    def liveness_probe(self) -> bool:
        """A NAIVE liveness check - just 'is the process running',
        answers True even during a genuine gray failure."""
        return self.is_process_alive

    def readiness_probe_naive(self) -> bool:
        """ALSO naive if it just checks the same shallow thing."""
        return self.is_process_alive

    def readiness_probe_deep(self) -> bool:
        """THE FIX: a readiness probe that actually exercises a real
        dependency path, not just 'is the process alive'."""
        try:
            return self._make_real_call()
        except Exception:
            return False

    def _make_real_call(self) -> bool:
        if not self.real_calls_succeed:
            raise ConnectionError("downstream dependency degraded")
        return True


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== PART 1: THUNDERING HERD ===")
    print("--- TEST 1: Naive fixed-interval retry - every client hits the recovered service at once ---")
    naive_times = fixed_interval_retry_times(num_clients=100, fixed_delay_seconds=5.0)
    print(f"All 100 clients retry at: {set(naive_times)} (expected: a single value - EVERYONE at once)")
    print(f"Concentrated load spike, exactly what re-crashes a just-recovered service")

    print()
    print("--- TEST 2: Jittered backoff - the SAME 100 clients, load genuinely spread out ---")
    jittered_times = jittered_backoff_retry_times(num_clients=100, base_delay_seconds=5.0)
    print(f"Retry time range: {min(jittered_times):.2f}s to {max(jittered_times):.2f}s")
    print(f"Genuinely spread across a real window, not concentrated: "
          f"{max(jittered_times) - min(jittered_times) > 4.0} (expected: True)")

    print()
    print("=== PART 2: SILENT DATA CORRUPTION ===")
    print("--- TEST 3: Reconciliation correctly detects a silently corrupted replica ---")
    primary = {"acc:001": "50000.00", "acc:002": "75000.50"}
    replica_corrupted = {"acc:001": "50000.00", "acc:002": "75000.51"}  # ONE CENT different - silent corruption
    mismatches = reconcile_primary_and_replica(primary, replica_corrupted)
    print(f"Mismatches found: {mismatches}")
    print(f"Correctly caught the one-cent silent divergence: {len(mismatches) == 1} (expected: True - "
          f"replication reported success, but the data genuinely differs)")

    print()
    print("--- TEST 4: A genuinely correct replica passes reconciliation cleanly ---")
    replica_correct = {"acc:001": "50000.00", "acc:002": "75000.50"}
    mismatches2 = reconcile_primary_and_replica(primary, replica_correct)
    print(f"Mismatches found: {mismatches2} (expected: empty list)")

    print()
    print("=== PART 3: CLOCK SKEW ===")
    print("--- TEST 5: A node with a skewed-AHEAD clock incorrectly rejects a still-valid token ---")
    real_expiry = datetime(2026, 8, 9, 12, 0, 0)
    skewed_node_time = datetime(2026, 8, 9, 12, 0, 3)  # this node's clock is 3 seconds fast
    naive_result = naive_token_expiry_check(real_expiry, skewed_node_time)
    print(f"Naive check result (token still valid?): {naive_result} (expected: False - WRONGLY rejected, "
          f"purely due to this node's clock running fast, not any real expiry)")

    print()
    print("--- TEST 6: THE FIX - the same skew, tolerated within a bounded window ---")
    fixed_result = skew_tolerant_token_expiry_check(real_expiry, skewed_node_time, max_tolerated_skew_seconds=5)
    print(f"Skew-tolerant check result: {fixed_result} (expected: True - correctly tolerates the 3s of drift, "
          f"which is within the real, expected NTP-class skew tolerance)")

    print()
    print("--- TEST 7: A GENUINELY expired token is still correctly rejected, even with tolerance applied ---")
    genuinely_expired_time = datetime(2026, 8, 9, 12, 0, 30)  # 30s past expiry - real skew tolerance doesn't hide this
    fixed_result2 = skew_tolerant_token_expiry_check(real_expiry, genuinely_expired_time, max_tolerated_skew_seconds=5)
    print(f"Result: {fixed_result2} (expected: False - the tolerance window is bounded, it doesn't mask a real expiry)")

    print()
    print("=== PART 4: GRAY FAILURE ===")
    print("--- TEST 8: A service in gray failure passes a naive liveness/readiness check ---")
    gray_service = ServiceWithGrayFailure()
    gray_service.is_process_alive = True
    gray_service.real_calls_succeed = False  # genuinely broken, but the process itself is fine
    print(f"Naive liveness probe: {gray_service.liveness_probe()} (expected: True - FALSE CONFIDENCE)")
    print(f"Naive readiness probe: {gray_service.readiness_probe_naive()} (expected: True - ALSO false confidence)")
    print("A load balancer trusting either of these would keep routing REAL traffic to a broken service")

    print()
    print("--- TEST 9: THE FIX - a deep readiness probe correctly detects the gray failure ---")
    deep_result = gray_service.readiness_probe_deep()
    print(f"Deep readiness probe (exercises a real call): {deep_result} (expected: False - correctly detects "
          f"the actual problem, not just 'is the process running')")

    print()
    print("--- TEST 10: Once the real dependency recovers, the deep probe correctly reflects that too ---")
    gray_service.real_calls_succeed = True
    recovered_result = gray_service.readiness_probe_deep()
    print(f"Deep readiness probe after real recovery: {recovered_result} (expected: True)")
