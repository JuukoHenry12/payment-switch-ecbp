"""
split_brain_and_circuit_breaker.py — closes two confirmed gaps.

PART 1: split-brain. multiregion_dr.py's simulate_region_failure()
assumed a region cleanly disappears - detected, unambiguous. A
network PARTITION is more dangerous: both regions are actually
healthy, but can no longer see each other, and each might
independently decide it should be the active one. Without a quorum
mechanism, this produces exactly the same danger proven in
active_active_analysis.py's Test 3 - two "active" regions both
processing writes, none aware of the other, real financial
corruption - except now triggered by network failure, not a design
choice made in code.

PART 2: circuit breaker. card_authorization_service.py's
_fraud_check() has no defined behavior for what happens if the fraud
engine itself is unreachable, not merely returning ALLOW/BLOCK. This
is a real, undecided design choice - fail OPEN (allow the
transaction through, prioritizing availability) or fail CLOSED
(decline it, prioritizing safety) - and currently the code has no
answer at all, which in production usually means an unhandled
exception, the worst of both options.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum


# ------------------------------------------------------------
# PART 1: Split-brain prevention via quorum
# ------------------------------------------------------------
class RegionHealth(Enum):
    HEALTHY = "HEALTHY"
    UNREACHABLE = "UNREACHABLE"  # NOT the same as failed - it might be perfectly fine


@dataclass
class QuorumRegion:
    region_id: str
    can_see_others: set  # which other regions THIS region can currently reach


class QuorumCoordinator:
    """
    The real fix: a region may ONLY become or remain ACTIVE if it can
    reach a majority (quorum) of the total region count. This is
    what a tie-breaker/witness mechanism (a 3rd, lightweight
    arbitration node) provides in real systems - here modeled
    directly. With exactly 2 regions, quorum requires BOTH being
    reachable - meaning a partition between them correctly results
    in NEITHER claiming to be active, rather than both claiming it.
    """

    def __init__(self, total_regions: int):
        self.total_regions = total_regions

    def has_quorum(self, reachable_count_including_self: int) -> bool:
        return reachable_count_including_self > self.total_regions / 2


def naive_failover_decision(region_id: str, can_reach_active: bool) -> str:
    """
    THE DANGEROUS NAIVE APPROACH: 'if I can't reach the active region,
    I must be the surviving one, promote myself.' This is exactly
    what causes split-brain during a network PARTITION (as opposed
    to a genuine region failure) - because the OTHER region might be
    making the identical decision, about THIS region, at the same
    moment.
    """
    if not can_reach_active:
        return "PROMOTE_SELF_TO_ACTIVE"  # DANGEROUS - no way to know if this is a real failure or just a partition
    return "REMAIN_STANDBY"


def quorum_aware_failover_decision(coordinator: QuorumCoordinator, reachable_count: int) -> str:
    """THE FIX: only promote if quorum is actually held."""
    if coordinator.has_quorum(reachable_count):
        return "PROMOTE_SELF_TO_ACTIVE"
    return "REMAIN_STANDBY_INSUFFICIENT_QUORUM"


# ------------------------------------------------------------
# PART 2: Circuit breaker - explicit fail-open vs fail-closed policy
# ------------------------------------------------------------
class CircuitState(Enum):
    CLOSED = "CLOSED"      # normal operation, calls go through
    OPEN = "OPEN"           # dependency confirmed unhealthy, calls short-circuit immediately
    HALF_OPEN = "HALF_OPEN" # testing whether the dependency has recovered


class FailurePolicy(Enum):
    FAIL_OPEN = "FAIL_OPEN"      # allow the transaction through when the dependency is unreachable
    FAIL_CLOSED = "FAIL_CLOSED"  # decline the transaction when the dependency is unreachable


class FraudCheckCircuitBreaker:
    """
    Wraps the fraud check with an EXPLICIT, deliberate policy - no
    more undefined behavior. The policy choice itself is a real
    business decision, not a technical afterthought: FAIL_CLOSED
    (decline) is the correct default for FRAUD specifically, because
    the cost of a false decline is a customer inconvenience, while
    the cost of fail-open during a fraud-engine outage is genuine,
    unchecked fraud exposure - a materially worse outcome for a bank.
    """

    FAILURE_THRESHOLD = 3       # consecutive failures before opening the circuit
    RECOVERY_TIMEOUT_SECONDS = 30

    def __init__(self, fraud_check_fn, policy: FailurePolicy):
        self.fraud_check_fn = fraud_check_fn
        self.policy = policy
        self.state = CircuitState.CLOSED
        self.consecutive_failures = 0
        self.opened_at: datetime | None = None

    def check(self, account, amount, now: datetime) -> tuple[bool, str]:
        if self.state == CircuitState.OPEN:
            if now - self.opened_at >= timedelta(seconds=self.RECOVERY_TIMEOUT_SECONDS):
                self.state = CircuitState.HALF_OPEN
            else:
                return self._apply_policy("CIRCUIT_OPEN_FRAUD_ENGINE_UNAVAILABLE")

        try:
            allowed, reason = self.fraud_check_fn(account, amount)
            self.consecutive_failures = 0
            if self.state == CircuitState.HALF_OPEN:
                self.state = CircuitState.CLOSED  # the dependency recovered
            return allowed, reason
        except Exception as e:
            self.consecutive_failures += 1
            if self.consecutive_failures >= self.FAILURE_THRESHOLD:
                self.state = CircuitState.OPEN
                self.opened_at = now
            return self._apply_policy(f"FRAUD_ENGINE_ERROR: {e}")

    def _apply_policy(self, reason: str) -> tuple[bool, str]:
        if self.policy == FailurePolicy.FAIL_OPEN:
            return True, f"ALLOWED_DESPITE_FAILURE: {reason}"
        return False, f"DECLINED_DUE_TO_FAILURE: {reason}"


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: NAIVE failover - THE split-brain danger, both sides reasoning identically ===")
    print("Simulating a network PARTITION (not a real failure) between 2 regions -")
    print("both regions can genuinely still process traffic, they just can't see each other.")
    region_a_decision = naive_failover_decision("ap-southeast-1", can_reach_active=False)
    region_b_decision = naive_failover_decision("ap-southeast-2", can_reach_active=False)
    print(f"Region A's naive decision: {region_a_decision}")
    print(f"Region B's naive decision: {region_b_decision}")
    print(f"SPLIT BRAIN: both regions decide to promote themselves: "
          f"{region_a_decision == region_b_decision == 'PROMOTE_SELF_TO_ACTIVE'} (expected: True - "
          f"this is the exact real danger, both now believe they are the sole active region)")

    print()
    print("=== TEST 2: THE FIX - quorum-aware decision, correctly refuses to promote during a 2-way partition ===")
    coordinator = QuorumCoordinator(total_regions=2)
    # During a partition between exactly 2 regions, each can only
    # see ITSELF (1 of 2) - correctly insufficient for quorum.
    decision_a = quorum_aware_failover_decision(coordinator, reachable_count=1)
    decision_b = quorum_aware_failover_decision(coordinator, reachable_count=1)
    print(f"Region A's quorum-aware decision: {decision_a}")
    print(f"Region B's quorum-aware decision: {decision_b}")
    print(f"NEITHER promotes - correctly refuses to guess: "
          f"{decision_a == decision_b == 'REMAIN_STANDBY_INSUFFICIENT_QUORUM'} (expected: True)")
    print("(the honest cost: during a 2-way partition with no 3rd witness, NEITHER region serves")
    print(" writes - correctly prioritizing safety over availability, exactly the right tradeoff")
    print(" for a payment system, at the cost of an outage until the partition heals or a human intervenes)")

    print()
    print("=== TEST 3: A genuine 3-region quorum correctly DOES allow failover, unlike the 2-region case ===")
    coordinator3 = QuorumCoordinator(total_regions=3)
    decision_3region = quorum_aware_failover_decision(coordinator3, reachable_count=2)  # 2 of 3 = majority
    print(f"With 2 of 3 regions reachable: {decision_3region} (expected: PROMOTE_SELF_TO_ACTIVE - "
          f"a real majority genuinely exists, unlike the ambiguous 2-region case)")

    print()
    now = datetime(2026, 8, 9, 16, 0, 0)
    print("=== TEST 4: Circuit breaker, FAIL_CLOSED policy - fraud engine unreachable, transaction correctly DECLINED ===")
    def always_fails(account, amount):
        raise ConnectionError("fraud-service unreachable")

    breaker_closed = FraudCheckCircuitBreaker(always_fails, policy=FailurePolicy.FAIL_CLOSED)
    for _ in range(FraudCheckCircuitBreaker.FAILURE_THRESHOLD):
        allowed, reason = breaker_closed.check("ACC0001234", 100.00, now)
    print(f"After {FraudCheckCircuitBreaker.FAILURE_THRESHOLD} consecutive failures - allowed: {allowed}, reason: {reason}")
    print(f"Circuit state: {breaker_closed.state.value} (expected: OPEN)")
    print(f"Correctly DECLINED (not silently allowed) once the circuit trips: {not allowed} (expected: True)")

    print()
    print("=== TEST 5: The SAME failure, but FAIL_OPEN policy - transaction correctly ALLOWED, business tradeoff made explicit ===")
    breaker_open = FraudCheckCircuitBreaker(always_fails, policy=FailurePolicy.FAIL_OPEN)
    for _ in range(FraudCheckCircuitBreaker.FAILURE_THRESHOLD):
        allowed2, reason2 = breaker_open.check("ACC0001234", 100.00, now)
    print(f"Allowed: {allowed2}, reason: {reason2}")
    print(f"Correctly ALLOWED under fail-open policy: {allowed2} (expected: True - the SAME failure, ")
    print(f"a DIFFERENT, deliberately chosen outcome, proving the policy is what decides this, not chance)")

    print()
    print("=== TEST 6: Recovery - once the fraud engine comes back, the circuit correctly closes again ===")
    def now_works(account, amount):
        return True, "CLEAR"

    breaker_recovering = FraudCheckCircuitBreaker(always_fails, policy=FailurePolicy.FAIL_CLOSED)
    for _ in range(FraudCheckCircuitBreaker.FAILURE_THRESHOLD):
        breaker_recovering.check("ACC0001234", 100.00, now)
    print(f"Circuit state after failures: {breaker_recovering.state.value} (expected: OPEN)")

    breaker_recovering.fraud_check_fn = now_works  # the dependency has genuinely recovered
    later = now + timedelta(seconds=35)  # past the 30s recovery timeout
    allowed3, reason3 = breaker_recovering.check("ACC0001234", 100.00, later)
    print(f"After recovery timeout + a working call: allowed={allowed3}, reason={reason3}")
    print(f"Circuit correctly closed again: {breaker_recovering.state.value == 'CLOSED'} (expected: True)")
