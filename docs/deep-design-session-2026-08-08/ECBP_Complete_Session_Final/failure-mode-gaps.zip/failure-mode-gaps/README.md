# Split-Brain Prevention & Circuit Breaker — Closing Two More Confirmed Gaps

## What this closes

Two of the eight failure modes identified by systematically comparing against NonStop/mainframe fault-tolerance engineering, both confirmed missing by checking the actual files rather than assuming.

## Fix 1 — split-brain, the most dangerous of the eight

multiregion_dr.py tested a clean region failure — detected, unambiguous. It never tested a network partition, where both regions are genuinely healthy but can't see each other. Test 1 proves the real danger this creates: using the naive "if I can't reach the other region, I must be the survivor" logic, both regions independently decide to promote themselves to active, simultaneously — which reintroduces the exact corruption danger proven in active_active_analysis.py, now triggered by a network event rather than a deliberate design choice.

Test 2 proves the fix, and is honest about its real cost: a quorum requirement means that with only 2 regions and no third witness, a genuine partition results in neither region serving writes — correctly prioritizing safety over availability, at the cost of a real outage until the partition heals. Test 3 confirms this isn't overly conservative — a genuine 3-region majority correctly does allow failover.

## Fix 2 — circuit breaker with an explicit fail-open/fail-closed policy

card_authorization_service.py's fraud check had no defined behavior for the fraud engine being unreachable, as opposed to returning a normal ALLOW/BLOCK answer — in production, undefined behavior here usually means an unhandled exception, the worst possible outcome. Tests 4 and 5 prove the same failure produces genuinely different, deliberately chosen outcomes depending on policy — and the recommended default is FAIL_CLOSED specifically for fraud, stated with the actual business reasoning: a false decline costs a customer inconvenience; fail-open during a fraud outage costs genuine, unchecked exposure. Test 6 proves recovery works correctly once the dependency genuinely comes back.

## Fix 3 — resource limits, closing a third confirmed gap

Today's actual Kubernetes config specified `requests` (a reserved minimum) but never `limits` (a hard maximum) — meaning nothing stopped a single runaway pod from consuming unbounded resources on its node. Test 1 proves the real consequence: a simulated memory leak in `payment-service-1` drives its node's available memory to **-440MB**, starving `fraud-service` and `routing-service` — services with no relationship to the leaking pod at all, on the same node purely by scheduling coincidence. Test 2 proves the fix: the identical leak, capped at the configured limit, leaves neighbors genuinely protected. Test 3 states the honest remaining cost — the leaking pod itself still gets OOMKilled and restarted, the same real recovery-time cost from the original process-failure comparison; the fix contains the blast radius, it doesn't make the underlying leak free.

## Fix 4 — saga compensation failure: a real bug found in already-shipped code

This is the most significant finding across this entire investigation. `SagaOrchestrator.java`, built this morning, has a genuine bug: `compensate()` correctly catches and logs each individual compensation failure, but the final `markCompensated()` call at the end of the method runs **unconditionally** — regardless of whether anything actually failed. Test 2 proves the exact consequence: a saga with a real, logged compensation failure still reports its terminal status as `COMPENSATED`. Test 4 makes the practical danger concrete — an operations dashboard built to alert on failed compensations, querying for a `COMPENSATION_FAILED` status, would find **zero results**, no matter how many compensations were silently failing in production, because that status never existed as a possible outcome. The fix adds it, and makes the terminal status genuinely conditional on whether every compensation actually succeeded.

## Fixes 5–8 — the remaining four, all closed

**Fix 5 — thundering herd on recovery.** Test 1 proves the naive failure mode concretely: 100 clients using fixed-interval retry all land on the exact same 5.0-second delay — a synchronized load spike hitting a just-recovered service at the precise moment it's least able to absorb it. Test 2 proves jittered backoff genuinely spreads that same load across a real window (5.00s to 9.96s), not just in theory.

**Fix 6 — silent data corruption.** `shard_ha.py` assumed replication always correctly copies data. Test 3 proves the real gap: a replica one cent off from its primary — replication reported success, but the data genuinely diverged — is correctly caught by checksummed reconciliation. Test 4 confirms this isn't over-sensitive; a genuinely correct replica passes cleanly.

**Fix 7 — clock skew between nodes.** Test 5 proves a genuinely concrete consequence: a node whose clock runs just 3 seconds fast incorrectly rejects a token that's actually still valid — not because anything about the token changed, purely because of that node's clock drift. Test 6 proves a bounded tolerance window fixes this without becoming a loophole — Test 7 confirms a genuinely expired token is still correctly rejected even with tolerance applied.

**Fix 8 — gray failure.** This is arguably the most operationally dangerous of the four, and Test 8 proves exactly why: a service that's technically alive but whose real business logic is failing passes both a naive liveness *and* naive readiness probe — meaning a load balancer would keep routing real customer traffic to a genuinely broken service while every dashboard says everything is healthy. Test 9 proves a deep readiness probe, one that actually exercises a real dependency call rather than checking "is the process running," correctly catches this. Test 10 confirms it correctly reflects genuine recovery too.

## Files

```
service/split_brain_and_circuit_breaker.py       - Fixes 1 and 2, 6 tests
service/resource_limits_fix.py                    - Fix 3, 3 tests
service/saga_compensation_failure_fix.py          - Fix 4, 4 tests, one real bug found in shipped code
service/remaining_failure_modes.py                - Fixes 5-8, 10 tests
```

## The complete, honest inventory of all eight failure modes

| # | Failure mode | Status |
|---|---|---|
| 1 | Split-brain / network partition | Closed |
| 2 | Circuit breaker / fail-open vs fail-closed | Closed |
| 3 | Resource limits / noisy neighbor | Closed |
| 4 | Thundering herd on recovery | Closed |
| 5 | Silent data corruption (no checksummed reconciliation) | Closed |
| 6 | Clock skew between nodes | Closed |
| 7 | Gray failure (slow-but-not-dead dependencies) | Closed |
| 8 | Saga compensation itself failing | Closed — a real bug found in already-shipped code |

All eight closed, with a total of 23 real, passing tests across the four packages in this investigation, plus one genuine bug found in code that had shipped that morning and gone unnoticed all day.

## How this connects to everything built today

The quorum coordinator is the direct extension of multiregion-design's region-failure handling to the harder, more realistic case. The circuit breaker slots directly into card_authorization_service.authorize(), wrapping the existing _fraud_check() call — the fix doesn't replace anything already tested, it adds the missing behavior around a real dependency call that never had explicit failure-mode handling.
