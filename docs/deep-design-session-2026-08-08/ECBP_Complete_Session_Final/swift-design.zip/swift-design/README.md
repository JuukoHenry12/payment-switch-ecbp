# SWIFT ISO 20022 Gateway — Design Package

## What this closes

Every design document today referenced pacs.008, structured addresses, and the November 2026 deadline — none of it had ever actually been built as real XML. This package genuinely constructs, validates, and round-trips a real ISO 20022 `pacs.008.001.08` (FIToFICustomerCreditTransfer) message.

## Two real issues found while testing this, both worth reading closely

**Issue 1 — a weak validator.** The first version checked BIC "validity" purely by length (8 or 11 characters). A placeholder test value, `"TOOSHORT"`, happened to be exactly 8 characters and passed — silently proving nothing. Fixed with an actual BIC format regex (4 letters bank code + 2 letters country code + 2 alphanumeric location code + optional 3 alphanumeric branch code).

**Issue 2 — the fix's own first test was also wrong, and this is the more valuable lesson.** The replacement test value, again `"TOOSHORT"`, turned out to *also* satisfy the new regex — 8 uppercase letters happens to be a structurally valid BIC shape, even though no human would mistake it for a real bank code. This is not a bug in the regex; it's a genuine, important limitation to understand: **format validation proves shape, never real-world meaning.** A regex can confirm a string *could* be a BIC. It can never confirm the string corresponds to an actual registered institution — that requires a real BIC directory lookup, which is explicitly out of scope for a personal project (real BIC directories are licensed, institutional data, not open to freely query). Worth stating this limitation honestly rather than implying the validator does more than it does.

## Files

```
ddl/swift_ddl.sql          - SWIFT_MESSAGE_LOG, correlating settlement_id/txn_id to the actual wire message
service/swift_gateway.py   - real message construction and validation, tested against 5 scenarios
```

## Verified, working — 5 real tests

1. **Build a real pacs.008** for TXN-003 (the cross-border transaction from the observability session) — genuine, structurally correct XML
2. **Validate a correct message** — passes cleanly, zero errors
3. **Round-trip integrity** — parse the built XML back and confirm the EndToEndId matches exactly what was set
4. **Reject a genuinely malformed BIC** (after the two-round fix above) — lowercase letters and digits in bank-code position, which no real BIC pattern permits
5. **Reject a missing structured address** — specifically enforcing the November 2026 requirement, not just checking for *an* address field

## How this ties into everything built today

```
TXN-003 (from today's observability session) needs external settlement
        │
        ▼
settlement-service: SettlementDecisionEngine determines this needs
an outgoing SWIFT message (settlement account type = NOSTRO)
        │
        ▼
swift_gateway.build_pacs008() constructs the real ISO 20022 message,
using the SAME txn_id that correlates the CQRS read model, the
structured logs, and the distributed trace from the observability
package
        │
        ▼
validate_pacs008() confirms structural correctness BEFORE transmission
        │
        ▼
SWIFT_MESSAGE_LOG records the message, keyed by both settlement_id
and the SWIFT-native end_to_end_id, for the reconciliation-service
timeout sweep to eventually correlate against an incoming
ExternalSettlementConfirmed or a late failure
```

## Honest limitation, stated plainly

This builds and validates one message type (`pacs.008`) for one straightforward single-transaction case. Real production SWIFT integration needs: `pain.001`, `camt.056` (cancellation), multi-transaction batch messages, full CBPR+ usage-guideline validation (a genuinely large specification), and actual network connectivity via a licensed SWIFT service bureau — none of which a personal project can obtain, consistent with the institutional-boundary honesty established throughout today's entire design session.
