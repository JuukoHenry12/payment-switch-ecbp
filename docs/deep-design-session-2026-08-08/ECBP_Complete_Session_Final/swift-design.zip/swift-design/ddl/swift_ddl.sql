-- ============================================================
-- ECBP SWIFT Gateway — DDL
-- ============================================================
-- Bridges an internal SETTLEMENT_INSTRUCTION (for a NOSTRO-type
-- settlement account) to a real ISO 20022 message. This is
-- deliberately separate from SETTLEMENT_INSTRUCTION itself - the
-- settlement engine's job is "did the money move," this table's job
-- is "what exact wire message represented that movement," since a
-- single settlement can, in principle, require message amendment or
-- cancellation (camt.056) after the fact, which needs its own
-- tracked lifecycle distinct from the settlement's own state.
-- ============================================================

CREATE TABLE SWIFT_MESSAGE_LOG (
    MESSAGE_ID              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    SETTLEMENT_ID              UUID          NOT NULL,   -- FK to SETTLEMENT_INSTRUCTION
    TXN_ID                       UUID        NOT NULL,   -- same correlation key as everything else today
    MESSAGE_TYPE                   VARCHAR(20) NOT NULL, -- pacs.008, pain.001, camt.056
    END_TO_END_ID                    VARCHAR(35) NOT NULL, -- SWIFT's own correlation field, distinct from ECBP's txn_id
    RAW_XML                            TEXT      NOT NULL,
    VALIDATION_STATUS                    VARCHAR(20) NOT NULL, -- VALID, INVALID
    VALIDATION_ERRORS                      TEXT    NULL,
    SENT_AT                                  TIMESTAMPTZ NULL,
    CREATED_AT                                 TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_SWIFT_MSG_SETTLEMENT ON SWIFT_MESSAGE_LOG (SETTLEMENT_ID);
CREATE INDEX IDX_SWIFT_MSG_E2E ON SWIFT_MESSAGE_LOG (END_TO_END_ID);
-- The E2E ID index matters specifically because that's the field a
-- correspondent bank's own systems will reference back to ECBP with
-- in any status/exception message - it needs to be a fast lookup.
