# Open Banking / Section 1033 & PSD3 Compliance — Design Package

## Why this was the correct next priority

Every other gap on the checklist is a competitive or operational best practice. This one is different: **CFPB Section 1033 (finalized October 2024, US) legally requires** exposing consumer financial data via open APIs to authorized third parties, and the EU's PSD3 is simultaneously strengthening the equivalent requirement. This package closes that gap with the two properties both frameworks actually demand: **scoped, time-limited, instantly revocable consent** — never blanket access, never indefinite, never silent.

## Files

```
ddl/open_banking_ddl.sql              - THIRD_PARTY_PROVIDER, CONSUMER_CONSENT, OPEN_BANKING_ACCESS_LOG
service/open_banking_gateway.py       - two independent enforcement gates, tested against 7 real scenarios
```

## Verified, working — 7 real scenarios, covering every failure mode a real examiner would probe

1. **Valid, correctly-scoped consent** — granted
2. **The core scoped-access test** — the same TPP, same account, same trusted relationship, but requesting a *different* data category than was actually consented to — correctly denied. Consenting to share your balance does not imply consenting to share your full transaction history, even with a provider you already trust
3. **No consent at all** — denied
4. **An uncertified TPP** — denied outright, checked *before* consent is even examined, proving TPP certification and consumer consent are two independent, both-required gates, not one substituting for the other
5. **Expired consent** — denied, even though it was genuinely valid at the time it was granted
6. **The most legally important test: revocation** — the exact same request, at the exact same instant in time, flips from `GRANTED` to `DENIED_REVOKED` the moment consent is pulled. This directly proves the consumer's right to immediately cut off access, not "at next renewal" or "within some grace period"
7. **Complete, unconditional audit trail** — all 6 prior attempts, granted and denied alike, recorded — exactly what a Section 1033 examination reviews

## Why two independent gates, not one combined check

A weaker design might check "is there a valid consent" as a single condition. This deliberately separates **TPP certification** (is this third party even allowed to participate in the ecosystem) from **consumer consent** (did *this specific* customer authorize *this specific* data category to *this specific* provider). Test 4 exists specifically to prove neither gate can substitute for the other — a consent record existing for an uncertified TPP should never happen in practice, but the gateway checks it anyway as genuine defense in depth, not blind trust in upstream registration processes.

## How this connects to everything built today

```
Third-party fintech app requests account data
        │
        ▼
OpenBankingGateway.request_access()
        │
        ├── GATE 1: TPP certification check (THIRD_PARTY_PROVIDER)
        │
        └── GATE 2: CONSUMER_CONSENT check — scope, expiry, revocation
                │
                ▼
        Every outcome (granted or denied) → OPEN_BANKING_ACCESS_LOG
                │
                ▼
        Same journaling philosophy as journal-design earlier today —
        one place, complete story, no reconstruction needed for
        an examiner or a support engineer investigating access history
```

The `api-gateway` package built earlier handles authentication and rate limiting generically; this package is the domain-specific layer sitting behind it, specifically for third-party consumer-data access — the two are complementary, not duplicated.

## Honest limitations, stated plainly

- **PISP (payment-initiation) specific flows** — this package proves the AISP (read-only account information) consent model correctly; payment-initiation consent carries additional real-world requirements (strong customer authentication at the moment of initiation, not just at consent time) not built here
- **The actual TPP certification/registration process** (verifying a third party's real-world regulatory standing before marking them `CERTIFIED`) is represented as a simple status field — the real onboarding and ongoing compliance verification of TPPs is a genuine, separate operational process, not something this package's logic performs
- **Consent renewal UX/notification flows** (proactively telling a consumer their consent is about to expire) are not built — this package proves the enforcement is correct at the moment of access, not the customer-facing consent lifecycle experience around it
