-- ============================================================
-- ECBP Open Banking / Section 1033 & PSD3 Compliance — DDL
-- ============================================================
-- Grounded in confirmed current requirements: CFPB Section 1033
-- (finalized October 2024, US) and PSD3 (EU) both require SCOPED,
-- CONSENT-BASED, REVOCABLE third-party access to consumer financial
-- data - never blanket access, never indefinite, never silent.
-- ============================================================

CREATE TABLE THIRD_PARTY_PROVIDER (
    TPP_ID                    VARCHAR(30)    PRIMARY KEY,
    TPP_NAME                      VARCHAR(200) NOT NULL,
    TPP_TYPE                          VARCHAR(10) NOT NULL,  -- AISP (read-only account info) or PISP (can initiate payments)
    REGISTRATION_STATUS                  VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, CERTIFIED, SUSPENDED, REVOKED
    CERTIFIED_AT                            TIMESTAMPTZ NULL,
    CREATED_AT                                TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- A TPP existing in this table does NOT mean it can access anything -
-- REGISTRATION_STATUS must be CERTIFIED, and separately, an actual
-- consumer consent must exist. Both gates are required, neither
-- alone is sufficient - enforced explicitly in the gateway below.

CREATE TABLE CONSUMER_CONSENT (
    CONSENT_ID                UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    ACCOUNT_ID                    VARCHAR(20) NOT NULL,   -- links to Phase 1's ACCOUNT table
    TPP_ID                           VARCHAR(30) NOT NULL REFERENCES THIRD_PARTY_PROVIDER(TPP_ID),
    SCOPES                              VARCHAR(30)[] NOT NULL,  -- e.g. {'ACCOUNT_BALANCE','TRANSACTION_HISTORY'} - NEVER a blanket "ALL"
    STATUS                                 VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',  -- ACTIVE, EXPIRED, REVOKED
    GRANTED_AT                                TIMESTAMPTZ NOT NULL DEFAULT now(),
    EXPIRES_AT                                  TIMESTAMPTZ NOT NULL,  -- consent MUST be time-limited, never indefinite
    REVOKED_AT                                    TIMESTAMPTZ NULL
);

CREATE INDEX IDX_CONSENT_ACCOUNT ON CONSUMER_CONSENT (ACCOUNT_ID, STATUS);
CREATE INDEX IDX_CONSENT_TPP ON CONSUMER_CONSENT (TPP_ID, STATUS);

CREATE TABLE OPEN_BANKING_ACCESS_LOG (
    ACCESS_ID                 UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    TPP_ID                        VARCHAR(30) NOT NULL,
    ACCOUNT_ID                       VARCHAR(20) NOT NULL,
    REQUESTED_SCOPE                     VARCHAR(30) NOT NULL,
    OUTCOME                                VARCHAR(20) NOT NULL,  -- GRANTED, DENIED_NO_CONSENT, DENIED_SCOPE_MISMATCH,
                                                                    -- DENIED_EXPIRED, DENIED_REVOKED, DENIED_TPP_NOT_CERTIFIED
    ACCESSED_AT                               TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_OB_ACCESS_ACCOUNT ON OPEN_BANKING_ACCESS_LOG (ACCOUNT_ID, ACCESSED_AT);
-- This is precisely what a Section 1033 examiner reviews: a complete,
-- unconditional record of every access attempt - granted or denied -
-- against every consumer's data, by every third party, ever.
