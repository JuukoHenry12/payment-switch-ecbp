"""
open_banking_gateway.py — the actual enforcement point for
Section 1033 / PSD3 compliant third-party access. Two independent
gates, BOTH required, tested separately: (1) the TPP itself must be
certified, and (2) a valid, scoped, non-expired, non-revoked consumer
consent must exist for the EXACT data category requested. Neither
gate alone is sufficient - a certified TPP with no consent is denied,
and a valid consent for an uncertified TPP should never exist in the
first place, but is checked anyway as defense in depth.

Every single attempt - granted or denied - is logged unconditionally,
which is precisely what a real regulatory examination reviews.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum


class TppStatus(Enum):
    PENDING = "PENDING"
    CERTIFIED = "CERTIFIED"
    SUSPENDED = "SUSPENDED"
    REVOKED = "REVOKED"


class ConsentStatus(Enum):
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"


class AccessOutcome(Enum):
    GRANTED = "GRANTED"
    DENIED_TPP_NOT_CERTIFIED = "DENIED_TPP_NOT_CERTIFIED"
    DENIED_NO_CONSENT = "DENIED_NO_CONSENT"
    DENIED_SCOPE_MISMATCH = "DENIED_SCOPE_MISMATCH"
    DENIED_EXPIRED = "DENIED_EXPIRED"
    DENIED_REVOKED = "DENIED_REVOKED"


@dataclass
class ThirdPartyProvider:
    tpp_id: str
    tpp_type: str  # AISP or PISP
    status: TppStatus


@dataclass
class Consent:
    consent_id: str
    account_id: str
    tpp_id: str
    scopes: set[str]
    status: ConsentStatus
    expires_at: datetime


class OpenBankingGateway:

    def __init__(self):
        self.tpps: dict[str, ThirdPartyProvider] = {}
        self.consents: dict[str, Consent] = {}
        self.access_log: list[dict] = []

    def register_tpp(self, tpp_id: str, tpp_type: str, status: TppStatus = TppStatus.CERTIFIED):
        self.tpps[tpp_id] = ThirdPartyProvider(tpp_id, tpp_type, status)

    def grant_consent(self, account_id: str, tpp_id: str, scopes: set[str],
                       duration_days: int, now: datetime) -> Consent:
        """Consent is ALWAYS time-limited - there is no code path
        that creates an indefinite consent, matching the real
        regulatory requirement directly, not as an optional parameter
        someone could accidentally leave unset."""
        consent_id = f"CONSENT-{account_id}-{tpp_id}-{len(self.consents)}"
        consent = Consent(
            consent_id=consent_id, account_id=account_id, tpp_id=tpp_id,
            scopes=scopes, status=ConsentStatus.ACTIVE,
            expires_at=now + timedelta(days=duration_days),
        )
        self.consents[consent_id] = consent
        return consent

    def revoke_consent(self, consent_id: str):
        """The consumer's right to revoke access at any time -
        immediate and permanent, checked at the very next access
        attempt regardless of how much time remains before expiry."""
        consent = self.consents.get(consent_id)
        if consent:
            consent.status = ConsentStatus.REVOKED

    def request_access(self, tpp_id: str, account_id: str, requested_scope: str, now: datetime) -> AccessOutcome:

        # GATE 1: is the TPP itself certified? Checked FIRST and
        # independently - an uncertified TPP is denied regardless of
        # any consent that might technically exist.
        tpp = self.tpps.get(tpp_id)
        if tpp is None or tpp.status != TppStatus.CERTIFIED:
            outcome = AccessOutcome.DENIED_TPP_NOT_CERTIFIED
            self._log(tpp_id, account_id, requested_scope, outcome, now)
            return outcome

        # GATE 2: find this specific account+TPP's consent, and check
        # it against every real failure mode independently.
        matching_consent = next(
            (c for c in self.consents.values() if c.account_id == account_id and c.tpp_id == tpp_id), None)

        if matching_consent is None:
            outcome = AccessOutcome.DENIED_NO_CONSENT
        elif matching_consent.status == ConsentStatus.REVOKED:
            outcome = AccessOutcome.DENIED_REVOKED
        elif now > matching_consent.expires_at:
            outcome = AccessOutcome.DENIED_EXPIRED
        elif requested_scope not in matching_consent.scopes:
            # THE key scoped-access test - consent for ONE data
            # category does not imply consent for ANY other category,
            # even from the same TPP for the same account.
            outcome = AccessOutcome.DENIED_SCOPE_MISMATCH
        else:
            outcome = AccessOutcome.GRANTED

        self._log(tpp_id, account_id, requested_scope, outcome, now)
        return outcome

    def _log(self, tpp_id, account_id, scope, outcome, now):
        # Unconditional - every attempt, granted or denied, exactly
        # what a Section 1033 examination reviews.
        self.access_log.append({
            "tpp_id": tpp_id, "account_id": account_id, "scope": scope,
            "outcome": outcome, "at": now,
        })


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    now = datetime(2026, 8, 8, 12, 0, 0)
    gateway = OpenBankingGateway()

    gateway.register_tpp("TPP-BUDGET-APP", tpp_type="AISP", status=TppStatus.CERTIFIED)
    gateway.register_tpp("TPP-UNCERTIFIED", tpp_type="AISP", status=TppStatus.PENDING)

    print("=== TEST 1: Valid consent, correct scope - access GRANTED ===")
    gateway.grant_consent("ACC0001234", "TPP-BUDGET-APP", scopes={"ACCOUNT_BALANCE"}, duration_days=90, now=now)
    result1 = gateway.request_access("TPP-BUDGET-APP", "ACC0001234", "ACCOUNT_BALANCE", now)
    print(f"Outcome: {result1.value} (expected: GRANTED)")

    print()
    print("=== TEST 2: Same TPP, same account, but requesting a DIFFERENT scope than consented - DENIED ===")
    print("(this is the core scoped-access test - consent to see balance does NOT imply consent")
    print(" to see full transaction history, even from the same trusted TPP)")
    result2 = gateway.request_access("TPP-BUDGET-APP", "ACC0001234", "TRANSACTION_HISTORY", now)
    print(f"Outcome: {result2.value} (expected: DENIED_SCOPE_MISMATCH)")

    print()
    print("=== TEST 3: No consent exists at all for this TPP+account pair - DENIED ===")
    result3 = gateway.request_access("TPP-BUDGET-APP", "ACC0009999", "ACCOUNT_BALANCE", now)
    print(f"Outcome: {result3.value} (expected: DENIED_NO_CONSENT)")

    print()
    print("=== TEST 4: An UNCERTIFIED TPP is denied outright, even if consent technically exists ===")
    gateway.grant_consent("ACC0005678", "TPP-UNCERTIFIED", scopes={"ACCOUNT_BALANCE"}, duration_days=90, now=now)
    result4 = gateway.request_access("TPP-UNCERTIFIED", "ACC0005678", "ACCOUNT_BALANCE", now)
    print(f"Outcome: {result4.value} (expected: DENIED_TPP_NOT_CERTIFIED - the TPP gate is checked FIRST, "
          f"independently of consent)")

    print()
    print("=== TEST 5: EXPIRED consent - access correctly denied even though it was once valid ===")
    expired_now = now + timedelta(days=91)  # 1 day past the 90-day consent duration
    result5 = gateway.request_access("TPP-BUDGET-APP", "ACC0001234", "ACCOUNT_BALANCE", expired_now)
    print(f"Outcome: {result5.value} (expected: DENIED_EXPIRED)")

    print()
    print("=== TEST 6: REVOKED consent - the consumer's right to immediately cut off access ===")
    gateway.grant_consent("ACC0002222", "TPP-BUDGET-APP", scopes={"ACCOUNT_BALANCE"}, duration_days=90, now=now)
    result_before_revoke = gateway.request_access("TPP-BUDGET-APP", "ACC0002222", "ACCOUNT_BALANCE", now)
    print(f"Before revocation: {result_before_revoke.value} (expected: GRANTED)")

    consent_to_revoke = next(c for c in gateway.consents.values()
                               if c.account_id == "ACC0002222" and c.tpp_id == "TPP-BUDGET-APP")
    gateway.revoke_consent(consent_to_revoke.consent_id)
    result_after_revoke = gateway.request_access("TPP-BUDGET-APP", "ACC0002222", "ACCOUNT_BALANCE", now)
    print(f"Immediately after revocation, same moment in time: {result_after_revoke.value} "
          f"(expected: DENIED_REVOKED - access stops instantly, not at next expiry)")

    print()
    print("=== TEST 7: Complete, unconditional audit trail - every attempt above is logged ===")
    print(f"Total access attempts logged: {len(gateway.access_log)}")
    for entry in gateway.access_log:
        print(f"  [{entry['outcome'].value}] TPP={entry['tpp_id']} account={entry['account_id']} "
              f"scope={entry['scope']}")
