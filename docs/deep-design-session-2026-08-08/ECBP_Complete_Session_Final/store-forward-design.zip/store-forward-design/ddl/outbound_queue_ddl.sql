-- ============================================================
-- ECBP Store-and-Forward Outbound Queue — DDL
-- ============================================================
-- The direct relational equivalent of a NonStop queue file: a
-- message destined for an external system that's currently
-- unreachable is durably persisted here BEFORE anything is
-- acknowledged, sits safely for however long the outage lasts, and
-- is automatically delivered in order the moment the destination
-- recovers - closing the gap confirmed missing from swift-design
-- and every direct synchronous service call built today.
-- ============================================================

CREATE TABLE OUTBOUND_QUEUE_ENTRY (
    QUEUE_ENTRY_ID             UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    DESTINATION                    VARCHAR(30) NOT NULL,   -- e.g. 'SWIFT-NETWORK', 'CARD-NETWORK-VISA'
    TXN_ID                            UUID     NOT NULL,   -- same correlation key as every package today
    PAYLOAD                              TEXT   NOT NULL,   -- the actual message, e.g. a real pacs.008 XML body
    SEQUENCE_NUMBER                        BIGINT NOT NULL, -- strict ordering per destination, matching a
                                                              -- NonStop queue file's FIFO delivery guarantee
    STATUS                                    VARCHAR(20) NOT NULL DEFAULT 'QUEUED',  -- QUEUED, DELIVERED, FAILED
    QUEUED_AT                                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    DELIVERED_AT                                    TIMESTAMPTZ NULL
);

CREATE INDEX IDX_OUTBOUND_QUEUE_DEST ON OUTBOUND_QUEUE_ENTRY (DESTINATION, SEQUENCE_NUMBER)
    WHERE STATUS = 'QUEUED';
-- This index is what makes "give me everything still queued for
-- this destination, in the correct order" a fast, single query -
-- the exact operation that runs the instant a destination recovers.
