# Store-and-Forward Outbound Queue — Closing a Real, Confirmed Gap

## Direct answer to the question asked

Not automatically, and not everywhere — confirmed by checking, not assumed. swift_gateway.py had zero handling for "the destination is currently unreachable." Direct, synchronous calls throughout today's codebase (routing, token lifecycle, fraud checks) fail immediately if their dependency is down — that's precisely why the circuit breaker package was needed a few rounds ago, and a circuit breaker is a workaround for the absence of store-and-forward, not a substitute for it. Kafka, philosophically, is the same underlying idea as a NonStop queue file — durable persistence decoupling producer from consumer in time — but that protection only applies to what's deliberately routed through it, not to every interaction in the system automatically.

## What this closes

A genuine, tested equivalent of a NonStop queue file: durable persistence before acknowledgment, strict per-destination ordering, and fully automatic delivery the instant a destination recovers — no manual retry, no caller-side error handling required.

## Files

```
ddl/outbound_queue_ddl.sql          - OUTBOUND_QUEUE_ENTRY, with the index that makes ordered recovery fast
service/store_and_forward.py        - tested against 6 real scenarios
```

## Verified, working — 6 real scenarios

1. Normal operation — a reachable destination delivers immediately
2. The real scenario — the destination goes down, and messages correctly queue instead of failing
3. A third message queues while the outage continues, proving this isn't a single-message fluke
4. The proof that matters most — the destination recovers, and all three queued messages deliver automatically, in the exact correct order, with zero manual intervention
5. After recovery, a new message delivers immediately again — proving the system correctly returns to normal behavior, not stuck in permanent queue mode
6. The real integration — a genuine, correctly-constructed pacs.008 message from swift-design's actual build_pacs008() function queues safely during a simulated outage, proving this works with real payloads, not a placeholder string

## Why Test 4's ordering matters as much as the delivery itself

A queue that loses order during recovery is nearly as dangerous as one that loses messages — for a payment system, message B processed after message D instead of before it can mean events landing in the wrong sequence at the receiving end. The sequence_number field and the explicit sort in mark_destination_recovered() exist specifically to guarantee this never happens, matching the FIFO guarantee a NonStop queue file provides natively.

## How this connects to everything built today

```
swift_gateway.build_pacs008() constructs a real, valid message
        |
        v
StoreAndForwardQueue.send() — durably persists FIRST, attempts
immediate delivery second
        |
        +-- SWIFT reachable -> delivered immediately, same as today's earlier design
        |
        +-- SWIFT unreachable -> safely QUEUED, never lost, never an error
                    thrown back to the caller
                        |
                        v
        mark_destination_recovered() — the moment connectivity
        returns, every queued message delivers automatically,
        in the correct order
```

## Honest limitation

This proves the queuing and ordered-recovery logic is correct. It does not include real outage detection (health-check polling, connection-failure monitoring that would actually call mark_destination_down/mark_destination_recovered in production) — that's genuine, separate infrastructure work, the same honest boundary drawn between proven logic and live infrastructure throughout every package today.
