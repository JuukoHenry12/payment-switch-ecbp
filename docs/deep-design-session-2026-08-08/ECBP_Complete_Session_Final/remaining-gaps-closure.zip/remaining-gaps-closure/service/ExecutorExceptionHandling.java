

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ExecutorExceptionHandling — closes interview question #15's gap,
 * confirmed present in notification-design, batch-design, and
 * store-forward-design's async delivery paths: none of them ever
 * specified how an exception inside a submitted task actually
 * surfaces. The real, classic danger: submit() returns a Future, and
 * an exception thrown inside that task is captured SILENTLY - it
 * only surfaces if something calls .get() on that specific Future.
 * If nobody does (a common, easy mistake in fire-and-forget async
 * code, exactly the shape of a notification retry or a store-and-
 * forward delivery attempt), the failure vanishes with no log, no
 * alert, nothing.
 */
public class ExecutorExceptionHandling {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("=== TEST 1: THE DANGER - submit() with a failing task, Future never checked ===");
        try (ExecutorService naiveExecutor = Executors.newFixedThreadPool(4)) {
            for (int i = 0; i < 10; i++) {
                final int taskId = i;
                naiveExecutor.submit(() -> {
                    if (taskId % 3 == 0) {
                        throw new RuntimeException("Delivery to destination failed for task " + taskId);
                    }
                    return "OK";
                });
                // THE BUG: the returned Future is never assigned, never
                // checked - any exception inside is now permanently lost.
            }
            naiveExecutor.shutdown();
            naiveExecutor.awaitTermination(5, TimeUnit.SECONDS);
        }
        System.out.println("Tasks submitted: 10, of which 4 should have thrown a real exception (task 0, 3, 6, 9)");
        System.out.println("Exceptions actually observed anywhere: 0 - completely silent, no log, no alert,");
        System.out.println("nothing indicating 4 real delivery failures ever happened. This is the exact,");
        System.out.println("confirmed shape of the gap in notification/batch/store-and-forward's async paths.");

        System.out.println();
        System.out.println("=== TEST 2: THE FIX - explicit Future collection, exceptions surfaced deliberately ===");
        AtomicInteger observedFailures = new AtomicInteger(0);
        java.util.List<Future<String>> futures = new java.util.ArrayList<>();
        try (ExecutorService fixedExecutor = Executors.newFixedThreadPool(4)) {
            for (int i = 0; i < 10; i++) {
                final int taskId = i;
                futures.add(fixedExecutor.submit(() -> {
                    if (taskId % 3 == 0) {
                        throw new RuntimeException("Delivery to destination failed for task " + taskId);
                    }
                    return "OK";
                }));
            }
            for (Future<String> f : futures) {
                try {
                    f.get();
                } catch (ExecutionException e) {
                    observedFailures.incrementAndGet();
                    System.out.println("  CAUGHT: " + e.getCause().getMessage());
                }
            }
            fixedExecutor.shutdown();
        }
        System.out.println("Exceptions actually observed: " + observedFailures.get() + " (expected: 4)");
        System.out.println("Every real failure surfaced deterministically - nothing silently lost.");

        System.out.println();
        System.out.println("=== TEST 3: THE PRODUCTION-CORRECT PATTERN - CompletableFuture with exceptionally() ===");
        System.out.println("(the real pattern for fire-and-forget async work - notification delivery,");
        System.out.println(" store-and-forward attempts - where nothing ever calls .get() by design,");
        System.out.println(" but a failure must STILL be reported, not silently dropped)");
        AtomicInteger reportedFailures = new AtomicInteger(0);
        CountDownLatch latch = new CountDownLatch(10);
        try (ExecutorService asyncExecutor = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < 10; i++) {
                final int taskId = i;
                CompletableFuture
                    .runAsync(() -> {
                        if (taskId % 3 == 0) {
                            throw new RuntimeException("Async delivery failed for task " + taskId);
                        }
                    }, asyncExecutor)
                    .exceptionally(ex -> {
                        reportedFailures.incrementAndGet();
                        System.out.println("  REPORTED (fire-and-forget, no .get() needed): " + ex.getCause().getMessage());
                        return null;
                    })
                    .whenComplete((r, ex) -> latch.countDown());
            }
            latch.await(5, TimeUnit.SECONDS);
        }
        System.out.println("Failures reported via exceptionally(), with zero explicit .get() calls anywhere: "
                + reportedFailures.get() + " (expected: 4)");
        System.out.println();
        System.out.println("This is the actual fix for notification-design, batch-design, and");
        System.out.println("store-forward-design's async paths - exceptionally() ensures a failure is");
        System.out.println("ALWAYS reported structurally, not dependent on a developer remembering to");
        System.out.println("call .get() on a Future nobody was ever going to check.");
    }
}
