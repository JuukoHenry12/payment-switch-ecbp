"""
performance_comparison.py — a REAL, measured comparison, not a
claim. Simulates the difference between (a) reading routing/fraud
config from a database on every single transaction, versus (b)
loading it into memory once and doing pure in-memory lookups. The
simulated "database read" includes a realistic round-trip delay -
this is what makes the comparison honest rather than a strawman.
"""

import time
import random


# A realistic simulated DB round-trip latency for a simple indexed
# lookup - genuinely on the low end of what a real network+DB call
# costs (local DB, good indexing, no contention). Real cross-AZ or
# heavily-loaded database calls are often significantly slower than
# this, meaning this comparison is actually CONSERVATIVE in the
# in-memory approach's favor, not exaggerated.
SIMULATED_DB_LATENCY_MS = 1.5


class DatabaseBackedRouting:
    """Simulates looking up routing config from a database on EVERY
    single transaction - the naive, slow approach."""

    def __init__(self, bin_table: dict):
        self._bin_table = bin_table  # stands in for the actual DB table

    def route(self, bin_value: str) -> str:
        time.sleep(SIMULATED_DB_LATENCY_MS / 1000.0)  # the actual DB round-trip cost
        return self._bin_table.get(bin_value, "UNMATCHED")


class InMemoryCachedRouting:
    """Loads the table ONCE at construction (startup), then every
    lookup is pure in-memory dict access - the real, correct approach."""

    def __init__(self, bin_table: dict):
        self._bin_table = dict(bin_table)  # loaded ONCE, at startup

    def route(self, bin_value: str) -> str:
        return self._bin_table.get(bin_value, "UNMATCHED")  # zero I/O, ever


# ------------------------------------------------------------
# REAL MEASUREMENT
# ------------------------------------------------------------
if __name__ == "__main__":

    bin_table = {f"{400000 + i}": "VISA" for i in range(1000)}
    bin_table.update({f"{510000 + i}": "MASTERCARD" for i in range(1000)})
    test_bins = [random.choice(list(bin_table.keys())) for _ in range(200)]

    print("=== TEST 1: Correctness - both approaches return IDENTICAL results ===")
    db_approach = DatabaseBackedRouting(bin_table)
    memory_approach = InMemoryCachedRouting(bin_table)

    sample_bins = test_bins[:10]
    db_results = [db_approach.route(b) for b in sample_bins]
    memory_results = [memory_approach.route(b) for b in sample_bins]
    print(f"Results identical: {db_results == memory_results} (expected: True - correctness must match before comparing speed)")

    print()
    print(f"=== TEST 2: REAL measured timing over 200 transactions, simulated DB latency = {SIMULATED_DB_LATENCY_MS}ms/call ===")

    start = time.perf_counter()
    for b in test_bins:
        db_approach.route(b)
    db_elapsed = time.perf_counter() - start

    start = time.perf_counter()
    for b in test_bins:
        memory_approach.route(b)
    memory_elapsed = time.perf_counter() - start

    print(f"Database-backed approach:  {db_elapsed*1000:.1f}ms total ({db_elapsed*1000/200:.3f}ms/transaction)")
    print(f"In-memory cached approach: {memory_elapsed*1000:.3f}ms total ({memory_elapsed*1000/200:.5f}ms/transaction)")
    print(f"Speedup factor: {db_elapsed/memory_elapsed:.0f}x faster")

    print()
    print("=== TEST 3: What this means at real transaction VOLUME - the actual point being made ===")
    for tps in [100, 1000, 10000]:
        db_time_per_sec = (db_elapsed / 200) * tps
        memory_time_per_sec = (memory_elapsed / 200) * tps
        print(f"At {tps:>6,} TPS: database approach needs {db_time_per_sec*1000:.0f}ms of routing-lookup time "
              f"per second of traffic{' -- EXCEEDS 1 real second, the system falls behind' if db_time_per_sec > 1 else ''}")
        print(f"{'':>15}in-memory approach needs {memory_time_per_sec*1000:.3f}ms of routing-lookup time per second - "
              f"negligible even at this volume")

    print()
    print("=== TEST 4: Cache freshness - the real tradeoff of in-memory caching, handled explicitly ===")
    print("(a BIN gets added to the routing table - the cache must eventually pick it up)")
    live_table = dict(bin_table)
    cached_engine = InMemoryCachedRouting(live_table)

    live_table["999999"] = "NEW_NETWORK"  # simulates an operator adding a new routing rule to the DB
    print(f"Immediately after the DB is updated, cached engine sees it: "
          f"{cached_engine.route('999999')} (expected: UNMATCHED - the cache is deliberately stale until refreshed)")

    cached_engine._bin_table = dict(live_table)  # simulates a periodic refresh (e.g. every 60s)
    print(f"After a periodic refresh picks up the change: "
          f"{cached_engine.route('999999')} (expected: NEW_NETWORK)")
