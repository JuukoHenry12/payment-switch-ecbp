"""
failure_diagnostics.py — standardized transaction failure logging,
directly addressing the real pain point named: legacy systems often
produce cryptic internal errors that don't map to any standard,
forcing support/dev teams to spend real time reconstructing root
cause. This uses REAL ISO 8583 field 39-style reason codes (the
actual standard, not an invented one), plus full structured context
- which service, which step, correlated by the same txn_id that's
threaded through every package built today.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone


# Mirrors REASON_CODE_REFERENCE from the DDL - real ISO 8583 field 39
# codes, not invented ones. In production this would be loaded into
# memory once (same principle as the routing engine above), not
# queried per-transaction.
REASON_CODES = {
    "00": {"description": "Approved", "category": "APPROVED", "retriable": False},
    "05": {"description": "Do not honor", "category": "CUSTOMER_ISSUE", "retriable": False},
    "14": {"description": "Invalid card number", "category": "CUSTOMER_ISSUE", "retriable": False},
    "51": {"description": "Insufficient funds", "category": "CUSTOMER_ISSUE", "retriable": False},
    "54": {"description": "Expired card", "category": "CUSTOMER_ISSUE", "retriable": False},
    "59": {"description": "Suspected fraud", "category": "RISK", "retriable": False},
    "61": {"description": "Exceeds withdrawal limit", "category": "RISK", "retriable": False},
    "91": {"description": "Issuer or network unavailable", "category": "NETWORK", "retriable": True},
    "96": {"description": "System malfunction", "category": "SYSTEM", "retriable": True},
    "R01": {"description": "Insufficient liquidity for RTGS settlement", "category": "SYSTEM", "retriable": True},
    "R02": {"description": "Reconciliation break - late external failure", "category": "SYSTEM", "retriable": False},
}


@dataclass
class TransactionFailureContext:
    """
    Everything a support engineer needs to root-cause a failure
    WITHOUT digging through five services' individual logs by hand -
    the exact complaint about legacy systems this directly answers.
    """
    txn_id: str
    reason_code: str
    failing_service: str
    failing_step: str
    correlation_ids: dict = field(default_factory=dict)  # e.g. {"saga_id": "...", "settlement_id": "..."}
    system_state_snapshot: dict = field(default_factory=dict)  # the ACTUAL values that led to the decision
    occurred_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_support_readable_summary(self) -> str:
        """
        This is genuinely the point: one function call produces a
        complete, human-readable root-cause summary from
        structured data - not a raw stack trace, not five separate
        log greps across five services.
        """
        code_info = REASON_CODES.get(self.reason_code, {"description": "UNKNOWN CODE", "category": "UNKNOWN", "retriable": False})

        lines = [
            f"=== TRANSACTION FAILURE SUMMARY ===",
            f"Transaction ID: {self.txn_id}",
            f"Occurred at:    {self.occurred_at.isoformat()}",
            f"Reason code:    {self.reason_code} - {code_info['description']}",
            f"Category:       {code_info['category']}",
            f"Retriable:      {code_info['retriable']}",
            f"Failed in:      {self.failing_service} (step: {self.failing_step})",
        ]

        if self.correlation_ids:
            lines.append("Correlated IDs (for cross-service log lookup):")
            for key, value in self.correlation_ids.items():
                lines.append(f"  {key}: {value}")

        if self.system_state_snapshot:
            lines.append("System state at time of failure (the actual values, not guesswork):")
            for key, value in self.system_state_snapshot.items():
                lines.append(f"  {key}: {value}")

        return "\n".join(lines)


def build_failure_context(txn_id: str, reason_code: str, failing_service: str,
                           failing_step: str, **context) -> TransactionFailureContext:
    if reason_code not in REASON_CODES:
        raise ValueError(f"'{reason_code}' is not a recognized standard reason code - "
                         f"every failure MUST use a code from the standard reference table, "
                         f"never an ad-hoc string, or support teams lose the ability to search/aggregate by code")
    return TransactionFailureContext(
        txn_id=txn_id, reason_code=reason_code, failing_service=failing_service,
        failing_step=failing_step, correlation_ids=context.get("correlation_ids", {}),
        system_state_snapshot=context.get("system_state_snapshot", {}),
    )


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: A real, complete failure trace - insufficient liquidity, tying together settlement + liquidity packages ===")
    ctx1 = build_failure_context(
        txn_id="TXN-003", reason_code="R01",
        failing_service="settlement-service", failing_step="SettlementDecisionEngine.attemptSettlement",
        correlation_ids={"settlement_id": "STL-100", "settlement_account_id": "SETL-CORR-A"},
        system_state_snapshot={"required_amount": "5000.00", "available_liquidity": "2300.00",
                                "intraday_credit_headroom": "0.00"},
    )
    print(ctx1.to_support_readable_summary())

    print()
    print("=== TEST 2: A card decline - insufficient funds, tying together card-service + routing ===")
    ctx2 = build_failure_context(
        txn_id="TXN-CARD-003", reason_code="51",
        failing_service="card-service", failing_step="CardAuthorizationService.authorize",
        correlation_ids={"auth_id": "AUTH-TXN-CARD-003", "card_network": "MASTERCARD"},
        system_state_snapshot={"requested_amount": "250.00", "available_credit": "100.00"},
    )
    print(ctx2.to_support_readable_summary())

    print()
    print("=== TEST 3: Reject an invalid/ad-hoc reason code - forces standardization, doesn't silently accept ===")
    try:
        build_failure_context(txn_id="TXN-999", reason_code="SOMETHING_WEIRD_HAPPENED",
                              failing_service="mystery-service", failing_step="unknown")
        print("FAIL - should have rejected the non-standard code")
    except ValueError as e:
        print(f"Correctly rejected: {e}")

    print()
    print("=== TEST 4: A retriable NETWORK failure is correctly flagged as such - support knows to retry, not escalate ===")
    ctx4 = build_failure_context(
        txn_id="TXN-SWIFT-001", reason_code="91",
        failing_service="swift-gateway-service", failing_step="submit_pacs008",
        system_state_snapshot={"correspondent": "CHASUS33", "attempt_number": 1},
    )
    print(f"Reason code: {ctx4.reason_code}")
    print(f"Is retriable: {REASON_CODES[ctx4.reason_code]['retriable']} (expected: True - support should retry, not escalate to ops)")

    print()
    print("=== TEST 5: A non-retriable RISK decline is correctly flagged - support should NOT blindly retry a fraud block ===")
    ctx5 = build_failure_context(
        txn_id="TXN-002", reason_code="59",
        failing_service="risk-service", failing_step="RuleEngine.evaluate",
        correlation_ids={"triggered_rule": "RULE-BLK-001"},
    )
    print(f"Is retriable: {REASON_CODES[ctx5.reason_code]['retriable']} (expected: False - retrying a fraud block is a real danger, not a fix)")
