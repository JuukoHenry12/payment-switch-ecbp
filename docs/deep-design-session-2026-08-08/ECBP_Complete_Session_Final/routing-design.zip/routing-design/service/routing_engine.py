"""
routing_engine.py — the actual "switch routing logic" the enterprise
architecture document named on day one and was never built. Given a
card BIN or a beneficiary BIC, decides where a transaction actually
routes to. Loaded into memory ONCE at startup (simulated here as
construction time), never queried per-transaction - directly
addressing the performance requirement: every lookup below is a
plain in-memory dict/list scan, not a database round-trip.
"""

from bisect import bisect_right


class RoutingEngine:
    """
    BIN ranges are loaded as a SORTED list at construction time,
    enabling O(log n) binary search lookup per transaction instead of
    a linear scan - genuinely matters once the table has thousands of
    real-world BIN ranges, not just the 4 test rows here.
    """

    def __init__(self, bin_routing_rows: list[dict], correspondent_routing_rows: list[dict]):
        # Sort once, at load time - the cost of sorting is paid ONCE,
        # not on every transaction.
        self._bin_ranges = sorted(bin_routing_rows, key=lambda r: r["bin_range_start"])
        self._bin_range_starts = [r["bin_range_start"] for r in self._bin_ranges]

        # Correspondent routing is a direct dict lookup - O(1).
        self._correspondent_routing = {
            row["beneficiary_bic_prefix"]: row for row in correspondent_routing_rows
        }

    def route_card_transaction(self, pan_or_token: str) -> dict:
        """
        Binary search for the matching BIN range - this is the exact
        performance property the user asked about: no table scan, no
        database call, a single O(log n) in-memory lookup.
        """
        bin_value = pan_or_token[:6]

        idx = bisect_right(self._bin_range_starts, bin_value) - 1
        if idx >= 0:
            candidate = self._bin_ranges[idx]
            if candidate["bin_range_start"] <= bin_value <= candidate["bin_range_end"]:
                return {
                    "matched": True,
                    "card_network": candidate["card_network"],
                    "routing_destination": candidate["routing_destination"],
                    "is_domestic": candidate["is_domestic"],
                }

        return {"matched": False, "routing_destination": None}

    def route_swift_transaction(self, beneficiary_bic: str) -> dict:
        bic_prefix = beneficiary_bic[:6]
        match = self._correspondent_routing.get(bic_prefix)
        if match:
            return {"matched": True, "settlement_account_id": match["settlement_account_id"],
                    "currency": match["currency"]}
        return {"matched": False, "settlement_account_id": None}


# ------------------------------------------------------------
# REAL TESTS - using the exact same test data (BIN 453212, various
# accounts) established across today's earlier packages
# ------------------------------------------------------------
if __name__ == "__main__":

    bin_rows = [
        {"bin_range_start": "453212", "bin_range_end": "453212", "card_network": "VISA",
         "routing_destination": "SETL-CARD-VISA-01", "is_domestic": False},
        {"bin_range_start": "400000", "bin_range_end": "499999", "card_network": "VISA",
         "routing_destination": "SETL-CARD-VISA-01", "is_domestic": False},
        {"bin_range_start": "510000", "bin_range_end": "559999", "card_network": "MASTERCARD",
         "routing_destination": "SETL-CARD-MC-01", "is_domestic": False},
        {"bin_range_start": "620000", "bin_range_end": "620099", "card_network": "LOCAL_DEBIT",
         "routing_destination": "INTERNAL", "is_domestic": True},
    ]
    correspondent_rows = [
        {"beneficiary_bic_prefix": "CHASUS", "settlement_account_id": "SETL-CORR-A", "currency": "USD"},
        {"beneficiary_bic_prefix": "DBSSSG", "settlement_account_id": "INTERNAL", "currency": "SGD"},
    ]

    engine = RoutingEngine(bin_rows, correspondent_rows)

    print("=== TEST 1: Route the exact PAN used throughout today's earlier packages (4532123456789012) ===")
    result1 = engine.route_card_transaction("4532123456789012")
    print(result1)
    print(f"Correctly identified as VISA, external network: "
          f"{result1['card_network'] == 'VISA' and not result1['is_domestic']}")

    print()
    print("=== TEST 2: A Mastercard BIN routes to the correct destination ===")
    result2 = engine.route_card_transaction("5412345678901234")
    print(result2)
    print(f"Correctly routed to Mastercard settlement: {result2['routing_destination'] == 'SETL-CARD-MC-01'}")

    print()
    print("=== TEST 3: ECBP's OWN card BIN correctly routes INTERNAL - never leaves the bank ===")
    result3 = engine.route_card_transaction("6200001234567890")
    print(result3)
    print(f"Correctly stays internal: {result3['routing_destination'] == 'INTERNAL' and result3['is_domestic']}")

    print()
    print("=== TEST 4: An unrecognized BIN correctly reports no match, rather than guessing ===")
    result4 = engine.route_card_transaction("9999999999999999")
    print(result4)
    print(f"Correctly unmatched: {result4['matched'] == False}")

    print()
    print("=== TEST 5: SWIFT routing - the correspondent bank from earlier today's SWIFT package ===")
    result5 = engine.route_swift_transaction("CHASUS33")
    print(result5)
    print(f"Correctly routed to the NOSTRO account: {result5['settlement_account_id'] == 'SETL-CORR-A'}")
