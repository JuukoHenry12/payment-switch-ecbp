-- ============================================================
-- ECBP Transaction Routing & Standardized Reason Codes — DDL
-- ============================================================

-- ------------------------------------------------------------
-- BIN_ROUTING_TABLE — the actual "switch routing logic" named in
-- the very first enterprise architecture document, never built
-- until now. Given a card number's BIN (first 6-8 digits), decides
-- which network a transaction routes to. This table is the
-- SOURCE OF TRUTH, but per the performance requirement below, it is
-- NEVER queried per-transaction - it's loaded into memory once and
-- refreshed periodically.
-- ------------------------------------------------------------
CREATE TABLE BIN_ROUTING_TABLE (
    BIN_RANGE_START          VARCHAR(8)     NOT NULL,
    BIN_RANGE_END              VARCHAR(8)   NOT NULL,
    CARD_NETWORK                  VARCHAR(20) NOT NULL,  -- VISA, MASTERCARD, LOCAL_DEBIT, AMEX
    ROUTING_DESTINATION              VARCHAR(30) NOT NULL, -- SETL-CARD-VISA-01, SETL-CARD-MC-01, INTERNAL (own-bank card)
    IS_DOMESTIC                        BOOLEAN   NOT NULL,
    UPDATED_AT                           TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (BIN_RANGE_START, BIN_RANGE_END)
);

INSERT INTO BIN_ROUTING_TABLE (BIN_RANGE_START, BIN_RANGE_END, CARD_NETWORK, ROUTING_DESTINATION, IS_DOMESTIC) VALUES
    ('453212', '453212', 'VISA', 'SETL-CARD-VISA-01', false),   -- matches the PAN used throughout today's C/tokenization work
    ('400000', '499999', 'VISA', 'SETL-CARD-VISA-01', false),
    ('510000', '559999', 'MASTERCARD', 'SETL-CARD-MC-01', false),
    ('620000', '620099', 'LOCAL_DEBIT', 'INTERNAL', true);    -- ECBP's own-issued cards - never leaves the bank at all

-- ------------------------------------------------------------
-- CORRESPONDENT_ROUTING_TABLE — for SWIFT/cross-border, given a
-- beneficiary BIC, which NOSTRO settlement account services that
-- corridor. Same in-memory-cache principle applies.
-- ------------------------------------------------------------
CREATE TABLE CORRESPONDENT_ROUTING_TABLE (
    BENEFICIARY_BIC_PREFIX     VARCHAR(6)   NOT NULL PRIMARY KEY,  -- first 6 chars of BIC (bank+country)
    SETTLEMENT_ACCOUNT_ID         VARCHAR(30) NOT NULL,
    CURRENCY                         CHAR(3)   NOT NULL,
    UPDATED_AT                         TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO CORRESPONDENT_ROUTING_TABLE (BENEFICIARY_BIC_PREFIX, SETTLEMENT_ACCOUNT_ID, CURRENCY) VALUES
    ('CHASUS', 'SETL-CORR-A', 'USD'),
    ('DBSSSG', 'INTERNAL', 'SGD');

-- ------------------------------------------------------------
-- REASON_CODE_REFERENCE — real, standard codes, not free-text.
-- The left column matches actual ISO 8583 field 39 response codes;
-- the right maps each to ECBP's own internal failure taxonomy so
-- every service in the system speaks the SAME failure vocabulary,
-- whether the failure originated from a card network, a fraud
-- check, insufficient liquidity, or a reconciliation break.
-- ------------------------------------------------------------
CREATE TABLE REASON_CODE_REFERENCE (
    REASON_CODE              VARCHAR(4)     PRIMARY KEY,   -- real ISO 8583 field 39 style codes
    SHORT_DESCRIPTION           VARCHAR(50)  NOT NULL,
    CATEGORY                       VARCHAR(20) NOT NULL,   -- APPROVED, CUSTOMER_ISSUE, RISK, SYSTEM, NETWORK
    IS_RETRIABLE                     BOOLEAN   NOT NULL
);

INSERT INTO REASON_CODE_REFERENCE (REASON_CODE, SHORT_DESCRIPTION, CATEGORY, IS_RETRIABLE) VALUES
    ('00', 'Approved',                        'APPROVED',      false),
    ('05', 'Do not honor',                    'CUSTOMER_ISSUE', false),
    ('14', 'Invalid card number',             'CUSTOMER_ISSUE', false),
    ('51', 'Insufficient funds',              'CUSTOMER_ISSUE', false),
    ('54', 'Expired card',                    'CUSTOMER_ISSUE', false),
    ('59', 'Suspected fraud',                 'RISK',          false),
    ('61', 'Exceeds withdrawal limit',        'RISK',          false),
    ('62', 'Restricted card',                 'RISK',          false),
    ('91', 'Issuer or network unavailable',   'NETWORK',       true),
    ('96', 'System malfunction',              'SYSTEM',        true),
    ('R01', 'Insufficient liquidity for RTGS settlement', 'SYSTEM', true),   -- ECBP-specific extension, same numbering discipline
    ('R02', 'Reconciliation break - late external failure', 'SYSTEM', false);
