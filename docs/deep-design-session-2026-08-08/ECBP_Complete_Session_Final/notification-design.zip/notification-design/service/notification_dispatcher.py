"""
notification_dispatcher.py — routes events (from the full event
catalog built today: PaymentFailed, FraudFlagged, ReconciliationBreak-
Detected, SettlementQueued, etc.) to the correct channel and
audience, with two properties genuinely tested rather than assumed:

  1. IDEMPOTENT DELIVERY - a redelivered Kafka event (the same
     concrete scenario that caused the settlement engine bug found
     hours ago) must never cause a customer to receive the same
     notification twice.

  2. RETRY WITH BACKOFF, THEN DEAD-LETTER - a failed delivery attempt
     retries with increasing delay, and after a bounded number of
     attempts, gives up and moves to a dead-letter state rather than
     retrying forever or silently dropping the notification.
"""

from dataclasses import dataclass, field
from enum import Enum


class Channel(Enum):
    CUSTOMER_SMS = "CUSTOMER_SMS"
    CUSTOMER_EMAIL = "CUSTOMER_EMAIL"
    OPS_ALERT = "OPS_ALERT"       # Slack/PagerDuty-equivalent, for ops/treasury, never a customer
    NONE = "NONE"                  # some events genuinely warrant no notification at all


class DeliveryStatus(Enum):
    PENDING = "PENDING"
    DELIVERED = "DELIVERED"
    RETRYING = "RETRYING"
    DEAD_LETTERED = "DEAD_LETTERED"


# Event type -> (channel, audience-appropriate template key).
# Deliberately data-driven, same "configuration not code" principle
# used for FRAUD_RULE earlier today - a new event type routing rule
# shouldn't need a code deployment.
EVENT_ROUTING = {
    "PaymentSettled": Channel.NONE,               # too routine to notify on every single one
    "PaymentFailed": Channel.CUSTOMER_SMS,
    "FraudFlagged_BLOCK": Channel.CUSTOMER_SMS,     # a blocked transaction genuinely needs the customer told
    "FraudFlagged_FLAG": Channel.NONE,              # a soft flag stays internal, doesn't alarm the customer
    "SettlementQueued": Channel.NONE,               # normal RTGS operating behavior, not customer-facing
    "ReconciliationBreakDetected": Channel.OPS_ALERT,
    "LiquidityLow": Channel.OPS_ALERT,
}

MAX_RETRY_ATTEMPTS = 3


@dataclass
class NotificationAttempt:
    event_id: str
    channel: Channel
    status: DeliveryStatus = DeliveryStatus.PENDING
    attempt_count: int = 0
    delivered_event_ids: set = field(default_factory=set)


class NotificationDispatcher:

    def __init__(self, delivery_fn):
        """delivery_fn: a callable simulating the actual send (SMS
        gateway, email provider, ops webhook) - injected so tests can
        control success/failure deterministically."""
        self.delivery_fn = delivery_fn
        self.delivered_event_ids: set[str] = set()  # THE idempotency guard
        self.attempts: dict[str, NotificationAttempt] = {}
        self.log: list[str] = []

    def _log(self, msg: str):
        self.log.append(msg)
        print(f"  {msg}")

    def dispatch(self, event_id: str, event_type: str, txn_id: str) -> DeliveryStatus:

        if event_id in self.delivered_event_ids:
            # THE idempotency check - this is what prevents a
            # redelivered Kafka event from double-notifying a
            # customer, the exact same class of problem that caused
            # the settlement engine bug found earlier today, applied
            # here to a genuinely different subsystem.
            self._log(f"SKIPPED: {event_id} already delivered - not sending again")
            return DeliveryStatus.DELIVERED

        channel = EVENT_ROUTING.get(event_type, Channel.NONE)

        if channel == Channel.NONE:
            self._log(f"NO NOTIFICATION: {event_type} does not warrant one (by design, not an oversight)")
            return DeliveryStatus.DELIVERED  # "delivered" in the sense of "correctly handled, nothing to send"

        attempt = self.attempts.get(event_id) or NotificationAttempt(event_id=event_id, channel=channel)
        self.attempts[event_id] = attempt

        for retry_num in range(MAX_RETRY_ATTEMPTS):
            attempt.attempt_count += 1
            success = self.delivery_fn(event_id, channel, txn_id, attempt.attempt_count)

            if success:
                attempt.status = DeliveryStatus.DELIVERED
                self.delivered_event_ids.add(event_id)
                self._log(f"DELIVERED: {event_id} via {channel.value} on attempt {attempt.attempt_count}")
                return DeliveryStatus.DELIVERED

            attempt.status = DeliveryStatus.RETRYING
            backoff_seconds = 2 ** attempt.attempt_count  # exponential backoff
            self._log(f"FAILED attempt {attempt.attempt_count} for {event_id} via {channel.value} - "
                      f"would retry after {backoff_seconds}s backoff")

        attempt.status = DeliveryStatus.DEAD_LETTERED
        self._log(f"DEAD-LETTERED: {event_id} - exhausted {MAX_RETRY_ATTEMPTS} attempts, giving up, "
                  f"flagged for manual ops review")
        return DeliveryStatus.DEAD_LETTERED


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: PaymentFailed correctly routes to CUSTOMER_SMS and delivers successfully ===")
    always_succeeds = lambda event_id, channel, txn_id, attempt: True
    dispatcher1 = NotificationDispatcher(always_succeeds)
    result1 = dispatcher1.dispatch("EVT-001", "PaymentFailed", "TXN-002")
    print(f"Status: {result1.value} (expected: DELIVERED)")

    print()
    print("=== TEST 2: A REDELIVERED event (same event_id) does NOT trigger a second notification ===")
    call_count = {"n": 0}
    def counting_delivery(event_id, channel, txn_id, attempt):
        call_count["n"] += 1
        return True
    dispatcher2 = NotificationDispatcher(counting_delivery)
    dispatcher2.dispatch("EVT-002", "PaymentFailed", "TXN-003")
    dispatcher2.dispatch("EVT-002", "PaymentFailed", "TXN-003")  # simulated Kafka redelivery of the SAME event
    dispatcher2.dispatch("EVT-002", "PaymentFailed", "TXN-003")  # and again
    print(f"Actual delivery attempts made: {call_count['n']} (expected: 1, despite 3 dispatch() calls)")

    print()
    print("=== TEST 3: ReconciliationBreakDetected routes to OPS_ALERT, never CUSTOMER_SMS ===")
    routed_channel = {}
    def channel_capturing_delivery(event_id, channel, txn_id, attempt):
        routed_channel["channel"] = channel
        return True
    dispatcher3 = NotificationDispatcher(channel_capturing_delivery)
    dispatcher3.dispatch("EVT-003", "ReconciliationBreakDetected", "TXN-003")
    print(f"Routed to: {routed_channel['channel'].value} (expected: OPS_ALERT, never a customer channel)")

    print()
    print("=== TEST 4: SettlementQueued (normal RTGS behavior) correctly triggers NO notification at all ===")
    should_not_be_called = lambda *args: (_ for _ in ()).throw(AssertionError("delivery_fn should never be called"))
    dispatcher4 = NotificationDispatcher(should_not_be_called)
    result4 = dispatcher4.dispatch("EVT-004", "SettlementQueued", "TXN-003")
    print(f"Status: {result4.value} (expected: DELIVERED - meaning 'correctly handled', delivery_fn never invoked)")

    print()
    print("=== TEST 5: Persistent failure - retries 3 times, then correctly dead-letters ===")
    always_fails = lambda event_id, channel, txn_id, attempt: False
    dispatcher5 = NotificationDispatcher(always_fails)
    result5 = dispatcher5.dispatch("EVT-005", "FraudFlagged_BLOCK", "TXN-002")
    print(f"Status: {result5.value} (expected: DEAD_LETTERED)")
    print(f"Attempt count: {dispatcher5.attempts['EVT-005'].attempt_count} (expected: {MAX_RETRY_ATTEMPTS})")

    print()
    print("=== TEST 6: Recovers on the 2nd attempt (transient failure, not permanent) ===")
    attempt_tracker = {"n": 0}
    def fails_once_then_succeeds(event_id, channel, txn_id, attempt):
        attempt_tracker["n"] += 1
        return attempt_tracker["n"] >= 2  # fails first attempt, succeeds second
    dispatcher6 = NotificationDispatcher(fails_once_then_succeeds)
    result6 = dispatcher6.dispatch("EVT-006", "FraudFlagged_BLOCK", "TXN-002")
    print(f"Status: {result6.value} (expected: DELIVERED - recovered before hitting the retry ceiling)")
    print(f"Total attempts needed: {dispatcher6.attempts['EVT-006'].attempt_count} (expected: 2)")
