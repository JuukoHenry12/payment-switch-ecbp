-- ============================================================
-- ECBP Settlement Engine & Liquidity Management — DDL
-- ============================================================
-- Design decisions, stated explicitly:
--   1. This is deliberately SEPARATE from the internal double-entry
--      ledger (ledger_shard_ddl.sql). Internal transfers between
--      ECBP accounts settle instantly via that ledger already - no
--      liquidity problem exists there, since both sides live inside
--      the same system and the saga either fully commits or fully
--      compensates.
--   2. This schema exists specifically for EXTERNAL settlement -
--      money moving between ECBP and outside parties: card network
--      interchange, SWIFT correspondent banks, real-time payment
--      rails (FedNow/RTP/PayNow-equivalent). That's where real
--      liquidity constraints and settlement finality genuinely
--      become a distinct problem from internal ledger posting.
--   3. "Settled" here means EXTERNALLY confirmed - a strictly later,
--      stricter state than the internal TRANSACTION_HEADER.STATUS
--      = SETTLED, which only reflects internal ledger completion.
-- ============================================================

-- ------------------------------------------------------------
-- SETTLEMENT_ACCOUNT — one row per external settlement
-- relationship (a nostro account, a network settlement account,
-- a card scheme settlement account, etc.)
-- ------------------------------------------------------------
CREATE TABLE SETTLEMENT_ACCOUNT (
    SETTLEMENT_ACCOUNT_ID   VARCHAR(30)     PRIMARY KEY,
    ACCOUNT_TYPE            VARCHAR(20)     NOT NULL,  -- NOSTRO, RTGS_RESERVE, CARD_NETWORK, INSTANT_RAIL
    COUNTERPARTY_NAME       VARCHAR(100)    NOT NULL,  -- e.g. "FedNow", "SWIFT-DBS-SGD", "Visa Settlement"
    CURRENCY                CHAR(3)         NOT NULL,  -- ISO 4217
    SETTLEMENT_MODE         VARCHAR(10)     NOT NULL,  -- RTGS, DNS
    DNS_CYCLE_SCHEDULE      VARCHAR(50)     NULL,       -- e.g. "DAILY_18:00", null if RTGS
    CREATED_AT              TIMESTAMPTZ     NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- LIQUIDITY_POSITION — real-time available liquidity per
-- settlement account. This is the single most important table
-- in this schema: it answers "can we actually settle this right now"
-- ------------------------------------------------------------
CREATE TABLE LIQUIDITY_POSITION (
    SETTLEMENT_ACCOUNT_ID   VARCHAR(30)     PRIMARY KEY REFERENCES SETTLEMENT_ACCOUNT(SETTLEMENT_ACCOUNT_ID),
    AVAILABLE_BALANCE       DECIMAL(18,2)   NOT NULL DEFAULT 0.00,
    RESERVED_AMOUNT         DECIMAL(18,2)   NOT NULL DEFAULT 0.00,  -- held for in-flight settlements not yet confirmed
    INTRADAY_CREDIT_LIMIT   DECIMAL(18,2)   NOT NULL DEFAULT 0.00,  -- liquidity bridge / overdraft facility ceiling
    INTRADAY_CREDIT_USED    DECIMAL(18,2)   NOT NULL DEFAULT 0.00,
    LOW_LIQUIDITY_THRESHOLD DECIMAL(18,2)   NOT NULL,               -- triggers an alert when AVAILABLE_BALANCE falls below this
    LAST_UPDATED            TIMESTAMPTZ     NOT NULL DEFAULT now(),
    VERSION                 BIGINT          NOT NULL DEFAULT 0      -- optimistic concurrency, this row is hot
);

-- Effective spendable liquidity = AVAILABLE_BALANCE - RESERVED_AMOUNT
--                                  + (INTRADAY_CREDIT_LIMIT - INTRADAY_CREDIT_USED)

-- ------------------------------------------------------------
-- SETTLEMENT_INSTRUCTION — one row per external settlement
-- attempt. Distinct from TRANSACTION_HEADER (the internal
-- ledger record) - this tracks the EXTERNAL leg specifically.
-- ------------------------------------------------------------
CREATE TABLE SETTLEMENT_INSTRUCTION (
    SETTLEMENT_ID           UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_ID                  UUID            NOT NULL,   -- FK to TRANSACTION_HEADER, cross-database reference
    SETTLEMENT_ACCOUNT_ID   VARCHAR(30)     NOT NULL REFERENCES SETTLEMENT_ACCOUNT(SETTLEMENT_ACCOUNT_ID),
    AMOUNT                  DECIMAL(18,2)   NOT NULL,
    DIRECTION               VARCHAR(10)     NOT NULL,   -- OUTGOING, INCOMING
    STATUS                  VARCHAR(20)     NOT NULL,   -- QUEUED, RESERVED, SETTLED, FAILED, EXPIRED
    PRIORITY                SMALLINT        NOT NULL DEFAULT 5,  -- 1 (highest) to 9 (lowest), for queue ordering
    QUEUED_AT                TIMESTAMPTZ     NULL,
    SETTLED_AT               TIMESTAMPTZ     NULL,
    EXTERNAL_CONFIRMATION_REF VARCHAR(100)   NULL,       -- the network's own reference once confirmed
    CREATED_AT                TIMESTAMPTZ    NOT NULL DEFAULT now()
);

CREATE INDEX IDX_SETTLEMENT_QUEUE
    ON SETTLEMENT_INSTRUCTION (SETTLEMENT_ACCOUNT_ID, STATUS, PRIORITY, CREATED_AT)
    WHERE STATUS = 'QUEUED';

CREATE INDEX IDX_SETTLEMENT_TXN ON SETTLEMENT_INSTRUCTION (TXN_ID);

-- ------------------------------------------------------------
-- LIQUIDITY_FORECAST — expected future inflows/outflows,
-- used by liquidity-service to warn ahead of a predictable
-- shortfall rather than only reacting once it happens.
-- Populated from known scheduled settlements (e.g. DNS cycles)
-- and historical pattern-based projections.
-- ------------------------------------------------------------
CREATE TABLE LIQUIDITY_FORECAST (
    FORECAST_ID              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    SETTLEMENT_ACCOUNT_ID    VARCHAR(30)     NOT NULL REFERENCES SETTLEMENT_ACCOUNT(SETTLEMENT_ACCOUNT_ID),
    FORECAST_WINDOW_START    TIMESTAMPTZ     NOT NULL,
    FORECAST_WINDOW_END      TIMESTAMPTZ     NOT NULL,
    PROJECTED_INFLOW         DECIMAL(18,2)   NOT NULL DEFAULT 0.00,
    PROJECTED_OUTFLOW        DECIMAL(18,2)   NOT NULL DEFAULT 0.00,
    CONFIDENCE_LEVEL         VARCHAR(10)     NOT NULL DEFAULT 'MEDIUM', -- HIGH (scheduled/contractual), MEDIUM, LOW (pattern-based)
    GENERATED_AT             TIMESTAMPTZ     NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- Sample data: a FedNow-equivalent RTGS settlement account
-- with tight liquidity, demonstrating the queuing scenario
-- ------------------------------------------------------------
INSERT INTO SETTLEMENT_ACCOUNT (SETTLEMENT_ACCOUNT_ID, ACCOUNT_TYPE, COUNTERPARTY_NAME, CURRENCY, SETTLEMENT_MODE)
VALUES ('SETL-RTGS-SGD-01', 'RTGS_RESERVE', 'MAS RTGS (MEPS+ equivalent)', 'SGD', 'RTGS');

INSERT INTO LIQUIDITY_POSITION (SETTLEMENT_ACCOUNT_ID, AVAILABLE_BALANCE, INTRADAY_CREDIT_LIMIT, LOW_LIQUIDITY_THRESHOLD)
VALUES ('SETL-RTGS-SGD-01', 50000.00, 20000.00, 10000.00);

-- A card network DNS settlement account, for contrast
INSERT INTO SETTLEMENT_ACCOUNT (SETTLEMENT_ACCOUNT_ID, ACCOUNT_TYPE, COUNTERPARTY_NAME, CURRENCY, SETTLEMENT_MODE, DNS_CYCLE_SCHEDULE)
VALUES ('SETL-CARD-VISA-01', 'CARD_NETWORK', 'Visa Settlement', 'SGD', 'DNS', 'DAILY_18:00');
