package com.balasubramani.ecbp.settlement.service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

/**
 * SettlementDecisionEngine — the core logic answering "can we settle
 * this external payment right now, and if not, what happens to it."
 *
 * This is the piece that was genuinely missing from ECBP before this
 * design pass. The internal ledger (account-service) already settles
 * transfers between ECBP's own accounts instantly via the saga
 * pattern - no liquidity problem exists there. This class exists
 * specifically for the EXTERNAL leg: money moving to/from a card
 * network, a correspondent bank via SWIFT, or a real-time payment
 * rail - where actual available liquidity, not just solvency, gates
 * whether settlement can happen right now.
 *
 * Three possible outcomes for any settlement attempt:
 *   1. SETTLE NOW - sufficient liquidity exists (including any
 *      available intraday credit), settle immediately (RTGS).
 *   2. QUEUE - insufficient liquidity right now, but this is an
 *      RTGS-mode account, so the instruction waits for liquidity to
 *      free up (either from an incoming settlement or a manual
 *      liquidity injection), rather than being immediately failed.
 *   3. ROUTE TO DNS BATCH - this settlement account operates on
 *      deferred net settlement, so no real-time liquidity check
 *      applies at all; the instruction is simply added to the
 *      account's pending batch for its next scheduled cycle.
 */
public class SettlementDecisionEngine {

    private final LiquidityRepository liquidityRepository;
    private final SettlementInstructionRepository instructionRepository;

    public SettlementDecisionEngine(
            LiquidityRepository liquidityRepository,
            SettlementInstructionRepository instructionRepository) {
        this.liquidityRepository = liquidityRepository;
        this.instructionRepository = instructionRepository;
    }

    /**
     * Entry point: attempt to settle a single outgoing instruction.
     * Called by settlement-service whenever payment-service publishes
     * a PaymentSettled event for a transaction that has an external
     * counterparty (not a purely internal ECBP-to-ECBP transfer).
     */
    public SettlementOutcome attemptSettlement(SettlementInstruction instruction) {

        SettlementAccount account = instructionRepository
                .getSettlementAccount(instruction.settlementAccountId());

        // DNS accounts never do a real-time liquidity check - they
        // simply accumulate into the next batch cycle. This is the
        // deliberate, correct behavior for e.g. card network
        // interchange, which still genuinely operates this way today.
        if (account.settlementMode() == SettlementMode.DNS) {
            instructionRepository.markQueuedForBatch(instruction, account.dnsCycleSchedule());
            return SettlementOutcome.ROUTED_TO_DNS_BATCH;
        }

        // RTGS path - this is where the real liquidity question lives.
        return attemptRtgsSettlement(instruction);
    }

    private SettlementOutcome attemptRtgsSettlement(SettlementInstruction instruction) {

        // Optimistic-concurrency-safe read-and-reserve. This must be
        // atomic against LIQUIDITY_POSITION.VERSION - two settlement
        // attempts racing for the same account's liquidity is a real,
        // expected scenario at any real transaction volume, and this
        // is exactly the kind of race condition worth deliberately
        // load-testing once this is implemented (Phase 25 in the
        // roadmap), not just trusting the logic on paper.
        LiquidityPosition position = liquidityRepository
                .getForUpdate(instruction.settlementAccountId());

        BigDecimal spendableLiquidity = position.availableBalance()
                .subtract(position.reservedAmount())
                .add(position.intradayCreditLimit().subtract(position.intradayCreditUsed()));

        if (spendableLiquidity.compareTo(instruction.amount()) >= 0) {
            // Sufficient liquidity (including intraday credit headroom
            // if needed) - settle now.
            reserveLiquidity(position, instruction);
            instructionRepository.markSettled(instruction, Instant.now());
            return SettlementOutcome.SETTLED_IMMEDIATELY;
        }

        // Insufficient liquidity right now. This is NOT a failure -
        // it is a completely normal, expected RTGS operating
        // condition, exactly as it is for real central bank RTGS
        // systems. The instruction queues rather than fails outright.
        instructionRepository.markQueued(instruction, Instant.now());
        checkLowLiquidityAlert(position);

        return SettlementOutcome.QUEUED_INSUFFICIENT_LIQUIDITY;
    }

    private void reserveLiquidity(LiquidityPosition position, SettlementInstruction instruction) {
        liquidityRepository.updateReserved(
                position.settlementAccountId(),
                position.reservedAmount().add(instruction.amount()),
                position.version()  // optimistic concurrency check
        );
    }

    private void checkLowLiquidityAlert(LiquidityPosition position) {
        BigDecimal remaining = position.availableBalance().subtract(position.reservedAmount());
        if (remaining.compareTo(position.lowLiquidityThreshold()) < 0) {
            // Publish a LiquidityLow event - consumed by an alerting
            // pipeline (Splunk/Prometheus, per the observability
            // design) so treasury/ops is notified BEFORE this becomes
            // a genuine settlement failure, not after.
            liquidityRepository.publishLowLiquidityAlert(position);
        }
    }

    /**
     * Gridlock resolution — called periodically (e.g. every few
     * seconds) or whenever new liquidity arrives on a settlement
     * account with a non-empty queue. This is the real mechanism
     * that makes RTGS queuing actually work in practice, rather than
     * just accumulating a backlog: as liquidity frees up, queued
     * instructions get released, prioritized by explicit priority
     * first, then FIFO within the same priority.
     *
     * A genuinely more advanced version of this (used by real
     * central bank RTGS systems under real gridlock conditions) does
     * multilateral offsetting - finding sets of queued payments
     * across MULTIPLE accounts that could all be released together
     * even though no single one individually has enough liquidity,
     * because they net against each other. That is intentionally
     * out of scope for this first design pass - worth flagging as a
     * genuine, real enhancement for later, not something to fake now.
     */
    public void resolveQueueForAccount(String settlementAccountId) {

        LiquidityPosition position = liquidityRepository.getForUpdate(settlementAccountId);
        BigDecimal spendable = position.availableBalance()
                .subtract(position.reservedAmount())
                .add(position.intradayCreditLimit().subtract(position.intradayCreditUsed()));

        List<SettlementInstruction> queued = instructionRepository
                .getQueuedOrderedByPriorityThenAge(settlementAccountId);

        for (SettlementInstruction instruction : queued) {
            if (spendable.compareTo(instruction.amount()) < 0) {
                // Not enough for this one - per standard RTGS queue
                // discipline, we do NOT skip ahead to a smaller queued
                // instruction here (that would starve larger, often
                // higher-priority payments indefinitely). We stop and
                // wait for more liquidity instead.
                break;
            }

            reserveLiquidity(position, instruction);
            instructionRepository.markSettled(instruction, Instant.now());
            spendable = spendable.subtract(instruction.amount());
        }
    }

    // --- Supporting types (would live in their own files in the real module) ---

    public enum SettlementMode { RTGS, DNS }
    public enum SettlementOutcome { SETTLED_IMMEDIATELY, QUEUED_INSUFFICIENT_LIQUIDITY, ROUTED_TO_DNS_BATCH }

    public record SettlementAccount(String settlementAccountId, SettlementMode settlementMode, String dnsCycleSchedule) {}
    public record SettlementInstruction(String settlementAccountId, BigDecimal amount) {}
    public record LiquidityPosition(
            String settlementAccountId, BigDecimal availableBalance, BigDecimal reservedAmount,
            BigDecimal intradayCreditLimit, BigDecimal intradayCreditUsed,
            BigDecimal lowLiquidityThreshold, long version) {}

    public interface LiquidityRepository {
        LiquidityPosition getForUpdate(String settlementAccountId);
        void updateReserved(String settlementAccountId, BigDecimal newReservedAmount, long expectedVersion);
        void publishLowLiquidityAlert(LiquidityPosition position);
    }

    public interface SettlementInstructionRepository {
        SettlementAccount getSettlementAccount(String settlementAccountId);
        void markSettled(SettlementInstruction instruction, Instant settledAt);
        void markQueued(SettlementInstruction instruction, Instant queuedAt);
        void markQueuedForBatch(SettlementInstruction instruction, String dnsCycleSchedule);
        List<SettlementInstruction> getQueuedOrderedByPriorityThenAge(String settlementAccountId);
    }
}
