# Settlement Engine & Liquidity Management — Design Package

## What this solves, precisely

ECBP's internal ledger (account-service) already settles transfers between ECBP's own accounts instantly — no liquidity problem exists there, since the saga either fully commits or fully compensates within the system's own boundary.

**This package exists for a genuinely different problem**: settling with *external* parties — a card network, a SWIFT correspondent bank, a real-time payment rail. There, actual available liquidity at the moment of settlement — not just solvency — determines whether a payment can complete right now. This is the real-world RTGS liquidity problem, and it was a genuine gap in the design before this pass.

## Files

```
ddl/settlement_liquidity_ddl.sql       - SETTLEMENT_ACCOUNT, LIQUIDITY_POSITION,
                                          SETTLEMENT_INSTRUCTION, LIQUIDITY_FORECAST
service/SettlementDecisionEngine.java  - the core RTGS/DNS decision + queuing + gridlock logic
schemas/*.avsc                         - 4 new events for the settlement/liquidity domain
```

## Honesty flag, same as always

I couldn't execute the DDL or run the Java against a real system in my environment — no database or full Spring context available to me here. Treat applying this DDL and wiring up the service as the genuine test, same as every other artifact in this project. If something breaks, paste it back.

## Two new services, and why they're separate from payment-service

**`settlement-service`** owns the `SettlementDecisionEngine` — the RTGS-vs-DNS decision, queuing, and gridlock resolution. It's deliberately a distinct service from `payment-service`, because payment-service's job is "did the internal transfer complete correctly" (already solved), while settlement-service's job is "did the external leg actually clear" — a genuinely different concern with a different failure mode (queuing is normal, not an error) and a different data model (settlement accounts, not customer accounts).

**`liquidity-service`** owns `LIQUIDITY_POSITION` and `LIQUIDITY_FORECAST` — real-time position tracking and proactive alerting, kept separate so it can be queried independently (a treasury/ops dashboard needs fast, direct access to current liquidity without going through the settlement decision path).

## How this connects to what already exists

```
payment-service publishes PaymentSettled (internal ledger complete)
        │
        ▼
settlement-service consumes it, checks: does this transaction have
an external counterparty? (card network, SWIFT, real-time rail)
        │
        ├── NO  → nothing further needed, already done
        │
        └── YES → SettlementDecisionEngine.attemptSettlement()
                    │
                    ├── DNS account → routed to next batch cycle
                    │
                    └── RTGS account → checks liquidity-service
                            │
                            ├── sufficient → SETTLED_IMMEDIATELY
                            │   publishes ExternalSettlementConfirmed
                            │   (once the network itself confirms)
                            │
                            └── insufficient → QUEUED
                                publishes SettlementQueued
                                liquidity-service may publish LiquidityLow
                                gridlock resolution runs periodically,
                                eventually publishes SettlementReleased
```

## What's deliberately NOT built yet — stated honestly, not hidden

**Multilateral gridlock offsetting** — real central bank RTGS systems, under genuine gridlock conditions, can find sets of queued payments across *multiple* settlement accounts that net against each other and release together, even though no single one has enough liquidity alone. The `resolveQueueForAccount` method in `SettlementDecisionEngine.java` deliberately does the simpler, correct single-account version (priority + FIFO, no skip-ahead) and explicitly does not attempt this — worth treating as a genuine future enhancement once the simpler version is built, tested, and proven, not something to fake now for the sake of looking complete.

**Actual intraday credit facility mechanics** — the DDL has `INTRADAY_CREDIT_LIMIT`/`INTRADAY_CREDIT_USED` fields, and the decision engine correctly factors them into spendable liquidity, but the actual process of *drawing* on such a facility (in reality, often collateralized against securities held with a central bank) is modeled here only as a number, not a full workflow — appropriate for this design stage, worth flagging as simplified rather than pretending it's fully modeled.

## Immediate next step

1. Apply `settlement_liquidity_ddl.sql` to a dedicated settlement/liquidity database (can share the DB2 instance you already have, in its own schema, or a new sharded Postgres instance — worth deciding deliberately rather than defaulting)
2. Register the 4 new Avro schemas in your Schema Registry
3. Scaffold `settlement-service` and `liquidity-service` as two new services in your `services/` folder, following the exact same pattern as your existing 10
4. Wire `SettlementDecisionEngine` into `settlement-service`, replacing the interface stubs (`LiquidityRepository`, `SettlementInstructionRepository`) with real Spring Data implementations

This genuinely completes the gap Part 9 identified — ECBP now has an explicit answer for "what happens when a real-time settlement can't happen right now," instead of implicitly assuming liquidity is always available.
