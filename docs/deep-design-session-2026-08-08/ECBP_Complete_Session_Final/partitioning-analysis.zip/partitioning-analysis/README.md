# Table Partitioning — Complete Impact Analysis

## Direct answer: no, we don't have this, and it's a real, significant gap

Confirmed by checking every DDL file built today: zero partitioning anywhere, across at least 7 genuinely high-volume, append-only tables (TRANSACTION_ENTRY, TRANSACTION_HEADER, CHANNEL_INGESTION_LOG, TOKEN_LIFECYCLE_LOG, SCREENING_RESULT, TRANSACTION_JOURNAL_ENTRY, OUTBOUND_QUEUE_ENTRY). This is not a theoretical concern — at real bank transaction volume, these tables genuinely will exceed what's manageable as a single, unpartitioned structure, and the gap needed real, tested analysis, not a general acknowledgment.

## Sharding versus partitioning — not interchangeable, both needed

Sharding (already built, Phase 1) splits data across separate databases — the answer to "one database can't handle the total write throughput." Partitioning splits a table within one database — the answer to "even this one shard's table has become too large to manage efficiently." A real payment switch at scale needs both simultaneously, not one instead of the other.

## What NonStop does, for context

Enscribe/SQL-MP files can be physically partitioned by key range across multiple disk volumes — parallel I/O, storage capacity beyond one disk, and partitions that can be maintained somewhat independently. Postgres range partitioning achieves the equivalent practical goals through a different mechanism, and the honest comparison below covers exactly where the mechanics genuinely differ.

## Finding 1 — the unique constraint problem, proven concretely

TRANSACTION_HEADER.IDEMPOTENCY_KEY had a plain UNIQUE constraint, no date component. Postgres requires every unique constraint on a partitioned table — including the primary key — to include the partition key. Test 1 in partitioning_analysis.py proves exactly what goes wrong if this is missed: the same idempotency key, submitted in January and again in February, is accepted both times — a genuine duplicate transaction slips through, because uniqueness was only ever checked within one partition, never globally.

The fix, and its own honest residual gap: the corrected DDL makes CREATED_AT part of both the primary key and the unique constraint. But Test 2's success comes with a caveat worth stating plainly — this only fully closes the gap if a separate, small, unpartitioned IDEMPOTENCY_KEY_LOOKUP table is also checked first, specifically to catch the edge case of a retry landing in a different month than the original. This is a real, standard production pattern, not an improvised workaround — but it's a second table to maintain correctly, not a free fix.

## Finding 2 — partition maintenance is an active process, and forgetting it causes real, direct outages

Partitions for future dates must be created ahead of time. Test 3 proves the real failure mode: attempting to insert a September transaction when only August's partition exists raises a genuine, blocking error — inserts for that entire month fail — until the partition is created. Test 4 proves the fix: a maintenance job, run proactively (the exact same operational discipline as batch-design's EOD job — must run reliably, must be monitored, must alert if it fails), creates partitions several months ahead so this is never hit under normal operation.

This is a genuine, standing operational responsibility, not a one-time setup step — worth being explicit that adding partitioning adds a new job to the list of things that must keep running correctly, the same category of risk as anything else on an operations dashboard.

## Finding 3 — partition pruning, measured, not claimed

Test 5 simulates 12 months of realistic data (50,000 rows each, 600,000 total) and measures the real difference: a query for one month's transactions touches 50,000 rows with pruning, 600,000 without — a 91.7% reduction, and this is the actual mechanism behind why large transaction tables become slow to query as they grow unpartitioned. This is the single biggest performance justification for partitioning at all.

## How easy are DB changes to a partitioned table — direct answer

Meaningfully harder than an unpartitioned table, in specific, nameable ways — not uniformly harder, but different.

- Adding a column: genuinely easy — ALTER TABLE TRANSACTION_HEADER ADD COLUMN on the parent table cascades to every partition automatically in modern Postgres. No real added difficulty here.
- Adding or changing a constraint (exactly the finding above): meaningfully harder — any unique or primary key constraint must be partition-key-aware, which is a real design constraint, not just an extra step.
- The Expand-Contract pattern from schema-migration-design: still fully applicable and still the right approach — but the "old" and "new" columns now need to be added consistently across every partition via the parent table, and a migration script needs to account for partitions that don't exist yet at the time it runs (a genuine intersection with Finding 2 — new partitions created by the maintenance job after a migration also need the new column, which they get automatically if the parent table has it, but this needs to be verified, not assumed).
- Dropping old data: this is where partitioning is a genuine, large improvement over an unpartitioned table — DROP TABLE TRANSACTION_HEADER_2020_01 instantly removes a year-old partition, versus a DELETE on an unpartitioned table scanning and removing rows one at a time, an operation that can take hours and generate enormous write-ahead-log volume on a table this size.

## Failure handling specifics

- A missing future partition: proven in Test 3 — a genuine, blocking insert failure, not a silent data-loss risk. This is arguably the correct failure mode (loud and immediate, not silent), but it means the maintenance job's own reliability directly gates write availability, a real dependency worth monitoring explicitly.
- A partition-local unique violation: behaves identically to a normal table's constraint violation — no new failure mode here.
- Cross-partition duplicate (Finding 1's exact scenario): the most dangerous failure mode, because it does not raise any error at all — it silently succeeds when it shouldn't. This is the one genuinely worth the most operational attention, since a silent failure is harder to catch than a loud one.

## Other bottlenecks worth naming honestly

- Too many partitions is itself a real performance problem — Postgres's query planner has real per-partition overhead, and thousands of tiny partitions (e.g., partitioning by day instead of month for a moderate-volume table) can make query planning itself slower than the unpartitioned baseline. Partition granularity is a real tuning decision, not "more partitions is always better."
- Cross-partition JOINs and aggregations (e.g., a full-year settlement report) still need to touch every relevant partition — pruning helps narrow-date queries, but a genuinely wide-date-range report doesn't get the same benefit, and this is worth setting realistic expectations about rather than implying partitioning fixes every query pattern.
- Backup and restore genuinely become easier to reason about per-partition (older partitions can move to cheaper storage tiers, or be backed up on a slower schedule since they're immutable) — a real, positive operational property, not covered by the tests here but worth naming as part of the honest complete picture.

## Files

```
ddl/transaction_header_partitioned_ddl.sql       - corrected partitioned schema with the constraint fix
service/partitioning_analysis.py                 - 5 tests across all three findings
```

## Honest summary

This was a real, significant, previously unaddressed gap — not a minor omission. The specific mechanism that would have broken silently (Finding 1) is exactly the kind of thing that passes every test written against a single partition and only fails once real data spans a month boundary — precisely the failure mode this whole session has been built around catching before it reaches production, not after.
