-- ============================================================
-- ECBP TRANSACTION_HEADER — Corrected Partitioned Schema
-- ============================================================
-- Real range partitioning by month, WITH the fix for the unique
-- constraint problem proven in partitioning_analysis.py's Test 1:
-- the original bare UNIQUE(IDEMPOTENCY_KEY) constraint cannot be
-- declared on a partitioned table in Postgres unless the partition
-- key is part of it - and even where the database technically
-- allows a workaround, per-partition-only uniqueness silently loses
-- the real, global guarantee the whole idempotency mechanism exists
-- for.
-- ============================================================

CREATE TABLE TRANSACTION_HEADER (
    TXN_ID              UUID            NOT NULL DEFAULT gen_random_uuid(),
    TXN_TYPE               VARCHAR(20)  NOT NULL,
    STATUS                    VARCHAR(20) NOT NULL,
    IDEMPOTENCY_KEY              VARCHAR(64) NOT NULL,
    CREATED_AT                     TIMESTAMPTZ NOT NULL DEFAULT now(),  -- THE partition key
    SETTLED_AT                        TIMESTAMPTZ NULL,

    -- THE FIX: the primary key and the unique constraint BOTH now
    -- include CREATED_AT, satisfying Postgres's real requirement
    -- that every unique constraint on a partitioned table include
    -- the partition key.
    PRIMARY KEY (TXN_ID, CREATED_AT),
    CONSTRAINT UQ_IDEMPOTENCY_KEY UNIQUE (IDEMPOTENCY_KEY, CREATED_AT)
) PARTITION BY RANGE (CREATED_AT);

-- ------------------------------------------------------------
-- THE HONEST REMAINING GAP, even with the fix above: this
-- constraint is now only enforced correctly IF every caller
-- supplies the correct CREATED_AT alongside IDEMPOTENCY_KEY when
-- checking for a duplicate - it does NOT, on its own, prevent a
-- genuinely duplicate submission that happens to land in two
-- DIFFERENT months (e.g. a retry submitted 32 days after the
-- original, crossing a month boundary). For a real production
-- system, this residual risk is closed by ALSO maintaining a
-- separate, small, global idempotency-key lookup table (unpartitioned,
-- since it only stores keys and a pointer, not full transaction
-- rows) - checked FIRST, before the partitioned insert - exactly
-- the CorrectPartitionedIdempotencyStore pattern proven in
-- partitioning_analysis.py's Test 2.
-- ------------------------------------------------------------

CREATE TABLE IDEMPOTENCY_KEY_LOOKUP (
    IDEMPOTENCY_KEY      VARCHAR(64)     PRIMARY KEY,   -- genuinely global, unpartitioned, small
    TXN_ID                  UUID         NOT NULL,
    CREATED_AT                 TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Example partitions - a real deployment creates these via the
-- automated maintenance job (see PARTITION_MAINTENANCE_LOG below),
-- never by hand, for exactly the reason proven in Test 3/4.
CREATE TABLE TRANSACTION_HEADER_2026_08 PARTITION OF TRANSACTION_HEADER
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
CREATE TABLE TRANSACTION_HEADER_2026_09 PARTITION OF TRANSACTION_HEADER
    FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');
CREATE TABLE TRANSACTION_HEADER_2026_10 PARTITION OF TRANSACTION_HEADER
    FOR VALUES FROM ('2026-10-01') TO ('2026-11-01');

-- ------------------------------------------------------------
-- Partition maintenance tracking - the automated job's own audit
-- trail, same "one place to see the whole story" principle as
-- journal-design earlier today.
-- ------------------------------------------------------------
CREATE TABLE PARTITION_MAINTENANCE_LOG (
    MAINTENANCE_ID        UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    PARTITION_NAME            VARCHAR(50) NOT NULL,
    ACTION                       VARCHAR(20) NOT NULL,  -- CREATED, DROPPED
    RUN_AT                          TIMESTAMPTZ NOT NULL DEFAULT now()
);
