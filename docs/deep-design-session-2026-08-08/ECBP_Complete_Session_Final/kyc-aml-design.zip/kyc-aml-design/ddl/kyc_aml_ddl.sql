-- ============================================================
-- ECBP KYC / AML / Sanctions Screening — DDL
-- ============================================================
-- Grounded in current, real requirements confirmed via research:
--   - FATF Recommendations 10/11, US BSA/PATRIOT Act/FinCEN CDD Rule
--   - 25% beneficial ownership threshold (US/EU standard)
--   - Currency Transaction Reports (CTR) mandatory for cash > $10,000
--   - Suspicious Activity Reports (SAR) for red-flag patterns
--   - Perpetual/ongoing KYC (2026 industry direction, not just onboarding)
-- ============================================================

CREATE TABLE CUSTOMER_KYC_PROFILE (
    ACCOUNT_ID                VARCHAR(20)    PRIMARY KEY,   -- links to Phase 1's ACCOUNT table
    FULL_LEGAL_NAME               VARCHAR(200) NOT NULL,
    DATE_OF_BIRTH                    DATE      NULL,
    RISK_RATING                        VARCHAR(10) NOT NULL DEFAULT 'MEDIUM', -- LOW, MEDIUM, HIGH
    ONBOARDED_AT                          TIMESTAMPTZ NOT NULL DEFAULT now(),
    LAST_REVIEWED_AT                        TIMESTAMPTZ NOT NULL DEFAULT now(),
    NEXT_REVIEW_DUE                           DATE      NOT NULL  -- risk-based cadence: HIGH=annual, MEDIUM=2yr, LOW=3yr
);

CREATE TABLE BENEFICIAL_OWNER (
    ACCOUNT_ID                VARCHAR(20)    NOT NULL REFERENCES CUSTOMER_KYC_PROFILE(ACCOUNT_ID),
    OWNER_NAME                    VARCHAR(200) NOT NULL,
    OWNERSHIP_PERCENTAGE              DECIMAL(5,2) NOT NULL,
    IDENTIFICATION_STATUS               VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, VERIFIED

    PRIMARY KEY (ACCOUNT_ID, OWNER_NAME)
);
-- Only owners at or above 25% MUST be identified (US/EU standard,
-- confirmed via research) - enforced in application logic below,
-- not by a CHECK constraint, since exact thresholds are jurisdiction-
-- configurable, not a universal database-level invariant.

CREATE TABLE SANCTIONS_LIST_ENTRY (
    ENTRY_ID                  UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    LIST_SOURCE                   VARCHAR(20) NOT NULL,   -- OFAC, UN, EU
    LISTED_NAME                       VARCHAR(200) NOT NULL,
    LISTED_NAME_NORMALIZED               VARCHAR(200) NOT NULL,  -- uppercase, tokens sorted - see screening_engine.py
    DATE_OF_BIRTH                          DATE       NULL,
    LOADED_AT                                TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE PEP_LIST_ENTRY (
    ENTRY_ID                  UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    FULL_NAME                     VARCHAR(200) NOT NULL,
    FULL_NAME_NORMALIZED             VARCHAR(200) NOT NULL,
    POSITION                            VARCHAR(200) NOT NULL,
    COUNTRY                                VARCHAR(50) NOT NULL,
    LOADED_AT                                TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE SCREENING_RESULT (
    SCREENING_ID               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    ACCOUNT_ID                    VARCHAR(20) NOT NULL,
    SCREENING_TYPE                    VARCHAR(20) NOT NULL,  -- ONBOARDING, ONGOING, LIST_UPDATE_TRIGGERED
    LIST_TYPE                            VARCHAR(20) NOT NULL, -- SANCTIONS, PEP
    MATCHED_ENTRY_ID                        UUID     NULL,
    MATCH_SCORE                                DECIMAL(4,3) NULL,  -- 0.000 to 1.000
    OUTCOME                                       VARCHAR(20) NOT NULL,  -- CLEAR, POTENTIAL_MATCH, CONFIRMED_MATCH
    SCREENED_AT                                     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_SCREENING_ACCOUNT ON SCREENING_RESULT (ACCOUNT_ID, SCREENED_AT);
CREATE INDEX IDX_SCREENING_POTENTIAL ON SCREENING_RESULT (OUTCOME) WHERE OUTCOME = 'POTENTIAL_MATCH';

CREATE TABLE CURRENCY_TRANSACTION_REPORT (
    CTR_ID                    UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_ID                       UUID         NOT NULL,   -- same correlation key as every package today
    ACCOUNT_ID                      VARCHAR(20) NOT NULL,
    AMOUNT                              DECIMAL(15,2) NOT NULL,
    TRIGGERED_AT                           TIMESTAMPTZ NOT NULL DEFAULT now(),
    FILED_AT                                  TIMESTAMPTZ NULL
);
-- Mandatory per BSA whenever a single cash transaction exceeds
-- $10,000 - confirmed threshold via research.

CREATE TABLE SUSPICIOUS_ACTIVITY_REPORT (
    SAR_ID                     UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    ACCOUNT_ID                    VARCHAR(20) NOT NULL,
    TRIGGER_PATTERN                   VARCHAR(30) NOT NULL,  -- STRUCTURING, SANCTIONS_MATCH, UNUSUAL_VELOCITY
    DESCRIPTION                          TEXT     NOT NULL,
    RELATED_TXN_IDS                         UUID[]  NOT NULL,
    STATUS                                    VARCHAR(20) NOT NULL DEFAULT 'DRAFT',  -- DRAFT, FILED
    CREATED_AT                                  TIMESTAMPTZ NOT NULL DEFAULT now()
);
