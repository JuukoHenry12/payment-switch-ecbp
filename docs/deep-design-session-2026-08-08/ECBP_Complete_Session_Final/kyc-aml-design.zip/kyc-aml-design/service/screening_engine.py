"""
screening_engine.py — real sanctions/PEP name screening. The core
technical challenge, stated honestly: exact string matching is
useless here. Sanctioned individuals appear across lists with name
reordering ("SMITH, JOHN" vs "JOHN SMITH"), transliteration variants
(Arabic/Cyrillic names romanized differently across sources), and
minor spelling differences. Miss a real variant -> a genuine
sanctions violation with real regulatory and criminal exposure. Match
too loosely -> compliance teams drown in false positives and stop
trusting the system, which is its own serious failure mode.

Uses token-normalized fuzzy matching, not raw string comparison, and
is tested specifically against both failure directions - a real
variant that MUST be caught, and a genuinely different name that
MUST NOT be flagged.

Test data note: all names below are deliberately fictional, chosen
only to exercise the matching algorithm's behavior - none reference
any real sanctioned individual or list entry.
"""

from dataclasses import dataclass
from difflib import SequenceMatcher


MATCH_THRESHOLD = 0.85       # score at or above this = CONFIRMED_MATCH, requires immediate block
POTENTIAL_THRESHOLD = 0.65   # score at or above this (below MATCH_THRESHOLD) = POTENTIAL_MATCH, human review


def normalize_name(name: str) -> str:
    """
    Uppercase and TOKEN-SORT the name. This is what makes
    'SMITH, JOHN' and 'JOHN SMITH' comparable at all - a raw string
    comparison would treat those as almost entirely different strings
    despite representing the same person.
    """
    cleaned = name.upper().replace(",", " ")
    tokens = sorted(cleaned.split())
    return " ".join(tokens)


def similarity_score(name_a: str, name_b: str) -> float:
    normalized_a = normalize_name(name_a)
    normalized_b = normalize_name(name_b)
    return SequenceMatcher(None, normalized_a, normalized_b).ratio()


@dataclass
class ListEntry:
    entry_id: str
    listed_name: str
    list_source: str


class ScreeningOutcome:
    CLEAR = "CLEAR"
    POTENTIAL_MATCH = "POTENTIAL_MATCH"
    CONFIRMED_MATCH = "CONFIRMED_MATCH"


@dataclass
class ScreeningResult:
    account_id: str
    outcome: str
    matched_entry: ListEntry | None
    match_score: float | None


class SanctionsScreeningEngine:

    def __init__(self, sanctions_list: list[ListEntry], pep_list: list[ListEntry]):
        # Loaded into memory once, same principle as the routing
        # engine from earlier today - sanctions/PEP screening happens
        # on every onboarding and every ongoing review, this cannot
        # be a per-check database round-trip at real volume.
        self.sanctions_list = sanctions_list
        self.pep_list = pep_list

    def screen(self, account_id: str, customer_name: str, list_type: str = "SANCTIONS") -> ScreeningResult:
        candidate_list = self.sanctions_list if list_type == "SANCTIONS" else self.pep_list

        best_match: ListEntry | None = None
        best_score = 0.0

        for entry in candidate_list:
            score = similarity_score(customer_name, entry.listed_name)
            if score > best_score:
                best_score = score
                best_match = entry

        if best_score >= MATCH_THRESHOLD:
            return ScreeningResult(account_id, ScreeningOutcome.CONFIRMED_MATCH, best_match, best_score)
        elif best_score >= POTENTIAL_THRESHOLD:
            return ScreeningResult(account_id, ScreeningOutcome.POTENTIAL_MATCH, best_match, best_score)
        else:
            return ScreeningResult(account_id, ScreeningOutcome.CLEAR, None, best_score)


# ------------------------------------------------------------
# REAL TESTS - fictional test names only, chosen to exercise the
# algorithm's behavior, not to reference any real sanctioned party
# ------------------------------------------------------------
if __name__ == "__main__":

    sanctions_list = [
        ListEntry("SANC-001", "AL-RASHIDI, KHALID MANSOUR", "OFAC"),
        ListEntry("SANC-002", "PETROV, DMITRI VLADIMIROVICH", "UN"),
        ListEntry("SANC-003", "OKONKWO, EMEKA CHUKWU", "EU"),
    ]
    pep_list = [
        ListEntry("PEP-001", "TANAKA, HIROSHI", "PEP-REGISTRY"),
    ]

    engine = SanctionsScreeningEngine(sanctions_list, pep_list)

    print("=== TEST 1: EXACT match (should CONFIRM immediately) ===")
    r1 = engine.screen("ACC-TEST-001", "AL-RASHIDI, KHALID MANSOUR")
    print(f"Outcome: {r1.outcome}, score: {r1.match_score:.3f} (expected: CONFIRMED_MATCH)")

    print()
    print("=== TEST 2: Name REORDERED - 'first last' vs listed 'last, first' - MUST still catch this ===")
    r2 = engine.screen("ACC-TEST-002", "Khalid Mansour Al-Rashidi")
    print(f"Outcome: {r2.outcome}, score: {r2.match_score:.3f} (expected: CONFIRMED_MATCH or at least POTENTIAL - "
          f"a raw string comparison would likely miss this entirely)")

    print()
    print("=== TEST 3: Minor spelling/transliteration variant - a real, common sanctions-screening challenge ===")
    r3 = engine.screen("ACC-TEST-003", "Petrov, Dmitri Vladimirovic")  # one letter different in the patronymic
    print(f"Outcome: {r3.outcome}, score: {r3.match_score:.3f} (expected: CONFIRMED_MATCH or POTENTIAL_MATCH - "
          f"should NOT silently clear a near-identical name)")

    print()
    print("=== TEST 4: GENUINELY different name - must NOT false-positive ===")
    r4 = engine.screen("ACC-TEST-004", "Sarah Jennifer Thompson")
    print(f"Outcome: {r4.outcome}, score: {r4.match_score:.3f} (expected: CLEAR - a real, unrelated customer)")

    print()
    print("=== TEST 5: A common short name with SOME token overlap but genuinely different person ===")
    r5 = engine.screen("ACC-TEST-005", "Chukwu Emeka Adeyemi")  # shares 2 of 3 tokens with SANC-003 but is a different person
    print(f"Outcome: {r5.outcome}, score: {r5.match_score:.3f}")
    print("(honest note: this scored 0.600, just under POTENTIAL_THRESHOLD, so it correctly")
    print(" returned CLEAR rather than flagging a genuinely different person. Worth knowing")
    print(" this threshold sits close enough to real partial-overlap cases that it deserves")
    print(" ongoing tuning against real compliance team feedback, not a one-time fixed value -")
    print(" a slightly different real name could easily land just above 0.65 instead.)")

    print()
    print("=== TEST 6: PEP screening - separate list, separate check ===")
    r6 = engine.screen("ACC-TEST-006", "Hiroshi Tanaka", list_type="PEP")
    print(f"Outcome: {r6.outcome}, score: {r6.match_score:.3f} (expected: CONFIRMED_MATCH against the PEP list)")

    print()
    print("=== TEST 7: Same customer checked against PEP list when they're only on it as a NON-issue ===")
    r7 = engine.screen("ACC-TEST-004", "Sarah Jennifer Thompson", list_type="PEP")
    print(f"Outcome: {r7.outcome} (expected: CLEAR - confirms PEP and sanctions lists are checked independently, "
          f"not conflated into one combined score)")
