"""
ctr_and_structuring.py — two real, specific, regulator-mandated AML
mechanisms, both grounded in confirmed current thresholds:

  1. CTR (Currency Transaction Report) - mandatory under the US Bank
     Secrecy Act whenever a SINGLE cash transaction exceeds $10,000.
     A simple, hard threshold check.

  2. STRUCTURING detection - the classic, well-known evasion pattern:
     splitting one large cash transaction into several smaller ones,
     each individually under the $10,000 CTR threshold, specifically
     to avoid triggering a report. This is itself a distinct, real
     crime (deliberately evading a reporting requirement), not just
     "many small transactions" - detecting the PATTERN, not the
     individual transaction, is the actual point.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta


CTR_THRESHOLD = 10_000.00
STRUCTURING_WINDOW_DAYS = 7
STRUCTURING_NEAR_THRESHOLD_RATIO = 0.90  # transactions at or above 90% of the CTR threshold count as "near-threshold"
STRUCTURING_MIN_COUNT = 3                 # 3+ near-threshold cash transactions in the window triggers a SAR


@dataclass
class CashTransaction:
    txn_id: str
    account_id: str
    amount: float
    occurred_at: datetime


def check_ctr_required(txn: CashTransaction) -> bool:
    """The simple, hard-threshold case."""
    return txn.amount > CTR_THRESHOLD


def detect_structuring(account_id: str, transactions: list[CashTransaction], now: datetime) -> dict | None:
    """
    Looks for the actual PATTERN: multiple near-threshold cash
    transactions from the SAME account within a short window. This
    is deliberately not just "count transactions over some amount" -
    it specifically looks for transactions clustered just BELOW the
    reporting threshold, which is the real, known signature of
    structuring, distinct from someone simply making several
    unrelated smaller cash deposits over time.
    """
    near_threshold_min = CTR_THRESHOLD * STRUCTURING_NEAR_THRESHOLD_RATIO
    window_start = now - timedelta(days=STRUCTURING_WINDOW_DAYS)

    suspicious = [
        t for t in transactions
        if t.account_id == account_id
        and window_start <= t.occurred_at <= now
        and near_threshold_min <= t.amount <= CTR_THRESHOLD
    ]

    if len(suspicious) >= STRUCTURING_MIN_COUNT:
        total = sum(t.amount for t in suspicious)
        return {
            "account_id": account_id,
            "pattern": "STRUCTURING",
            "transaction_count": len(suspicious),
            "total_amount": total,
            "related_txn_ids": [t.txn_id for t in suspicious],
            "description": (
                f"{len(suspicious)} cash transactions between "
                f"${near_threshold_min:,.2f} and ${CTR_THRESHOLD:,.2f} "
                f"within {STRUCTURING_WINDOW_DAYS} days, totaling ${total:,.2f} - "
                f"consistent with deliberate structuring to evade CTR reporting"
            ),
        }
    return None


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: A single cash transaction over $10,000 - CTR required ===")
    txn1 = CashTransaction("TXN-CASH-001", "ACC0001234", 15000.00, datetime(2026, 8, 8))
    print(f"CTR required: {check_ctr_required(txn1)} (expected: True)")

    print()
    print("=== TEST 2: A cash transaction at exactly $10,000 - NOT over the threshold ===")
    txn2 = CashTransaction("TXN-CASH-002", "ACC0001234", 10000.00, datetime(2026, 8, 8))
    print(f"CTR required: {check_ctr_required(txn2)} (expected: False - the rule is 'exceeds', not 'at or above')")

    print()
    print("=== TEST 3: THE STRUCTURING PATTERN - three deposits just under threshold, same week ===")
    now = datetime(2026, 8, 8, 15, 0, 0)
    structuring_txns = [
        CashTransaction("TXN-S-001", "ACC0009999", 9500.00, now - timedelta(days=6)),
        CashTransaction("TXN-S-002", "ACC0009999", 9200.00, now - timedelta(days=3)),
        CashTransaction("TXN-S-003", "ACC0009999", 9800.00, now - timedelta(days=1)),
    ]
    result3 = detect_structuring("ACC0009999", structuring_txns, now)
    print(f"Structuring detected: {result3 is not None} (expected: True)")
    if result3:
        print(f"  {result3['description']}")

    print()
    print("=== TEST 4: NOT structuring - one large legitimate deposit, correctly NOT flagged ===")
    legit_txns = [CashTransaction("TXN-L-001", "ACC0001234", 25000.00, now - timedelta(days=1))]
    result4 = detect_structuring("ACC0001234", legit_txns, now)
    print(f"Structuring detected: {result4 is not None} (expected: False - a single large transaction "
          f"correctly triggers a CTR instead, not a structuring SAR)")

    print()
    print("=== TEST 5: NOT structuring - several SMALL, genuinely unrelated deposits (not near-threshold) ===")
    small_txns = [
        CashTransaction("TXN-SM-001", "ACC0005678", 500.00, now - timedelta(days=5)),
        CashTransaction("TXN-SM-002", "ACC0005678", 300.00, now - timedelta(days=3)),
        CashTransaction("TXN-SM-003", "ACC0005678", 450.00, now - timedelta(days=1)),
    ]
    result5 = detect_structuring("ACC0005678", small_txns, now)
    print(f"Structuring detected: {result5 is not None} (expected: False - genuinely small, unrelated "
          f"transactions, not clustered near the reporting threshold)")

    print()
    print("=== TEST 6: NOT structuring - near-threshold transactions but OUTSIDE the 7-day window ===")
    spread_out_txns = [
        CashTransaction("TXN-SP-001", "ACC0002222", 9500.00, now - timedelta(days=6)),
        CashTransaction("TXN-SP-002", "ACC0002222", 9200.00, now - timedelta(days=20)),  # too far apart
        CashTransaction("TXN-SP-003", "ACC0002222", 9800.00, now - timedelta(days=35)),
    ]
    result6 = detect_structuring("ACC0002222", spread_out_txns, now)
    print(f"Structuring detected: {result6 is not None} (expected: False - spread over weeks, not the "
          f"tight clustering that actually indicates deliberate evasion)")

    print()
    print("=== TEST 7: Two near-threshold transactions is NOT enough - the pattern needs 3+ ===")
    two_txns = [
        CashTransaction("TXN-TWO-001", "ACC0003333", 9500.00, now - timedelta(days=3)),
        CashTransaction("TXN-TWO-002", "ACC0003333", 9200.00, now - timedelta(days=1)),
    ]
    result7 = detect_structuring("ACC0003333", two_txns, now)
    print(f"Structuring detected: {result7 is not None} (expected: False - avoids over-flagging on "
          f"just two transactions, which could still be coincidental)")
