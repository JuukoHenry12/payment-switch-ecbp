# KYC / AML / Sanctions Screening — Design Package

## Why this is the highest-stakes package built today

Confirmed via research before building anything: global AML enforcement fines reached roughly $4.6 billion in 2024 alone, with TD Bank alone paying $3.09 billion. This isn't a nice-to-have module — it's one of the most consequential compliance obligations a bank carries, and it was completely absent from ECBP before this package (only a single generic `BLACKLIST` fraud rule existed, nowhere close to real sanctions screening).

## Grounded in current, real requirements — not assumed

- **25% beneficial ownership threshold** — the confirmed US/EU standard (FinCEN CDD Rule)
- **$10,000 CTR threshold** — the confirmed US Bank Secrecy Act requirement for cash transactions
- **February 2026 FinCEN relief** — banks are no longer required to re-verify beneficial owners at *every* new account opening for an already-verified entity, only under three specific circumstances. This is current, real, and easy to over-apply incorrectly (defaulting to "always re-verify") if not built deliberately against the actual current rule

## Files

```
ddl/kyc_aml_ddl.sql                    - CUSTOMER_KYC_PROFILE, BENEFICIAL_OWNER, SANCTIONS_LIST_ENTRY, PEP_LIST_ENTRY, SCREENING_RESULT, CTR, SAR
service/screening_engine.py            - fuzzy name matching, tested against 7 scenarios
service/ctr_and_structuring.py         - CTR threshold + structuring pattern detection, tested against 7 scenarios
service/beneficial_ownership.py        - 25% threshold + the 2026 re-verification relief, tested against 5 scenarios
```

**Note on test data**: every name used in testing is deliberately fictional, chosen only to exercise the matching algorithm — none reference any real sanctioned individual or list entry.

## The core technical challenge, solved and tested

Sanctions screening cannot be exact-string matching — real sanctioned individuals appear across lists with reordered names, transliteration variants, and minor spelling differences. `screening_engine.py`'s token-normalized fuzzy matching was tested against both failure directions that actually matter:

- **A reordered name** ("Khalid Mansour Al-Rashidi" vs. the listed "AL-RASHIDI, KHALID MANSOUR") — correctly caught, scoring 1.000 after normalization, something a raw string comparison would likely miss entirely
- **A genuinely different name** — correctly cleared, not falsely flagged
- **The honest hard case** — a name sharing 2 of 3 tokens with a listed entry scored 0.600, just under the review threshold, correctly returning `CLEAR`. Worth being direct about this: a slightly different real name could easily land just above that threshold instead, which is exactly why this needs ongoing tuning against real compliance feedback, not a fixed value set once and left alone

## The structuring detection — the real, specific evasion pattern, not just "many small transactions"

Test 3's actual output reads like a real SAR narrative would: *"3 cash transactions between $9,000.00 and $10,000.00 within 7 days, totaling $28,500.00 — consistent with deliberate structuring to evade CTR reporting."* The detector specifically looks for transactions clustered *near, but under*, the reporting threshold — not simply "several small transactions," which Test 5 confirms correctly does NOT trigger a false alarm.

## How this connects to everything built today

```
New account opens → CUSTOMER_KYC_PROFILE created →
SanctionsScreeningEngine.screen() + PEP screen (onboarding)
        │
        ▼
Every cash transaction → check_ctr_required() → CTR filed if needed
        │
        ▼
Periodically (or on list update) → detect_structuring() scans recent
cash activity per account → SUSPICIOUS_ACTIVITY_REPORT drafted if
the pattern is found
        │
        ▼
Any CONFIRMED_MATCH from screening → uses the SAME reason-code
taxonomy (routing-design) and gets logged in the SAME transaction
journal (journal-design) as every other failure in the system —
a compliance investigation and a payment investigation speak the
same vocabulary
```

## Honest limitations, stated plainly

- **Real sanctions/PEP list ingestion** (actually pulling and parsing OFAC/UN/EU published lists) is not built — this package proves the *matching logic* is correct against realistic test data, not a live feed integration
- **The fuzzy-matching thresholds (0.65/0.85) are a reasonable starting point, not a regulator-validated calibration** — real deployment requires tuning against a compliance team's actual false-positive/false-negative tolerance, an ongoing operational process, not a one-time engineering decision
- **Adverse media screening** (checking news sources for negative coverage, a real component of full KYC per the research) is not built here — this package covers sanctions, PEP, beneficial ownership, and the two most well-known transaction-monitoring patterns (large cash, structuring), not the complete AML surface
