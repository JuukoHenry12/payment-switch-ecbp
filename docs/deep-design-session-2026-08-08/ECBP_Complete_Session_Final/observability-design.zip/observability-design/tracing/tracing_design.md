## Distributed Tracing — OpenTelemetry Span Design

Using **TXN-003** (the reconciliation-break journey) as the concrete example, since it's the one that genuinely touches the most services — exactly the case where distributed tracing earns its value, versus a simple single-service happy path where a trace adds little.

### The span tree for TXN-003, end to end

```
[trace_id: 7a3f...] payment-service: POST /api/v1/transfers          13ms
    │
    ├── [span] account-service: debit hold + entry post                 8ms
    │
    ├── [span] risk-service: fraud check (rule engine only, no flag)    3ms
    │
    ├── [span] payment-service: publish PaymentSettled                  2ms
    │
    ├── [span] settlement-service: attemptSettlement()                  5ms
    │       └── [span] liquidity-service: check spendable liquidity     2ms
    │
    ├── [span] settlement-service: SettlementQueued (insufficient)      -
    │       ... (gap here - this is real elapsed time, not span
    │            duration, while liquidity is genuinely unavailable) ...
    │
    ├── [span] settlement-service: gridlock resolution sweep            4ms
    │       └── SettlementReleased, queuedDurationMillis=4200
    │
    └── [span, 2 hours later] reconciliation-service: timeout sweep     1ms
            └── ReconciliationBreakDetected (OVERDUE_CONFIRMATION)
```

### Why the propagation design matters, specifically here

**The `txn_id` IS the trace correlation key** — every event schema designed today already carries `txnId` (after today's fix to the reconciliation events). This is not a coincidence; it means distributed tracing and the CQRS read-model projector both key off the exact same identifier. A single `txn_id` lets you move seamlessly between "show me the trace" (OpenTelemetry/Jaeger UI, for a developer debugging in real time) and "show me the full business lifecycle" (`TRANSACTION_LIFECYCLE_VIEW`, for an ops/business user), without needing a separate correlation scheme for each.

**The multi-hour gap between settlement release and the reconciliation break is real, not a tracing artifact.** A trace spanning 2+ hours (queued liquidity wait, then a scheduled reconciliation sweep) is unusual compared to typical sub-second request traces — worth configuring trace retention and sampling accordingly (100% sampling on every request-scoped span, but the reconciliation sweep's span should link back via `txn_id`/`settlement_id` context propagation rather than assuming the original trace context is still technically "live" after that much elapsed time).

### Practical implementation note

```java
// Every service, at its entry point, does this:
Span span = tracer.spanBuilder(spanName)
    .setAttribute("txn_id", txnId)  // the SAME field name as every Kafka event
    .setParent(Context.current())    // propagated via W3C traceparent header
                                      // for synchronous calls, or embedded in
                                      // the Kafka message headers for async
    .startSpan();
```

For the asynchronous hops (Kafka-published events, like the 2-hour-later reconciliation sweep), trace context propagates via Kafka message headers, not just synchronous HTTP headers — this is the standard OpenTelemetry pattern for event-driven systems and is what makes the "2 hours later" reconciliation span still correctly attribute back to the original trace, rather than becoming a disconnected orphan.
