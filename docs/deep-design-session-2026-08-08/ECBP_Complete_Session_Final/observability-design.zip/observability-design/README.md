# Observability & Reporting — Design Package

## What this closes

Every event schema designed today (11 total, across ledger, settlement, liquidity, gridlock, reconciliation, fraud) now has somewhere to actually go: a denormalized read model for business reporting, structured logs for operational search, and distributed traces for debugging — all three keyed off the same `txn_id`.

## A real bug found through this exact testing process

Building the CQRS projector against real event sequences surfaced a genuine gap: `ReconciliationBreakDetected` and `ReconciliationBreakResolved` (designed during the reconciliation session) never included `txnId` — only `settlementId`. Any consumer needing to correlate a break back to its transaction would have needed an extra lookup, which defeats the point of an event-driven denormalized projection. **Both schemas have been fixed and the reconciliation-design.zip has been re-packaged** — if you already downloaded that zip earlier, re-download it now.

This is exactly the value of testing across the full chain rather than each piece in isolation — this gap was invisible when reconciliation was designed on its own, and only became obvious once a consumer actually tried to use the event for its real purpose.

## Files

```
ddl/cqrs_read_model_ddl.sql       - TRANSACTION_LIFECYCLE_VIEW, DAILY_SETTLEMENT_SUMMARY
projector/event_projector.py      - tested against 3 realistic multi-event transaction journeys
logging/splunk_logging.py         - structured log format, tested with 4 real SPL-equivalent queries
tracing/tracing_design.md         - OpenTelemetry span design using the same txn_id correlation
```

## Verified, working — real results

**CQRS Projector**: 3 transaction journeys (clean happy path, fraud-blocked, settled-then-reconciliation-break), all projected correctly. The fraud journey specifically proves the "BLOCK always wins regardless of arrival order" rule holds even with two different detection methods firing for the same transaction. The daily summary report, built purely from the read model with zero access to write-side tables, correctly aggregates: 3 transactions, 2 settled, 1 failed, 1 fraud-blocked, 1 open reconciliation break.

**Splunk logging**: 11 real log lines generated and validated as parseable JSON, then 3 SPL-equivalent queries run against them — errors-by-service, latency-by-service (the real p50/p95/p99 operational question), and a full single-transaction trace across 3 services.

## How this ties every piece from today together

```
account-service, payment-service, risk-service, settlement-service,
liquidity-service, reconciliation-service — all publish events
        │
        ├──► Kafka (the actual production path) ──► EventProjector
        │                                             │
        │                                             ▼
        │                                   TRANSACTION_LIFECYCLE_VIEW
        │                                   (business/regulatory reporting,
        │                                    zero load on write-side tables)
        │
        ├──► Structured JSON logs ──► Splunk HEC
        │                               │
        │                               ▼
        │                     Operational dashboards, alerts
        │                     (errors by service, latency percentiles)
        │
        └──► OpenTelemetry spans, txn_id-correlated ──► Jaeger/tracing backend
                                                            │
                                                            ▼
                                                  Developer debugging,
                                                  root-cause analysis
```

**One correlation key (`txn_id`) drives all three views** — business reporting, operational monitoring, and developer debugging — rather than three separate, disconnected identification schemes. That consistency is itself a design decision worth being able to articulate, not an accident.

## Immediate next step

1. Apply `cqrs_read_model_ddl.sql`
2. Wire `EventProjector` into a real Kafka consumer (Spring Kafka `@KafkaListener` per event type, calling the equivalent of `apply()`)
3. Re-download the corrected `reconciliation-design.zip` if you already have the old version
4. Configure each service's logging framework (Logback, given your Spring Boot stack) to emit the structured JSON format from `splunk_logging.py`, shipped to Splunk via HEC
