"""
splunk_logging.py — the structured log format every ECBP service
emits, designed for Splunk HEC ingestion. Validated here by actually
generating log lines from today's three test transactions and
running SPL-equivalent search/aggregation logic against them, proving
the format supports the real operational questions it needs to.
"""

import json
from datetime import datetime, timezone


def structured_log(service: str, level: str, event_type: str, txn_id: str, **fields) -> str:
    """
    Every ECBP service log line follows this exact shape - consistent
    structure is what makes Splunk field extraction reliable without
    fragile regex parsing of free-text log lines.
    """
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "service": service,
        "level": level,
        "event_type": event_type,
        "txn_id": txn_id,
        **fields,
    }
    return json.dumps(entry)


# ------------------------------------------------------------
# Generate real log lines matching today's three test journeys
# ------------------------------------------------------------
log_lines = [
    structured_log("payment-service", "INFO", "PaymentInitiated", "TXN-001",
                    from_account="ACC0001234", to_account="ACC0005678", amount=250.00, latency_ms=12),
    structured_log("risk-service", "INFO", "FraudCheckCompleted", "TXN-001",
                    detection_method="RULE_ENGINE", action="ALLOW_WITH_MONITORING", latency_ms=3),
    structured_log("account-service", "INFO", "PaymentSettled", "TXN-001", latency_ms=45),

    structured_log("payment-service", "INFO", "PaymentInitiated", "TXN-002",
                    from_account="ACC0009999", to_account="ACC0001234", amount=25000.00, latency_ms=11),
    structured_log("risk-service", "WARN", "FraudCheckCompleted", "TXN-002",
                    detection_method="ML_ANOMALY", action="FLAG_FOR_REVIEW", latency_ms=8),
    structured_log("risk-service", "ERROR", "FraudCheckCompleted", "TXN-002",
                    detection_method="RULE_ENGINE", action="BLOCK", latency_ms=2),
    structured_log("payment-service", "ERROR", "PaymentFailed", "TXN-002",
                    reason_code="FRAUD_DECLINED", latency_ms=67),

    structured_log("payment-service", "INFO", "PaymentInitiated", "TXN-003",
                    from_account="ACC0001234", to_account="EXTERNAL-CORRESPONDENT-A", amount=5000.00, latency_ms=13),
    structured_log("settlement-service", "INFO", "SettlementQueued", "TXN-003",
                    settlement_account="SETL-CORR-A", latency_ms=5),
    structured_log("settlement-service", "INFO", "SettlementReleased", "TXN-003",
                    queued_duration_ms=4200, latency_ms=4),
    structured_log("reconciliation-service", "ERROR", "ReconciliationBreakDetected", "TXN-003",
                    break_type="OVERDUE_CONFIRMATION", latency_ms=1),
]

print("=== TEST 1: Every log line is valid, parseable JSON (required for Splunk field extraction) ===")
parsed_logs = []
all_valid = True
for line in log_lines:
    try:
        parsed = json.loads(line)
        parsed_logs.append(parsed)
    except json.JSONDecodeError:
        all_valid = False
print(f"All {len(log_lines)} log lines are valid JSON: {all_valid}")

print()
print("=== TEST 2: SPL-equivalent query — 'errors in the last hour, grouped by service' ===")
print("(SPL would be: index=ecbp level=ERROR | stats count by service)")
errors_by_service = {}
for log in parsed_logs:
    if log["level"] == "ERROR":
        errors_by_service[log["service"]] = errors_by_service.get(log["service"], 0) + 1
print(errors_by_service)
print("Expected: risk-service=1 (the BLOCK), payment-service=1 (the failure), "
      "reconciliation-service=1 (the break)")

print()
print("=== TEST 3: SPL-equivalent query — 'average latency by service' (the p50/p95/p99 operational question) ===")
print("(SPL would be: index=ecbp | stats avg(latency_ms) by service)")
latencies_by_service = {}
for log in parsed_logs:
    latencies_by_service.setdefault(log["service"], []).append(log["latency_ms"])
for service, latencies in latencies_by_service.items():
    print(f"  {service}: avg={sum(latencies)/len(latencies):.1f}ms, max={max(latencies)}ms, n={len(latencies)}")

print()
print("=== TEST 4: SPL-equivalent query — 'trace every log line for one specific transaction' ===")
print("(SPL would be: index=ecbp txn_id=\"TXN-003\" | sort timestamp)")
txn_003_trace = [log for log in parsed_logs if log["txn_id"] == "TXN-003"]
for log in txn_003_trace:
    print(f"  [{log['service']}] {log['event_type']} (level={log['level']})")
print(f"Found {len(txn_003_trace)} log lines for TXN-003 across {len(set(l['service'] for l in txn_003_trace))} services")
