-- ============================================================
-- ECBP CQRS Read Model — DDL
-- ============================================================
-- This is the read side, built EXCLUSIVELY from the Kafka events
-- designed across today's entire session:
--   PaymentInitiated, EntryPosted, PaymentSettled, PaymentFailed,
--   FraudFlagged, SettlementQueued, SettlementReleased,
--   ExternalSettlementConfirmed, ReconciliationBreakDetected,
--   ReconciliationBreakResolved
-- It NEVER queries the write-side ledger/settlement/fraud tables
-- directly - that separation is the entire point of CQRS, and it's
-- what lets reporting run at any volume without competing with live
-- transaction throughput for the same database resources.
-- ============================================================

CREATE TABLE TRANSACTION_LIFECYCLE_VIEW (
    TXN_ID                    UUID            PRIMARY KEY,
    FROM_ACCOUNT_ID             VARCHAR(20)   NOT NULL,
    TO_ACCOUNT_ID                 VARCHAR(20) NOT NULL,
    AMOUNT                          DECIMAL(15,2) NOT NULL,
    CURRENCY                          CHAR(3)   NOT NULL,

    -- Ledger lifecycle (from PaymentInitiated / EntryPosted / PaymentSettled / PaymentFailed)
    LEDGER_STATUS                      VARCHAR(20) NOT NULL,  -- PENDING, SETTLED, FAILED
    INITIATED_AT                         TIMESTAMPTZ NOT NULL,
    SETTLED_AT                            TIMESTAMPTZ NULL,
    FAILURE_REASON_CODE                    VARCHAR(30) NULL,

    -- Fraud lifecycle (from FraudFlagged, one row can represent multiple checks)
    FRAUD_CHECK_COUNT                        SMALLINT  NOT NULL DEFAULT 0,
    FRAUD_FINAL_ACTION                        VARCHAR(30) NULL,  -- ALLOW, FLAG_FOR_REVIEW, BLOCK

    -- External settlement lifecycle (from SettlementQueued / SettlementReleased / ExternalSettlementConfirmed)
    HAS_EXTERNAL_SETTLEMENT                    BOOLEAN    NOT NULL DEFAULT false,
    SETTLEMENT_STATUS                           VARCHAR(20) NULL,  -- QUEUED, RELEASED, CONFIRMED
    SETTLEMENT_QUEUED_DURATION_MS                 BIGINT   NULL,

    -- Reconciliation lifecycle (from ReconciliationBreakDetected / Resolved)
    RECONCILIATION_STATUS                          VARCHAR(20) NOT NULL DEFAULT 'CLEAN', -- CLEAN, BREAK_OPEN, BREAK_RESOLVED

    LAST_UPDATED_AT                                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_LIFECYCLE_STATUS ON TRANSACTION_LIFECYCLE_VIEW (LEDGER_STATUS, INITIATED_AT);
CREATE INDEX IDX_LIFECYCLE_FRAUD ON TRANSACTION_LIFECYCLE_VIEW (FRAUD_FINAL_ACTION) WHERE FRAUD_FINAL_ACTION IS NOT NULL;
CREATE INDEX IDX_LIFECYCLE_RECON ON TRANSACTION_LIFECYCLE_VIEW (RECONCILIATION_STATUS) WHERE RECONCILIATION_STATUS != 'CLEAN';

-- ------------------------------------------------------------
-- DAILY_SETTLEMENT_SUMMARY — a pre-aggregated report table,
-- rebuilt periodically from TRANSACTION_LIFECYCLE_VIEW. This is
-- what makes "give me today's settlement report" an instant query
-- instead of a live aggregation over potentially millions of rows.
-- ------------------------------------------------------------
CREATE TABLE DAILY_SETTLEMENT_SUMMARY (
    SUMMARY_DATE              DATE            PRIMARY KEY,
    TOTAL_TRANSACTIONS          INTEGER       NOT NULL,
    TOTAL_AMOUNT                  DECIMAL(18,2) NOT NULL,
    SETTLED_COUNT                    INTEGER  NOT NULL,
    FAILED_COUNT                      INTEGER NOT NULL,
    FRAUD_BLOCKED_COUNT                 INTEGER NOT NULL,
    FRAUD_FLAGGED_COUNT                   INTEGER NOT NULL,
    RECONCILIATION_BREAKS_OPENED            INTEGER NOT NULL,
    GENERATED_AT                              TIMESTAMPTZ NOT NULL DEFAULT now()
);
