import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;

/**
 * Follow-up to InMemoryTransactionPipeline.java's surprising result:
 * the "optimized" pooled+lock-free version was SLOWER than naive
 * alloc+synchronized. This isolates the two techniques separately
 * to find out honestly which claim (if either) actually holds up on
 * a modern JVM, rather than accepting or hiding the first result.
 */
public class IsolatedBenchmark {

    static class Ctx {
        String txnId; String routingDestination;
        void reset() { txnId = null; routingDestination = null; }
    }

    // --- Isolate ONLY the config-access pattern, no pooling involved ---
    private static final Map<String, String> plainMap = Map.of("453212", "SETL-CARD-VISA-01");
    private static final AtomicReference<Map<String, String>> atomicSnapshot =
            new AtomicReference<>(Map.of("453212", "SETL-CARD-VISA-01"));
    private static final Object lock = new Object();

    static String lookupSynchronized(String bin) {
        synchronized (lock) {
            return plainMap.getOrDefault(bin, "UNMATCHED");
        }
    }

    static String lookupLockFree(String bin) {
        return atomicSnapshot.get().getOrDefault(bin, "UNMATCHED");
    }

    // --- Isolate ONLY the allocation pattern, no config lookup involved ---
    private static final ConcurrentLinkedQueue<Ctx> pool = new ConcurrentLinkedQueue<>();

    static Ctx allocateFresh() {
        return new Ctx();
    }

    static Ctx allocatePooled() {
        Ctx c = pool.poll();
        return (c != null) ? c : new Ctx();
    }

    static void returnPooled(Ctx c) {
        c.reset();
        pool.offer(c);
    }

    public static void main(String[] args) throws InterruptedException {
        int warmup = 500_000;
        int n = 5_000_000;

        System.out.println("=== ISOLATED TEST A: config lookup ONLY - synchronized map vs AtomicReference snapshot ===");
        for (int i = 0; i < warmup; i++) { lookupSynchronized("453212"); lookupLockFree("453212"); }

        long t1 = System.nanoTime();
        for (int i = 0; i < n; i++) lookupSynchronized("453212");
        long syncMs = (System.nanoTime() - t1) / 1_000_000;

        long t2 = System.nanoTime();
        for (int i = 0; i < n; i++) lookupLockFree("453212");
        long lockFreeMs = (System.nanoTime() - t2) / 1_000_000;

        System.out.printf("Synchronized map lookup:  %,d ms for %,d calls (%.4f us/call)%n", syncMs, n, syncMs*1000.0/n);
        System.out.printf("AtomicReference snapshot: %,d ms for %,d calls (%.4f us/call)%n", lockFreeMs, n, lockFreeMs*1000.0/n);
        System.out.printf("Ratio (sync/lockfree): %.2fx%n", (double) syncMs / lockFreeMs);

        System.out.println();
        System.out.println("=== ISOLATED TEST B: object allocation ONLY - fresh 'new' vs pooled reuse ===");
        for (int i = 0; i < warmup; i++) { allocateFresh(); Ctx c = allocatePooled(); returnPooled(c); }

        long t3 = System.nanoTime();
        for (int i = 0; i < n; i++) { Ctx c = allocateFresh(); c.txnId = "x"; }
        long freshMs = (System.nanoTime() - t3) / 1_000_000;

        long t4 = System.nanoTime();
        for (int i = 0; i < n; i++) { Ctx c = allocatePooled(); c.txnId = "x"; returnPooled(c); }
        long pooledMs = (System.nanoTime() - t4) / 1_000_000;

        System.out.printf("Fresh allocation ('new'): %,d ms for %,d calls (%.4f us/call)%n", freshMs, n, freshMs*1000.0/n);
        System.out.printf("Pooled reuse:             %,d ms for %,d calls (%.4f us/call)%n", pooledMs, n, pooledMs*1000.0/n);
        System.out.printf("Ratio (fresh/pooled): %.2fx%n", (double) freshMs / pooledMs);

        System.out.println();
        System.out.println("=== TEST C: config lookup under REAL 8-thread contention - this is where it should matter ===");
        int threads = 8;
        int perThread = 1_000_000;

        long t5 = System.nanoTime();
        Thread[] ts1 = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            ts1[i] = new Thread(() -> { for (int j = 0; j < perThread; j++) lookupSynchronized("453212"); });
            ts1[i].start();
        }
        for (Thread t : ts1) t.join();
        long syncMtMs = (System.nanoTime() - t5) / 1_000_000;

        long t6 = System.nanoTime();
        Thread[] ts2 = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            ts2[i] = new Thread(() -> { for (int j = 0; j < perThread; j++) lookupLockFree("453212"); });
            ts2[i].start();
        }
        for (Thread t : ts2) t.join();
        long lockFreeMtMs = (System.nanoTime() - t6) / 1_000_000;

        System.out.printf("Synchronized (8 threads):  %,d ms total%n", syncMtMs);
        System.out.printf("Lock-free (8 threads):     %,d ms total%n", lockFreeMtMs);
        System.out.printf("Ratio under real contention: %.2fx%n", (double) syncMtMs / lockFreeMtMs);
    }
}
