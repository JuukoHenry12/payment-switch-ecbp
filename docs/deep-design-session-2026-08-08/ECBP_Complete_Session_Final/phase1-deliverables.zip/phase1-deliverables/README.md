# Phase 1 Deliverables — Architecture & Schema Decisions

These are the concrete artifacts from Phase 1 of the Unified Master Roadmap. Everything from Phase 2 onward builds on these decisions.

## What's here

```
ddl/ledger_shard_ddl.sql       - Apply to all 3 shard databases identically
router/ShardRouter.java         - Goes in common-dto, shared across services
schemas/*.avsc                  - Register each in Kafka Schema Registry
```

## 1. Apply the DDL to your 3 shards

```bash
# You already have these running from the Phase 0 installs:
psql -h localhost -p 5433 -U postgres -d postgres -f ddl/ledger_shard_ddl.sql   # shard 1
psql -h localhost -p 5434 -U postgres -d postgres -f ddl/ledger_shard_ddl.sql   # shard 2
psql -h localhost -p 5435 -U postgres -d postgres -f ddl/ledger_shard_ddl.sql   # shard 3
```

**Important honesty note:** I could not execute this DDL against a live database in my own environment — no SQL engine was available to me here. Treat your first real run against your actual Postgres containers as the genuine test, exactly like every other piece of code in this project. If it errors, paste the error back and we debug it the same way we've debugged everything else.

**Validate it worked:**
```sql
-- Run against any one shard
SELECT * FROM ACCOUNT;
SELECT * FROM TRANSACTION_HEADER;
SELECT * FROM TRANSACTION_ENTRY;
SELECT * FROM ACCOUNT_BALANCE_CACHE;

-- Run the balance verification query (should return ZERO rows)
SELECT TXN_ID, SUM(DEBIT_AMT) AS total_debit, SUM(CREDIT_AMT) AS total_credit
FROM TRANSACTION_ENTRY
GROUP BY TXN_ID
HAVING SUM(DEBIT_AMT) <> SUM(CREDIT_AMT);
```

## 2. Where ShardRouter.java goes

Place it at:
```
common-dto/src/main/java/com/balasubramani/ecbp/common/sharding/ShardRouter.java
```

It needs a Spring configuration bean supplying the 3 DataSources — that's Phase 3 work (building account-service), not something to wire up yet. For now it's just the routing logic, ready to be plugged in.

**How every future service will use it:**
```java
@Autowired
private ShardRouter shardRouter;

// Writing an account
DataSource ds = shardRouter.getDataSourceFor(accountId);

// Deciding local-transaction vs saga in payment-service
if (shardRouter.sameShardTransferPossible(fromAccountId, toAccountId)) {
    // simple local ACID transaction
} else {
    // saga orchestration with compensating transactions
}
```

## 3. Register the Avro schemas

```bash
for f in schemas/*.avsc; do
  subject=$(basename "$f" .avsc)
  curl -X POST http://localhost:8081/subjects/${subject}-value/versions \
    -H "Content-Type: application/vnd.schemaregistry.v1+json" \
    -d "{\"schema\": $(python3 -c "import json; print(json.dumps(open('$f').read()))")}"
done
```

**Validate registration:**
```bash
curl http://localhost:8081/subjects
# Should list all 5 schemas
```

## The 5 events and what they mean for later phases

| Event | Published by | Consumed by (later phases) |
|---|---|---|
| `PaymentInitiated` | payment-service | risk-service (fraud scoring begins), audit-service |
| `EntryPosted` | account-service | **CQRS read-model builder (Phase 11) — this is its primary input** |
| `PaymentSettled` | payment-service | notification-service, audit-service, CQRS |
| `PaymentFailed` | payment-service | notification-service, audit-service |
| `FraudFlagged` | risk-service | audit-service, notification-service, api-gateway (for blocking) |

Notice `FraudFlagged` already has a `detectionMethod` field distinguishing `RULE_ENGINE` from `ML_ANOMALY` — this is exactly why Phase 5 (rules + ML built together) works cleanly: the event contract already treats them as two detection methods feeding one unified event, not two separate systems bolted together later.

## What this unlocks for Phase 2 onward

- **Phase 2 (Foundation)**: service skeletons can now declare their Kafka producers/consumers against real, registered schemas from day one
- **Phase 3 (account-service)**: builds directly against `ledger_shard_ddl.sql` — no guessing at schema, no later migration
- **Phase 4 (payment-service)**: the saga-vs-local-transaction decision is a single `ShardRouter` method call, not ad-hoc logic
- **Phase 11 (CQRS)**: already has its event contract fully defined — that phase becomes pure implementation against a stable spec

## Next step

Once you've applied the DDL and registered the schemas, you're genuinely ready for Phase 2 (Foundation) — Config Server, Eureka, service skeletons, with Istio wired in from the start.
