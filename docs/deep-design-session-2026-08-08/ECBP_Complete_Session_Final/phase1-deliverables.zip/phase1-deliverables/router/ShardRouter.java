package com.balasubramani.ecbp.common.sharding;

import org.springframework.stereotype.Component;
import javax.sql.DataSource;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

/**
 * ShardRouter — determines which physical database shard an account
 * lives on, and provides the correct DataSource for it.
 *
 * Design decisions, stated explicitly:
 *   1. Hash-based (not range-based) partitioning. A range-based scheme
 *      (accounts 0000000-3333333 -> shard 1, etc.) is simpler to reason
 *      about but creates hot spots when account creation isn't uniform
 *      (e.g. sequential account numbering means all NEW accounts land
 *      on the same shard). Hashing the account ID distributes load
 *      evenly regardless of ID allocation pattern.
 *   2. SHA-256 truncated to a fixed number of bits, modulo shard count.
 *      This is deterministic (same account ID always routes to the
 *      same shard) and stable even if shard count needs to grow later
 *      via a resharding process (out of scope for this phase, but the
 *      hash-based design is what makes resharding tractable at all —
 *      range-based schemes require full data reshuffling on resize,
 *      hash-based schemes support consistent-hashing techniques that
 *      minimize data movement).
 *   3. The SHARD_KEY column on ACCOUNT (see ledger_shard_ddl.sql) is a
 *      denormalized cache of this routing decision, written once at
 *      account creation time, so subsequent lookups don't need to
 *      recompute the hash on every single query — read it directly.
 */
@Component
public class ShardRouter {

    private static final int SHARD_COUNT = 3;

    private final Map<Integer, DataSource> shardDataSources;

    public ShardRouter(Map<Integer, DataSource> shardDataSources) {
        if (shardDataSources.size() != SHARD_COUNT) {
            throw new IllegalArgumentException(
                "Expected " + SHARD_COUNT + " shard DataSources, got " + shardDataSources.size());
        }
        this.shardDataSources = shardDataSources;
    }

    /**
     * Compute which shard index (0, 1, or 2) an account ID belongs to.
     * This is a pure function — same input always produces same output,
     * which is exactly the property a sharding scheme requires.
     */
    public int computeShardIndex(String accountId) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(accountId.getBytes(StandardCharsets.UTF_8));

            // Take the first 4 bytes of the hash as an unsigned integer,
            // then modulo by shard count. Using only part of the hash is
            // fine here — SHA-256's output is uniformly distributed, so
            // any contiguous slice is also effectively uniform.
            int hashInt = ((hashBytes[0] & 0xFF) << 24)
                        | ((hashBytes[1] & 0xFF) << 16)
                        | ((hashBytes[2] & 0xFF) << 8)
                        | (hashBytes[3] & 0xFF);

            // Mask off the sign bit before modulo, since Java ints are
            // signed and a negative value would give a negative or
            // unexpected result from %.
            return (hashInt & 0x7FFFFFFF) % SHARD_COUNT;

        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is guaranteed available on every standard JVM;
            // this branch is unreachable in practice, but Java requires
            // handling the checked exception.
            throw new IllegalStateException("SHA-256 not available on this JVM", e);
        }
    }

    /**
     * Get the actual DataSource to use for queries against this account.
     */
    public DataSource getDataSourceFor(String accountId) {
        int shardIndex = computeShardIndex(accountId);
        DataSource ds = shardDataSources.get(shardIndex);
        if (ds == null) {
            throw new IllegalStateException("No DataSource configured for shard " + shardIndex);
        }
        return ds;
    }

    /**
     * Determine whether two accounts live on the same shard.
     * This is the single most important check in payment-service's
     * saga orchestration: if true, a normal local ACID transaction
     * suffices. If false, the saga pattern with compensating
     * transactions MUST be used instead — a local transaction can
     * never span two separate physical databases.
     */
    public boolean sameShardTransferPossible(String fromAccountId, String toAccountId) {
        return computeShardIndex(fromAccountId) == computeShardIndex(toAccountId);
    }

    /**
     * Return every shard's DataSource — used only by cross-shard
     * operations (e.g. an admin report that must query all shards
     * and merge results) and by the CQRS read-model builder, which
     * legitimately needs to read from every shard to build a unified
     * denormalized view. Regular request-path code should never call
     * this — it should always route through getDataSourceFor().
     */
    public List<DataSource> getAllShardDataSources() {
        return shardDataSources.values().stream().toList();
    }
}
