-- ============================================================
-- ECBP Sharded Double-Entry Ledger — Shard DDL
-- Apply this IDENTICAL schema to all 3 shard databases
-- (postgres-shard1, postgres-shard2, postgres-shard3)
-- ============================================================
-- Design decisions, stated explicitly:
--   1. Balance is NEVER stored directly on ACCOUNT — it is always
--      derived from TRANSACTION_ENTRY, and cached separately.
--      This is the core double-entry principle: the ledger is the
--      single source of truth, never a mutable balance field.
--   2. ACCOUNT uses system-period temporal versioning (bi-temporal
--      history) so "what did this account look like at time T" is
--      always answerable — a real regulatory requirement.
--   3. TRANSACTION_ENTRY is append-only. Nothing is ever UPDATEd
--      or DELETEd after insert. Corrections are reversing entries.
-- ============================================================

-- ------------------------------------------------------------
-- ACCOUNT (system-versioned / temporal)
-- ------------------------------------------------------------
CREATE TABLE ACCOUNT (
    ACCOUNT_ID          VARCHAR(20)     NOT NULL,
    HOLDER_NAME         VARCHAR(100)    NOT NULL,
    ACCOUNT_TYPE        VARCHAR(20)     NOT NULL,   -- SAVINGS, CHECKING, LOAN_LINKED
    STATUS              VARCHAR(20)     NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, FROZEN, CLOSED
    DAILY_LIMIT         DECIMAL(15,2)   NOT NULL DEFAULT 5000.00,
    SHARD_KEY           SMALLINT        NOT NULL,   -- which logical shard this account belongs to (0,1,2)
    CREATED_AT          TIMESTAMPTZ     NOT NULL DEFAULT now(),

    -- System-period temporal columns (bi-temporal history)
    SYS_START           TIMESTAMPTZ     NOT NULL DEFAULT now(),
    SYS_END             TIMESTAMPTZ     NOT NULL DEFAULT 'infinity',

    PRIMARY KEY (ACCOUNT_ID, SYS_START)
);

-- Fast lookup of the CURRENT version of an account
CREATE INDEX IDX_ACCOUNT_CURRENT
    ON ACCOUNT (ACCOUNT_ID)
    WHERE SYS_END = 'infinity';

-- History table holding closed-out (superseded) versions.
-- On every UPDATE to an account's mutable attributes, the
-- application layer must: (1) close the current row by setting
-- SYS_END = now(), (2) insert a new row with the new values and
-- SYS_START = now(). This is enforced in the service layer, not
-- a database trigger, to keep the write path simple and fast.

-- ------------------------------------------------------------
-- TRANSACTION_HEADER — one row per logical transaction
-- ------------------------------------------------------------
CREATE TABLE TRANSACTION_HEADER (
    TXN_ID              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_TYPE            VARCHAR(20)     NOT NULL,   -- TRANSFER, DEPOSIT, WITHDRAWAL, REVERSAL, FEE
    STATUS              VARCHAR(20)     NOT NULL,   -- PENDING, SETTLED, FAILED, REVERSED
    IDEMPOTENCY_KEY      VARCHAR(64)     NOT NULL,
    REFERENCE_TXN_ID     UUID            NULL,       -- set when this txn reverses another
    CREATED_AT           TIMESTAMPTZ     NOT NULL DEFAULT now(),
    SETTLED_AT           TIMESTAMPTZ     NULL,

    CONSTRAINT UQ_IDEMPOTENCY_KEY UNIQUE (IDEMPOTENCY_KEY)
);

CREATE INDEX IDX_TXN_HEADER_CREATED ON TRANSACTION_HEADER (CREATED_AT);
CREATE INDEX IDX_TXN_HEADER_STATUS  ON TRANSACTION_HEADER (STATUS);

-- ------------------------------------------------------------
-- TRANSACTION_ENTRY — the actual double-entry ledger rows.
-- Every TRANSACTION_HEADER has 2+ balanced ENTRY rows:
-- sum(DEBIT_AMT) for the txn must equal sum(CREDIT_AMT).
-- APPEND-ONLY. Never UPDATE or DELETE a posted entry.
-- ------------------------------------------------------------
CREATE TABLE TRANSACTION_ENTRY (
    ENTRY_ID            UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_ID               UUID            NOT NULL REFERENCES TRANSACTION_HEADER(TXN_ID),
    ACCOUNT_ID            VARCHAR(20)     NOT NULL,
    DEBIT_AMT             DECIMAL(15,2)   NOT NULL DEFAULT 0.00,
    CREDIT_AMT            DECIMAL(15,2)   NOT NULL DEFAULT 0.00,
    ENTRY_SEQUENCE        SMALLINT        NOT NULL,  -- ordering within the txn (1, 2, 3...)
    CREATED_AT            TIMESTAMPTZ     NOT NULL DEFAULT now(),

    CONSTRAINT CHK_ONE_SIDED CHECK (
        (DEBIT_AMT > 0 AND CREDIT_AMT = 0) OR
        (CREDIT_AMT > 0 AND DEBIT_AMT = 0)
    )
);

CREATE INDEX IDX_ENTRY_ACCOUNT_CREATED
    ON TRANSACTION_ENTRY (ACCOUNT_ID, CREATED_AT DESC);
CREATE INDEX IDX_ENTRY_TXN
    ON TRANSACTION_ENTRY (TXN_ID);

-- ------------------------------------------------------------
-- ACCOUNT_BALANCE_CACHE — the ONLY place a "balance" number
-- physically lives. This is a derived, rebuildable cache, never
-- the source of truth. Updated transactionally alongside each
-- TRANSACTION_ENTRY insert (same DB transaction), and mirrored
-- into Redis for sub-millisecond reads outside the DB entirely.
-- ------------------------------------------------------------
CREATE TABLE ACCOUNT_BALANCE_CACHE (
    ACCOUNT_ID           VARCHAR(20)     PRIMARY KEY,
    CURRENT_BALANCE       DECIMAL(15,2)   NOT NULL DEFAULT 0.00,
    LAST_ENTRY_ID          UUID            NULL,
    UPDATED_AT             TIMESTAMPTZ     NOT NULL DEFAULT now(),
    VERSION                BIGINT          NOT NULL DEFAULT 0   -- optimistic concurrency
);

-- ------------------------------------------------------------
-- Verification query — run this anytime to prove the ledger is
-- balanced (should ALWAYS return zero rows; if it returns rows,
-- something is seriously wrong with a transaction's entries)
-- ------------------------------------------------------------
-- SELECT TXN_ID, SUM(DEBIT_AMT) AS total_debit, SUM(CREDIT_AMT) AS total_credit
-- FROM TRANSACTION_ENTRY
-- GROUP BY TXN_ID
-- HAVING SUM(DEBIT_AMT) <> SUM(CREDIT_AMT);

-- ------------------------------------------------------------
-- Sample data — 2 accounts, one balanced transfer between them
-- ------------------------------------------------------------
INSERT INTO ACCOUNT (ACCOUNT_ID, HOLDER_NAME, ACCOUNT_TYPE, SHARD_KEY)
VALUES
    ('ACC0001234', 'BALASUBRAMANI', 'SAVINGS', 0),
    ('ACC0005678', 'SUKANYA', 'SAVINGS', 0);

INSERT INTO ACCOUNT_BALANCE_CACHE (ACCOUNT_ID, CURRENT_BALANCE)
VALUES
    ('ACC0001234', 50000.00),
    ('ACC0005678', 75000.50);

-- A transfer of 1000.00 from ACC0001234 to ACC0005678
DO $$
DECLARE
    v_txn_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO TRANSACTION_HEADER (TXN_ID, TXN_TYPE, STATUS, IDEMPOTENCY_KEY, SETTLED_AT)
    VALUES (v_txn_id, 'TRANSFER', 'SETTLED', 'demo-idem-key-001', now());

    INSERT INTO TRANSACTION_ENTRY (TXN_ID, ACCOUNT_ID, DEBIT_AMT, CREDIT_AMT, ENTRY_SEQUENCE)
    VALUES (v_txn_id, 'ACC0001234', 1000.00, 0.00, 1);

    INSERT INTO TRANSACTION_ENTRY (TXN_ID, ACCOUNT_ID, DEBIT_AMT, CREDIT_AMT, ENTRY_SEQUENCE)
    VALUES (v_txn_id, 'ACC0005678', 0.00, 1000.00, 2);

    UPDATE ACCOUNT_BALANCE_CACHE SET CURRENT_BALANCE = CURRENT_BALANCE - 1000.00, VERSION = VERSION + 1
        WHERE ACCOUNT_ID = 'ACC0001234';
    UPDATE ACCOUNT_BALANCE_CACHE SET CURRENT_BALANCE = CURRENT_BALANCE + 1000.00, VERSION = VERSION + 1
        WHERE ACCOUNT_ID = 'ACC0005678';
END $$;
