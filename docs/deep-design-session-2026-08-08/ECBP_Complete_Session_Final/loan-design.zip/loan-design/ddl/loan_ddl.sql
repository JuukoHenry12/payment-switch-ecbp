-- ============================================================
-- ECBP Loan Service — DDL
-- ============================================================
-- DECIMAL throughout, never floating point - the exact same
-- discipline as the very first ledger DDL this morning, and for the
-- exact same reason: amortization math is genuinely one of the most
-- common places rounding errors silently accumulate in real banking
-- software, and this domain is specifically tested for that below.
-- ============================================================

CREATE TABLE LOAN_ACCOUNT (
    LOAN_ID                VARCHAR(20)     PRIMARY KEY,
    ACCOUNT_ID                VARCHAR(20)  NOT NULL,   -- the linked deposit account, per Phase 1's schema
    PRINCIPAL_AMOUNT             DECIMAL(15,2) NOT NULL,
    ANNUAL_INTEREST_RATE            DECIMAL(6,4) NOT NULL,  -- e.g. 0.0450 = 4.50%
    TERM_MONTHS                        SMALLINT  NOT NULL,
    STATUS                                VARCHAR(20) NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, PAID_OFF, DEFAULTED
    ORIGINATED_AT                          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE AMORTIZATION_SCHEDULE_ENTRY (
    LOAN_ID                  VARCHAR(20)   NOT NULL REFERENCES LOAN_ACCOUNT(LOAN_ID),
    PAYMENT_NUMBER              SMALLINT   NOT NULL,
    PAYMENT_AMOUNT                 DECIMAL(15,2) NOT NULL,
    PRINCIPAL_PORTION                 DECIMAL(15,2) NOT NULL,
    INTEREST_PORTION                     DECIMAL(15,2) NOT NULL,
    REMAINING_BALANCE                       DECIMAL(15,2) NOT NULL,

    PRIMARY KEY (LOAN_ID, PAYMENT_NUMBER)
);

-- The invariant this schema exists to make checkable at any time:
-- SELECT LOAN_ID, SUM(PRINCIPAL_PORTION) FROM AMORTIZATION_SCHEDULE_ENTRY
-- GROUP BY LOAN_ID
-- -- must EXACTLY equal LOAN_ACCOUNT.PRINCIPAL_AMOUNT for every loan,
-- -- to the cent, with zero tolerance - this is precisely the
-- -- invariant the test suite below checks directly in code.
