# Loan Amortization Service — Design Package

## What's different about this package, worth stating honestly

Every other package today found and fixed a real bug during testing. This one didn't — the implementation passed all 6 tests, including the exact-sum invariant, on the first run. Worth being just as honest about that as about the bugs: not manufacturing a false narrative either way is part of the same discipline that's made the bug-finding earlier today credible in the first place.

## The invariant this specifically defends against — the classic real bug in this domain

Amortization schedules are one of the most common places rounding errors silently compound in real banking software: calculate each month's principal portion independently, and by the final payment, the sum across the whole schedule can drift a cent or two away from the actual original loan amount — small, easy to miss, and genuinely wrong.

**The fix that prevents this, built in from the start**: the final payment's principal portion is never independently recalculated. It's explicitly set to whatever the remaining balance actually is at that point, absorbing any rounding drift from every prior month in one place. This is the standard, correct real-world approach — and Test 2/3 verify it actually holds, not just that the code looks like it should.

## Files

```
ddl/loan_ddl.sql                  - LOAN_ACCOUNT, AMORTIZATION_SCHEDULE_ENTRY
service/loan_amortization.py      - tested against 6 scenarios, all passing
```

## Verified, working — 6 real scenarios

1. **Full 60-month schedule** for a $25,000 loan at 6.5% — correct monthly payment, correct final balance of exactly $0.00
2. **The critical invariant** — sum of all 60 principal portions exactly equals $25,000.00, to the cent, zero tolerance
3. **Final payment absorption** — explicitly confirmed the last payment's principal portion is whatever remained, not an independently recalculated value
4. **Zero-interest edge case** — a $12,000 interest-free loan still sums exactly correctly (the formula correctly branches to simple division rather than dividing by zero in the standard amortization formula)
5. **Prepayment** — a $5,000 extra principal payment after month 12 genuinely shortens a 60-month loan to 48 months, not just truncating rows
6. **Prepayment invariant** — the shortened schedule's principal sum, plus the prepayment itself, still exactly equals the original $25,000

## How this connects to everything built today

Same `DECIMAL`-only discipline as the very first ledger DDL this morning — no floating point anywhere in the calculation, for exactly the same reason: currency math that silently loses or gains fractions of a cent is a genuine, unacceptable defect class in a financial system, not a rounding nuance to shrug off.

The eventual `TRANSACTION_HEADER`/`TRANSACTION_ENTRY` postings for each loan repayment would flow through the same double-entry ledger from Phase 1 — this package's job was proving the *math* is correct before it ever touches the ledger, not re-implementing ledger posting itself.
