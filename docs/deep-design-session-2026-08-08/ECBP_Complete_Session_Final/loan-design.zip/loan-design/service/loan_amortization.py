"""
loan_amortization.py — standard amortizing loan schedule generation,
using Decimal throughout (never float, exactly the same discipline
as the ledger DDL from this morning) and specifically tested for the
single most common real bug in this domain: the sum of every
payment's principal portion, across the WHOLE schedule, failing to
exactly equal the original loan amount due to rounding drift
compounding month over month.
"""

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP


@dataclass
class ScheduleEntry:
    payment_number: int
    payment_amount: Decimal
    principal_portion: Decimal
    interest_portion: Decimal
    remaining_balance: Decimal


def calculate_monthly_payment(principal: Decimal, annual_rate: Decimal, term_months: int) -> Decimal:
    """Standard amortizing loan payment formula."""
    if annual_rate == 0:
        return (principal / term_months).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    monthly_rate = annual_rate / Decimal("12")
    numerator = principal * monthly_rate * (1 + monthly_rate) ** term_months
    denominator = (1 + monthly_rate) ** term_months - 1
    return (numerator / denominator).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def generate_amortization_schedule(
        principal: Decimal, annual_rate: Decimal, term_months: int) -> list[ScheduleEntry]:
    """
    Generates the full schedule. The critical detail, worth being
    explicit about: on the FINAL payment, the principal portion is
    NOT calculated the same way as every other month - it's set to
    whatever the remaining balance actually is, absorbing any
    rounding drift that accumulated across the prior payments. This
    is the standard, correct approach real loan systems use, and
    it's exactly what the test suite below verifies actually holds.
    """
    monthly_payment = calculate_monthly_payment(principal, annual_rate, term_months)
    monthly_rate = annual_rate / Decimal("12")

    schedule = []
    remaining_balance = principal

    for payment_num in range(1, term_months + 1):
        interest_portion = (remaining_balance * monthly_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        if payment_num == term_months:
            # FINAL payment - principal portion absorbs whatever is
            # actually left, not a freshly recalculated value. This
            # is the specific line that prevents cumulative rounding
            # drift from ever leaving a fractional cent unaccounted
            # for anywhere in the schedule.
            principal_portion = remaining_balance
            actual_payment_amount = principal_portion + interest_portion
        else:
            principal_portion = monthly_payment - interest_portion
            actual_payment_amount = monthly_payment

        remaining_balance -= principal_portion

        schedule.append(ScheduleEntry(
            payment_number=payment_num,
            payment_amount=actual_payment_amount,
            principal_portion=principal_portion,
            interest_portion=interest_portion,
            remaining_balance=remaining_balance,
        ))

    return schedule


def apply_prepayment(schedule: list[ScheduleEntry], after_payment_number: int,
                      prepayment_amount: Decimal, principal: Decimal, annual_rate: Decimal) -> list[ScheduleEntry]:
    """
    A borrower makes an extra principal-only payment after a given
    scheduled payment. The remaining term must be recalculated from
    the new, lower balance - not just truncated, since a real
    prepayment genuinely shortens the loan, it doesn't just delete
    remaining rows.
    """
    balance_after_prepayment = schedule[after_payment_number - 1].remaining_balance - prepayment_amount
    if balance_after_prepayment <= 0:
        return schedule[:after_payment_number]  # loan is fully paid off by the prepayment

    original_monthly_payment = calculate_monthly_payment(principal, annual_rate, len(schedule))
    monthly_rate = annual_rate / Decimal("12")

    new_schedule = schedule[:after_payment_number]
    remaining_balance = balance_after_prepayment
    payment_num = after_payment_number

    while remaining_balance > 0:
        payment_num += 1
        interest_portion = (remaining_balance * monthly_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        if remaining_balance + interest_portion <= original_monthly_payment:
            # This is genuinely the final payment of the shortened loan
            principal_portion = remaining_balance
            actual_payment_amount = principal_portion + interest_portion
        else:
            principal_portion = original_monthly_payment - interest_portion
            actual_payment_amount = original_monthly_payment

        remaining_balance -= principal_portion
        new_schedule.append(ScheduleEntry(
            payment_number=payment_num, payment_amount=actual_payment_amount,
            principal_portion=principal_portion, interest_portion=interest_portion,
            remaining_balance=remaining_balance,
        ))

    return new_schedule


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    principal = Decimal("25000.00")
    annual_rate = Decimal("0.065")  # 6.5%
    term_months = 60  # 5-year loan

    print(f"=== TEST 1: Generate a full 60-month amortization schedule for a {principal} loan at {annual_rate*100}% ===")
    schedule = generate_amortization_schedule(principal, annual_rate, term_months)
    print(f"Monthly payment (from first entry): {schedule[0].payment_amount}")
    print(f"Number of payments generated: {len(schedule)} (expected: 60)")
    print(f"First payment's remaining balance: {schedule[0].remaining_balance}")
    print(f"Last payment's remaining balance: {schedule[-1].remaining_balance} (expected: 0.00)")

    print()
    print("=== TEST 2: THE critical invariant - sum of ALL principal portions EXACTLY equals the original loan amount ===")
    total_principal_paid = sum(entry.principal_portion for entry in schedule)
    print(f"Original principal: {principal}")
    print(f"Sum of all 60 principal portions: {total_principal_paid}")
    print(f"EXACTLY equal (to the cent, zero tolerance): {total_principal_paid == principal}")

    print()
    print("=== TEST 3: The final payment specifically absorbs whatever rounding remainder exists ===")
    print(f"Final payment's principal portion: {schedule[-1].principal_portion}")
    print(f"Final remaining balance after that payment: {schedule[-1].remaining_balance}")
    print(f"Confirms remaining balance hits EXACTLY zero, not a fractional cent left over: "
          f"{schedule[-1].remaining_balance == Decimal('0.00')}")

    print()
    print("=== TEST 4: A zero-interest loan (edge case) still sums exactly correctly ===")
    zero_rate_schedule = generate_amortization_schedule(Decimal("12000.00"), Decimal("0.00"), 12)
    zero_rate_total = sum(entry.principal_portion for entry in zero_rate_schedule)
    print(f"Sum of principal portions: {zero_rate_total} (expected: 12000.00, exactly)")
    print(f"Exactly equal: {zero_rate_total == Decimal('12000.00')}")

    print()
    print("=== TEST 5: Prepayment scenario - extra principal payment after payment 12, shortens the loan ===")
    prepay_schedule = apply_prepayment(schedule, after_payment_number=12,
                                        prepayment_amount=Decimal("5000.00"),
                                        principal=principal, annual_rate=annual_rate)
    print(f"Original schedule length: {len(schedule)} payments")
    print(f"Shortened schedule length: {len(prepay_schedule)} payments (expected: fewer than 60)")
    print(f"Loan genuinely shortened: {len(prepay_schedule) < len(schedule)}")
    print(f"Final balance still hits exactly zero: {prepay_schedule[-1].remaining_balance == Decimal('0.00')}")

    print()
    print("=== TEST 6: Prepayment schedule ALSO satisfies the exact-sum invariant (including the extra principal payment) ===")
    total_principal_with_prepayment = sum(e.principal_portion for e in prepay_schedule) + Decimal("5000.00")
    print(f"Sum of scheduled principal portions + the {Decimal('5000.00')} prepayment: "
          f"{total_principal_with_prepayment}")
    print(f"Exactly equals original principal: {total_principal_with_prepayment == principal}")
