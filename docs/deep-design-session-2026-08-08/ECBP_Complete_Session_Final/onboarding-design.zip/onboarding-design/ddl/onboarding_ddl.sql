-- ============================================================
-- ECBP Customer Onboarding Workflow — DDL
-- ============================================================
-- The orchestration layer that was missing: KYC screening
-- (kyc-aml-design), account creation (Phase 1), and card issuance
-- (card-issuance-design) all exist as independent capabilities, but
-- nothing sequences them into one real "open a new account" journey
-- with a genuine state machine an operations team can monitor.
-- ============================================================

CREATE TABLE ONBOARDING_APPLICATION (
    APPLICATION_ID             UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    APPLICANT_NAME                 VARCHAR(200) NOT NULL,
    STATUS                            VARCHAR(30) NOT NULL,  -- see the state machine in onboarding_workflow.py
    ACCOUNT_ID                           VARCHAR(20) NULL,   -- populated once an account is actually created
    REJECTION_REASON                        VARCHAR(100) NULL,
    STARTED_AT                                 TIMESTAMPTZ NOT NULL DEFAULT now(),
    COMPLETED_AT                                 TIMESTAMPTZ NULL
);

CREATE TABLE ONBOARDING_STEP_LOG (
    STEP_LOG_ID                UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    APPLICATION_ID                 UUID       NOT NULL REFERENCES ONBOARDING_APPLICATION(APPLICATION_ID),
    STEP_NAME                          VARCHAR(50) NOT NULL,
    OUTCOME                               VARCHAR(20) NOT NULL,  -- PASSED, FAILED
    DETAIL                                   TEXT       NULL,
    OCCURRED_AT                                TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_ONBOARDING_APP_STEPS ON ONBOARDING_STEP_LOG (APPLICATION_ID, OCCURRED_AT);
-- Same "one query, complete story" principle as journal-design -
-- an operations team reviewing a rejected application gets the full
-- sequence of what happened, in order, from one query.
