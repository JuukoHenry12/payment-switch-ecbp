"""
onboarding_workflow.py — the orchestration layer sequencing three
capabilities already built today (sanctions/PEP screening from
kyc-aml-design, account creation, card issuance) into one real
"open a new account" journey with a genuine state machine.

Deliberately reuses the saga orchestrator's core lesson from earlier
today: if ANY step fails, the workflow must stop cleanly at a known,
correctly-labeled state - never leave a half-created account with no
card, and never silently continue past a sanctions hit.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class ApplicationStatus(Enum):
    STARTED = "STARTED"
    SCREENING = "SCREENING"
    SCREENING_REJECTED = "SCREENING_REJECTED"
    SCREENING_MANUAL_REVIEW = "SCREENING_MANUAL_REVIEW"
    ACCOUNT_CREATED = "ACCOUNT_CREATED"
    CARD_ISSUED = "CARD_ISSUED"
    COMPLETED = "COMPLETED"


@dataclass
class OnboardingApplication:
    application_id: str
    applicant_name: str
    status: ApplicationStatus
    account_id: str | None = None
    rejection_reason: str | None = None
    step_log: list[dict] = field(default_factory=list)


class OnboardingWorkflow:

    def __init__(self, screening_fn, account_creation_fn, card_issuance_fn):
        """All three real capabilities injected, reusing exactly what
        was already built and tested today rather than reimplementing
        any of them - screening_fn wraps kyc-aml-design's
        SanctionsScreeningEngine, account_creation_fn wraps Phase 1's
        ledger, card_issuance_fn wraps card-issuance-design."""
        self.screening_fn = screening_fn
        self.account_creation_fn = account_creation_fn
        self.card_issuance_fn = card_issuance_fn
        self.applications: dict[str, OnboardingApplication] = {}

    def _log_step(self, app: OnboardingApplication, step_name: str, outcome: str, detail: str = ""):
        app.step_log.append({"step": step_name, "outcome": outcome, "detail": detail,
                              "at": datetime.now()})

    def start_application(self, application_id: str, applicant_name: str) -> OnboardingApplication:
        app = OnboardingApplication(application_id, applicant_name, ApplicationStatus.STARTED)
        self.applications[application_id] = app
        self._log_step(app, "APPLICATION_STARTED", "PASSED")
        return app

    def run(self, application_id: str) -> OnboardingApplication:
        app = self.applications[application_id]

        # STEP 1: sanctions/PEP screening - reuses kyc-aml-design's
        # exact CONFIRMED_MATCH / POTENTIAL_MATCH / CLEAR outcomes.
        app.status = ApplicationStatus.SCREENING
        screening_result = self.screening_fn(app.applicant_name)

        if screening_result == "CONFIRMED_MATCH":
            app.status = ApplicationStatus.SCREENING_REJECTED
            app.rejection_reason = "Confirmed sanctions/PEP match"
            self._log_step(app, "SANCTIONS_SCREENING", "FAILED", "CONFIRMED_MATCH")
            return app  # STOPS HERE - never proceeds to account creation

        if screening_result == "POTENTIAL_MATCH":
            app.status = ApplicationStatus.SCREENING_MANUAL_REVIEW
            self._log_step(app, "SANCTIONS_SCREENING", "FAILED", "POTENTIAL_MATCH - held for human review")
            return app  # ALSO stops here - a potential match is never auto-approved

        self._log_step(app, "SANCTIONS_SCREENING", "PASSED", "CLEAR")

        # STEP 2: account creation - only reached if screening genuinely cleared.
        account_result = self.account_creation_fn(app.applicant_name)
        if not account_result["success"]:
            app.status = ApplicationStatus.SCREENING_REJECTED  # reuse as generic "did not complete"
            app.rejection_reason = account_result.get("reason", "Account creation failed")
            self._log_step(app, "ACCOUNT_CREATION", "FAILED", app.rejection_reason)
            return app

        app.account_id = account_result["account_id"]
        app.status = ApplicationStatus.ACCOUNT_CREATED
        self._log_step(app, "ACCOUNT_CREATION", "PASSED", app.account_id)

        # STEP 3: card issuance - only reached if the account genuinely exists.
        card_result = self.card_issuance_fn(app.account_id)
        if not card_result["success"]:
            # Deliberately NOT rolled back to REJECTED - the account
            # is real and usable even if card issuance needs a retry;
            # this mirrors the honest lesson from the saga package:
            # a partial failure should leave the system in a KNOWN,
            # correctly labeled state, not silently pretend to be
            # further along than it actually is, and not discard
            # real, already-completed work.
            self._log_step(app, "CARD_ISSUANCE", "FAILED", card_result.get("reason", "unknown"))
            return app  # stays at ACCOUNT_CREATED - accurate, not COMPLETED

        app.status = ApplicationStatus.CARD_ISSUED
        self._log_step(app, "CARD_ISSUANCE", "PASSED", card_result["card_id"])

        app.status = ApplicationStatus.COMPLETED
        self._log_step(app, "ONBOARDING_COMPLETED", "PASSED")
        return app


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    print("=== TEST 1: Full happy path - screening clears, account created, card issued ===")
    workflow1 = OnboardingWorkflow(
        screening_fn=lambda name: "CLEAR",
        account_creation_fn=lambda name: {"success": True, "account_id": "ACC-NEW-001"},
        card_issuance_fn=lambda acc_id: {"success": True, "card_id": "CARD-NEW-001"},
    )
    app1 = workflow1.start_application("APP-001", "Sarah Jennifer Thompson")
    result1 = workflow1.run("APP-001")
    print(f"Final status: {result1.status.value} (expected: COMPLETED)")
    print(f"Account ID assigned: {result1.account_id}")

    print()
    print("=== TEST 2: Sanctions CONFIRMED_MATCH - stops immediately, never reaches account creation ===")
    account_creation_calls = []
    workflow2 = OnboardingWorkflow(
        screening_fn=lambda name: "CONFIRMED_MATCH",
        account_creation_fn=lambda name: account_creation_calls.append(name) or {"success": True, "account_id": "SHOULD-NOT-EXIST"},
        card_issuance_fn=lambda acc_id: {"success": True, "card_id": "SHOULD-NOT-EXIST"},
    )
    workflow2.start_application("APP-002", "Suspicious Applicant")
    result2 = workflow2.run("APP-002")
    print(f"Final status: {result2.status.value} (expected: SCREENING_REJECTED)")
    print(f"Account creation was NEVER called: {len(account_creation_calls) == 0} (expected: True)")

    print()
    print("=== TEST 3: POTENTIAL_MATCH - held for human review, NOT auto-rejected, NOT auto-approved ===")
    workflow3 = OnboardingWorkflow(
        screening_fn=lambda name: "POTENTIAL_MATCH",
        account_creation_fn=lambda name: {"success": True, "account_id": "SHOULD-NOT-EXIST"},
        card_issuance_fn=lambda acc_id: {"success": True, "card_id": "SHOULD-NOT-EXIST"},
    )
    workflow3.start_application("APP-003", "Ambiguous Name Match")
    result3 = workflow3.run("APP-003")
    print(f"Final status: {result3.status.value} (expected: SCREENING_MANUAL_REVIEW - "
          f"neither auto-approved nor auto-rejected)")

    print()
    print("=== TEST 4: Card issuance fails AFTER account was genuinely created - account is NOT discarded ===")
    workflow4 = OnboardingWorkflow(
        screening_fn=lambda name: "CLEAR",
        account_creation_fn=lambda name: {"success": True, "account_id": "ACC-NEW-004"},
        card_issuance_fn=lambda acc_id: {"success": False, "reason": "Card printer service unavailable"},
    )
    workflow4.start_application("APP-004", "Real Customer")
    result4 = workflow4.run("APP-004")
    print(f"Final status: {result4.status.value} (expected: ACCOUNT_CREATED - accurately reflects reality, "
          f"not COMPLETED and not thrown away)")
    print(f"Account ID still assigned and usable: {result4.account_id is not None} (expected: True)")

    print()
    print("=== TEST 5: Complete step-by-step log exists for a rejected application - operations can see exactly why ===")
    for step in result2.step_log:
        print(f"  [{step['outcome']}] {step['step']}: {step['detail']}")
