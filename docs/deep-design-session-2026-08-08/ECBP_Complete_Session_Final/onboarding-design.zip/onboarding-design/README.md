# Customer Onboarding Workflow — Design Package

## What this closes

Three real capabilities already existed independently — sanctions/PEP screening (kyc-aml-design), account creation (Phase 1), card issuance (card-issuance-design) — but nothing sequenced them into one real "open a new account" journey. This is that orchestration layer.

## Files

```
ddl/onboarding_ddl.sql              - ONBOARDING_APPLICATION, ONBOARDING_STEP_LOG
service/onboarding_workflow.py      - tested against 5 real scenarios
```

## Verified, working — 5 real scenarios

1. **Full happy path** — screening clears, account created, card issued, all three steps genuinely sequenced
2. **A confirmed sanctions match stops the workflow immediately** — proven by checking account creation was *never even called*, not just that the final status looks right
3. **A potential match is held for human review** — neither auto-approved nor auto-rejected, the correct, conservative real-world behavior for an ambiguous screening result
4. **The honest partial-failure case** — card issuance fails after the account was genuinely created. The workflow correctly stays at `ACCOUNT_CREATED`, not falsely `COMPLETED`, and the real account is never discarded just because a downstream step needs a retry
5. **Complete step-by-step audit** — a rejected application's full history is available from one place, same "one query, complete story" principle as `journal-design`

## Why Test 4 matters more than it might look

This directly reuses the honest lesson from the saga orchestrator built earlier today: a partial failure must leave the system in a *known, accurately labeled* state — never silently pretend to be further along than reality, and never throw away work that genuinely succeeded. An account that's real and usable shouldn't be deleted just because the card printer service happened to be down at the wrong moment; it should sit at an accurate status until the next step can be retried.

## How this ties three packages together, for real

```
OnboardingWorkflow.run()
        │
        ├── screening_fn → kyc-aml-design's SanctionsScreeningEngine
        │   (same CONFIRMED_MATCH / POTENTIAL_MATCH / CLEAR vocabulary)
        │
        ├── account_creation_fn → Phase 1's ledger (ACCOUNT table)
        │
        └── card_issuance_fn → card-issuance-design's CardIssuanceService
            (which itself already integrates with token-lifecycle-design)
```

This is the second package today (after card-issuance-design) built explicitly as an integration on top of prior work rather than a new standalone concern — and like that one, the tests prove the integration is real, not just implied.

## Honest limitation

The actual identity verification / document collection step (scanning an ID, biometric liveness check — the real "how do we know this person is who they claim to be" part of onboarding) is not built here. This package assumes a name has already been captured and focuses on correctly sequencing screening, account creation, and card issuance around it — the identity-proofing step itself is a genuinely separate, specialized capability (often a third-party integration in real banks) not attempted in this package.
