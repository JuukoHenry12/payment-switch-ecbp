-- ============================================================
-- ECBP Card Authorization — DDL
-- ============================================================
-- Implements the REAL DMS (Dual Message System) lifecycle discussed
-- earlier today: an authorization places a HOLD, not a ledger
-- posting. A SEPARATE capture event, arriving hours to days later,
-- is what actually posts the transaction. This table set is the
-- concrete implementation of that distinction, tied to the same
-- TRANSACTION_HEADER/TRANSACTION_ENTRY ledger from Phase 1.
-- ============================================================

CREATE TABLE CARD_AUTHORIZATION (
    AUTH_ID                 UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_ID                    UUID          NOT NULL,   -- same correlation key as everything today
    CARD_TOKEN                  VARCHAR(19) NOT NULL,   -- the TOKEN from the tokenization vault, never the real PAN
    ACCOUNT_ID                    VARCHAR(20) NOT NULL,
    MERCHANT_NAME                    VARCHAR(100) NOT NULL,
    AMOUNT                              DECIMAL(15,2) NOT NULL,
    STATUS                                VARCHAR(20)  NOT NULL,  -- HELD, CAPTURED, EXPIRED, DECLINED
    AUTHORIZED_AT                          TIMESTAMPTZ  NOT NULL DEFAULT now(),
    HOLD_EXPIRES_AT                          TIMESTAMPTZ NOT NULL,  -- the real, standard 3-7 day hold expiry
    CAPTURED_AT                                TIMESTAMPTZ NULL,
    DECLINE_REASON                               VARCHAR(50) NULL
);

CREATE INDEX IDX_CARD_AUTH_STATUS ON CARD_AUTHORIZATION (STATUS, HOLD_EXPIRES_AT)
    WHERE STATUS = 'HELD';
-- This index is what makes the "orphaned hold" sweep (find HELD
-- authorizations past their expiry that were never captured)
-- efficient - exactly the real operational problem discussed
-- earlier today: a customer walks away, the merchant never batches
-- out, and the hold must eventually release automatically.
