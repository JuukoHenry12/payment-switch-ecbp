# Card Authorization Service — Design Package

## What this ties together

The C ISO 8583 message work from this morning, the tokenization vault from this afternoon (card identity is always a `TOKEN`, never the real PAN), the fraud rule engine, and the real DMS authorization-vs-capture lifecycle discussed early in today's design session — all in one coherent `card-service` flow, genuinely tested.

## A serious bug found — worth reading closely, more than the others today

The `sweep_expired_holds` function iterated **every authorization across the entire service**, not just the ones belonging to the account it was called with. Test 5's account (`ACC0003333`) received a credit for an expired hold that actually belonged to a completely different account (`ACC0001234`, from Test 1) — money was about to be credited to the wrong customer.

**This is qualitatively more serious than the earlier bugs found today.** The idempotency and saga bugs would have caused things to *not happen* correctly (a stuck queue, a double-post, a silently-skipped batch day). This one would have caused money to move to the **wrong party entirely** — a genuine, severe financial-integrity defect, exactly the kind of thing a real bank's audit or a regulator would treat as a serious incident, not a minor bug.

Fixed by filtering the sweep to only the authorizations matching the account actually passed in. The test that caught it wasn't looking for this specifically — it was a routine "does the sweep work" test that happened to have two different accounts' authorizations sitting in the same service instance, which is exactly the realistic condition (multiple customers, one running service) that exposed the flaw.

## Files

```
ddl/card_auth_ddl.sql                      - CARD_AUTHORIZATION, with the expiry-sweep index
service/card_authorization_service.py      - tested against 6 real scenarios, one serious bug found and fixed
```

## Verified, working — 6 real scenarios

1. **Approved authorization** — correctly places a HOLD, explicitly not a ledger posting
2. **Declined by fraud rule** — amount threshold, available credit correctly left untouched
3. **Declined by insufficient credit** — a completely separate decline path, correctly distinguished
4. **Partial capture** (the real restaurant-tip scenario) — captures less than the original hold, correctly releases exactly the difference back
5. **Orphaned hold expiry** — never captured, automatically releases after the real-world 5-day window, **correctly scoped to only the right account** after the fix
6. **Late capture safety check** — an already-expired authorization can never be captured after the fact, and doesn't double-affect the account's credit

## How this connects to everything built today

```
ISO 8583 authorization request arrives (0100 message, per this
morning's C work) — card identity is the TOKEN, never the real PAN
        │
        ▼
CardAuthorizationService.authorize()
        │
        ├── fraud check (same pattern as the tested RuleEngine)
        ├── available credit check
        │
        └── APPROVED → HOLD placed (NOT a ledger entry yet)
                │
                ▼ (hours to days later, per the real DMS pattern)
        capture() → THIS is what would trigger a real
                    TRANSACTION_HEADER/ENTRY posting via account-service
                    (the ledger posting itself already proven correct
                    in the Phase 1 package - this service's job is the
                    authorization/capture state machine around it)
                │
                ▼ (if never captured)
        sweep_expired_holds() → releases the hold automatically,
                    scoped correctly to the right account only
```

## Honest limitation

The fraud check here is deliberately simplified to two rules, matching the shape of the fully-tested `RuleEngine` from the fraud-design package rather than re-testing rule logic already proven correct independently. A real integration would call the actual `RuleEngine` and `IsolationForest` model directly, not a simplified inline reimplementation.
