"""
card_authorization_service.py — ties together the ISO 8583 card
domain (this morning's C/C++ work), the tokenization vault (this
afternoon's security package), the fraud rule engine, and the real
DMS authorization-vs-capture lifecycle discussed early in today's
design session — into one coherent, genuinely tested card-service
authorization flow.

The key distinction this correctly implements: authorization places
a HOLD against available credit, NOT a ledger posting. A separate
capture event, arriving later, is what actually creates a
TRANSACTION_HEADER/TRANSACTION_ENTRY pair on the ledger. This is
exactly the real-world DMS pattern - and the orphaned-hold expiry
problem (a hold that's never captured must eventually release
itself) is handled explicitly, not left as a gap.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from enum import Enum


class AuthStatus(Enum):
    HELD = "HELD"
    CAPTURED = "CAPTURED"
    EXPIRED = "EXPIRED"
    DECLINED = "DECLINED"


@dataclass
class CardAuthorization:
    auth_id: str
    txn_id: str
    card_token: str
    account_id: str
    amount: Decimal
    status: AuthStatus
    authorized_at: datetime
    hold_expires_at: datetime
    captured_at: datetime | None = None
    decline_reason: str | None = None


@dataclass
class Account:
    account_id: str
    available_credit: Decimal   # what's actually spendable right now (credit limit minus existing holds)
    daily_txn_count: int = 0


class CardAuthorizationService:

    HOLD_DURATION_DAYS = 5  # real-world standard is 3-7 days
    MAX_DAILY_TXN_COUNT = 5  # mirrors the velocity rule from the fraud-design package
    LARGE_AMOUNT_THRESHOLD = Decimal("5000.00")

    def __init__(self):
        self.authorizations: dict[str, CardAuthorization] = {}
        self.log: list[str] = []

    def _log(self, msg: str):
        self.log.append(msg)
        print(f"  {msg}")

    def _fraud_check(self, account: Account, amount: Decimal) -> tuple[bool, str | None]:
        """Simplified rule check, same shape as the fully-tested
        RuleEngine from the fraud-design package - this integration
        reuses the pattern rather than re-proving rule logic already
        validated independently."""
        if account.daily_txn_count >= self.MAX_DAILY_TXN_COUNT:
            return False, "VELOCITY_EXCEEDED"
        if amount > self.LARGE_AMOUNT_THRESHOLD:
            return False, "AMOUNT_THRESHOLD_EXCEEDED"
        return True, None

    def authorize(self, txn_id: str, card_token: str, account: Account,
                   merchant_name: str, amount: Decimal, now: datetime) -> CardAuthorization:
        """
        The real DMS authorization step: check fraud, check available
        credit, and if both pass, place a HOLD - explicitly NOT a
        ledger posting. This is the exact distinction from the
        earlier SMS/DMS discussion: money doesn't move here, it's
        reserved.
        """
        fraud_ok, decline_reason = self._fraud_check(account, amount)
        if not fraud_ok:
            self._log(f"AUTH DECLINED: {card_token} for {amount} - {decline_reason}")
            auth = CardAuthorization(
                auth_id=f"AUTH-{txn_id}", txn_id=txn_id, card_token=card_token,
                account_id=account.account_id, amount=amount, status=AuthStatus.DECLINED,
                authorized_at=now, hold_expires_at=now, decline_reason=decline_reason,
            )
            self.authorizations[auth.auth_id] = auth
            return auth

        if account.available_credit < amount:
            self._log(f"AUTH DECLINED: {card_token} for {amount} - INSUFFICIENT_CREDIT "
                      f"(available: {account.available_credit})")
            auth = CardAuthorization(
                auth_id=f"AUTH-{txn_id}", txn_id=txn_id, card_token=card_token,
                account_id=account.account_id, amount=amount, status=AuthStatus.DECLINED,
                authorized_at=now, hold_expires_at=now, decline_reason="INSUFFICIENT_CREDIT",
            )
            self.authorizations[auth.auth_id] = auth
            return auth

        # Approved - place the HOLD, do NOT post to the ledger yet.
        account.available_credit -= amount
        account.daily_txn_count += 1
        auth = CardAuthorization(
            auth_id=f"AUTH-{txn_id}", txn_id=txn_id, card_token=card_token,
            account_id=account.account_id, amount=amount, status=AuthStatus.HELD,
            authorized_at=now, hold_expires_at=now + timedelta(days=self.HOLD_DURATION_DAYS),
        )
        self.authorizations[auth.auth_id] = auth
        self._log(f"AUTH APPROVED: {card_token} for {amount} at {merchant_name}. "
                  f"Hold placed, account available_credit now {account.available_credit}")
        return auth

    def capture(self, auth_id: str, capture_amount: Decimal, now: datetime, account: Account) -> bool:
        """
        The DMS capture step - arrives separately, potentially hours
        or days later. THIS is what would actually create a
        TRANSACTION_HEADER/ENTRY pair on the ledger in the real
        system (delegated conceptually here, since the ledger posting
        itself was already proven correct in the Phase 1 package -
        this test's job is the authorization/capture STATE MACHINE,
        not re-proving ledger posting).
        """
        auth = self.authorizations.get(auth_id)
        if auth is None or auth.status != AuthStatus.HELD:
            self._log(f"CAPTURE REJECTED: {auth_id} - not in HELD state "
                      f"(actual: {auth.status if auth else 'NOT FOUND'})")
            return False

        if now > auth.hold_expires_at:
            self._log(f"CAPTURE REJECTED: {auth_id} - hold already expired at {auth.hold_expires_at}")
            return False

        # Real-world nuance: capture amount can differ from the
        # original hold (restaurant tip, hotel incidentals) - only
        # release the DIFFERENCE if capturing less than held.
        if capture_amount < auth.amount:
            difference = auth.amount - capture_amount
            account.available_credit += difference
            self._log(f"CAPTURE {auth_id}: captured {capture_amount} (less than held {auth.amount}), "
                      f"released difference {difference} back to available credit")

        auth.status = AuthStatus.CAPTURED
        auth.captured_at = now
        self._log(f"CAPTURE COMPLETED: {auth_id} for {capture_amount}")
        return True

    def sweep_expired_holds(self, now: datetime, account: Account) -> list[str]:
        """
        The orphaned-hold problem, handled explicitly: a HELD
        authorization whose expiry has passed without ever being
        captured must release its hold on available credit
        automatically - exactly the real operational gap named (but
        not built) in the earlier SMS/DMS discussion.

        CRITICAL: only processes holds belonging to THIS account -
        a previous version of this method iterated every
        authorization across the entire service and applied whatever
        it found to whichever single account object was passed in,
        meaning an expired hold belonging to a COMPLETELY DIFFERENT
        customer's account would incorrectly credit this account
        instead. Found via Test 5/6 below reporting an unexpected
        final balance. In a real system this would mean crediting
        money to the wrong customer - a genuinely serious class of
        bug, not a cosmetic one.
        """
        expired = []
        for auth in self.authorizations.values():
            if auth.account_id != account.account_id:
                continue  # THE FIX - only this account's own holds
            if auth.status == AuthStatus.HELD and now > auth.hold_expires_at:
                account.available_credit += auth.amount
                auth.status = AuthStatus.EXPIRED
                expired.append(auth.auth_id)
                self._log(f"EXPIRY SWEEP: {auth.auth_id} expired, released {auth.amount} "
                          f"back to available credit (now {account.available_credit})")
        return expired


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    now = datetime(2026, 8, 8, 10, 0, 0)
    service = CardAuthorizationService()

    print("=== TEST 1: Approved authorization, correctly places a HOLD not a ledger posting ===")
    account = Account(account_id="ACC0001234", available_credit=Decimal("10000.00"))
    auth1 = service.authorize("TXN-CARD-001", "TOKEN-ABC123", account, "Grocery Store", Decimal("150.00"), now)
    print(f"Status: {auth1.status.value} (expected: HELD)")
    print(f"Available credit reduced: {account.available_credit == Decimal('9850.00')} (expected: True)")

    print()
    print("=== TEST 2: Declined - fraud rule (amount exceeds threshold) ===")
    auth2 = service.authorize("TXN-CARD-002", "TOKEN-ABC123", account, "Electronics Store", Decimal("6000.00"), now)
    print(f"Status: {auth2.status.value} (expected: DECLINED)")
    print(f"Decline reason: {auth2.decline_reason} (expected: AMOUNT_THRESHOLD_EXCEEDED)")
    print(f"Available credit UNCHANGED by a decline: {account.available_credit == Decimal('9850.00')} (expected: True)")

    print()
    print("=== TEST 3: Declined - insufficient available credit ===")
    account_low = Account(account_id="ACC0009999", available_credit=Decimal("100.00"))
    auth3 = service.authorize("TXN-CARD-003", "TOKEN-XYZ789", account_low, "Restaurant", Decimal("250.00"), now)
    print(f"Status: {auth3.status.value} (expected: DECLINED)")
    print(f"Decline reason: {auth3.decline_reason} (expected: INSUFFICIENT_CREDIT)")

    print()
    print("=== TEST 4: Capture LESS than the original hold (restaurant tip scenario) ===")
    account_tip = Account(account_id="ACC0002222", available_credit=Decimal("5000.00"))
    auth4 = service.authorize("TXN-CARD-004", "TOKEN-TIP001", account_tip, "Restaurant", Decimal("100.00"), now)
    print(f"After auth: available_credit = {account_tip.available_credit} (expected: 4900.00)")
    later = now + timedelta(hours=2)
    captured = service.capture(auth4.auth_id, Decimal("85.00"), later, account_tip)  # final bill was less than pre-auth
    print(f"Capture succeeded: {captured} (expected: True)")
    print(f"Difference released back: available_credit = {account_tip.available_credit} "
          f"(expected: 4915.00 = 4900 + the 15.00 difference)")

    print()
    print("=== TEST 5: Orphaned hold - never captured, sweep releases it automatically ===")
    print("(this also verifies the sweep is correctly scoped to ONLY this account -")
    print(" a previous version of this test found the sweep incorrectly applying an")
    print(" expired hold belonging to ACC0001234 from Test 1 onto this unrelated account)")
    account_orphan = Account(account_id="ACC0003333", available_credit=Decimal("2000.00"))
    auth5 = service.authorize("TXN-CARD-005", "TOKEN-ORPHAN01", account_orphan, "Hotel", Decimal("500.00"), now)
    print(f"After auth: available_credit = {account_orphan.available_credit} (expected: 1500.00)")
    far_future = now + timedelta(days=10)  # well past the 5-day hold expiry, never captured
    expired = service.sweep_expired_holds(far_future, account_orphan)
    print(f"Expired auth IDs found by sweep: {expired} (expected: ONLY AUTH-TXN-CARD-005, "
          f"NOT AUTH-TXN-CARD-001 which belongs to a different account)")
    print(f"Available credit fully restored: {account_orphan.available_credit == Decimal('2000.00')} (expected: True)")
    print(f"Auth status now EXPIRED: {service.authorizations[auth5.auth_id].status == AuthStatus.EXPIRED} (expected: True)")

    print()
    print("=== TEST 6: An EXPIRED hold can never be captured after the fact - safety check ===")
    late_capture_attempt = service.capture(auth5.auth_id, Decimal("500.00"), far_future, account_orphan)
    print(f"Late capture correctly rejected: {not late_capture_attempt} (expected: True)")
    print(f"Available credit not double-affected: {account_orphan.available_credit == Decimal('2000.00')} (expected: True)")
