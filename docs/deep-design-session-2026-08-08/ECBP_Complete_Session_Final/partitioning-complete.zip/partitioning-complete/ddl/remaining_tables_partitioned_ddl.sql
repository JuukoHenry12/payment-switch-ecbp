-- ============================================================
-- ECBP — Remaining High-Volume Tables, Partitioned
-- ============================================================
-- Closes item 2: every table identified in the original gap
-- analysis now has a corrected, partitioned schema. Each partitioned
-- by its own natural, already-existing timestamp column - no new
-- columns invented, no schema redesign beyond adding PARTITION BY.
-- ============================================================

-- ------------------------------------------------------------
-- CHANNEL_INGESTION_LOG — partitioned by RECEIVED_AT
-- ------------------------------------------------------------
CREATE TABLE CHANNEL_INGESTION_LOG (
    INGESTION_ID              UUID           NOT NULL DEFAULT gen_random_uuid(),
    TXN_ID                       UUID        NOT NULL,
    CHANNEL_TYPE                    VARCHAR(10) NOT NULL,
    RAW_MESSAGE_TYPE                   VARCHAR(30) NOT NULL,
    TERMINAL_ID                           VARCHAR(20) NULL,
    NORMALIZATION_OUTCOME                    VARCHAR(20) NOT NULL,
    REJECT_REASON                               VARCHAR(100) NULL,
    RECEIVED_AT                                   TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (INGESTION_ID, RECEIVED_AT)
) PARTITION BY RANGE (RECEIVED_AT);

CREATE TABLE CHANNEL_INGESTION_LOG_2026_08 PARTITION OF CHANNEL_INGESTION_LOG
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

-- ------------------------------------------------------------
-- TOKEN_LIFECYCLE_LOG — partitioned by PERFORMED_AT
-- ------------------------------------------------------------
CREATE TABLE TOKEN_LIFECYCLE_LOG (
    LIFECYCLE_EVENT_ID       UUID            NOT NULL DEFAULT gen_random_uuid(),
    TOKEN                       VARCHAR(19)  NOT NULL,
    ACTION                        VARCHAR(20) NOT NULL,
    REASON                          VARCHAR(100) NULL,
    PERFORMED_BY                       VARCHAR(50) NOT NULL,
    PERFORMED_AT                         TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (LIFECYCLE_EVENT_ID, PERFORMED_AT)
) PARTITION BY RANGE (PERFORMED_AT);

CREATE TABLE TOKEN_LIFECYCLE_LOG_2026_08 PARTITION OF TOKEN_LIFECYCLE_LOG
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

-- ------------------------------------------------------------
-- SCREENING_RESULT — partitioned by SCREENED_AT
-- Real volume driver: perpetual/ongoing re-screening never stops.
-- ------------------------------------------------------------
CREATE TABLE SCREENING_RESULT (
    SCREENING_ID               UUID          NOT NULL DEFAULT gen_random_uuid(),
    ACCOUNT_ID                    VARCHAR(20) NOT NULL,
    SCREENING_TYPE                    VARCHAR(20) NOT NULL,
    LIST_TYPE                            VARCHAR(20) NOT NULL,
    MATCHED_ENTRY_ID                        UUID     NULL,
    MATCH_SCORE                                DECIMAL(4,3) NULL,
    OUTCOME                                       VARCHAR(20) NOT NULL,
    SCREENED_AT                                     TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (SCREENING_ID, SCREENED_AT)
) PARTITION BY RANGE (SCREENED_AT);

CREATE TABLE SCREENING_RESULT_2026_08 PARTITION OF SCREENING_RESULT
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

-- ------------------------------------------------------------
-- TRANSACTION_JOURNAL_ENTRY — partitioned by RECORDED_AT
-- Note: BIGSERIAL alone cannot be the sole primary key on a
-- partitioned table either - same underlying rule as everything
-- else here, replaced with GENERATED ALWAYS AS IDENTITY + composite key.
-- ------------------------------------------------------------
CREATE TABLE TRANSACTION_JOURNAL_ENTRY (
    JOURNAL_ENTRY_ID          BIGINT         NOT NULL GENERATED ALWAYS AS IDENTITY,
    TXN_ID                       UUID        NOT NULL,
    STEP_SEQUENCE                   SMALLINT NOT NULL,
    SERVICE_NAME                       VARCHAR(50) NOT NULL,
    STEP_NAME                            VARCHAR(100) NOT NULL,
    STATUS                                  VARCHAR(20) NOT NULL,
    INPUT_SNAPSHOT                            JSONB     NOT NULL,
    OUTPUT_SNAPSHOT                             JSONB    NULL,
    REASON_CODE                                   VARCHAR(4) NULL,
    DURATION_MS                                     INTEGER NOT NULL,
    RECORDED_AT                                       TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (JOURNAL_ENTRY_ID, RECORDED_AT),
    CONSTRAINT UQ_TXN_STEP UNIQUE (TXN_ID, STEP_SEQUENCE, RECORDED_AT)
) PARTITION BY RANGE (RECORDED_AT);

CREATE TABLE TRANSACTION_JOURNAL_ENTRY_2026_08 PARTITION OF TRANSACTION_JOURNAL_ENTRY
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

-- ------------------------------------------------------------
-- OUTBOUND_QUEUE_ENTRY — partitioned by QUEUED_AT
-- ------------------------------------------------------------
CREATE TABLE OUTBOUND_QUEUE_ENTRY (
    QUEUE_ENTRY_ID             UUID           NOT NULL DEFAULT gen_random_uuid(),
    DESTINATION                    VARCHAR(30) NOT NULL,
    TXN_ID                            UUID     NOT NULL,
    PAYLOAD                              TEXT   NOT NULL,
    SEQUENCE_NUMBER                        BIGINT NOT NULL,
    STATUS                                    VARCHAR(20) NOT NULL DEFAULT 'QUEUED',
    QUEUED_AT                                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    DELIVERED_AT                                    TIMESTAMPTZ NULL,

    PRIMARY KEY (QUEUE_ENTRY_ID, QUEUED_AT)
) PARTITION BY RANGE (QUEUED_AT);

CREATE TABLE OUTBOUND_QUEUE_ENTRY_2026_08 PARTITION OF OUTBOUND_QUEUE_ENTRY
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
