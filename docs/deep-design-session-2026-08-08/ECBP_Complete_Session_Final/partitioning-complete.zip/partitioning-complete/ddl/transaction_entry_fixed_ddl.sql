-- ============================================================
-- ECBP TRANSACTION_ENTRY — Corrected, Partitioned, FK Fixed
-- ============================================================
-- Closes item 1: this table's original FK, `TXN_ID UUID NOT NULL
-- REFERENCES TRANSACTION_HEADER(TXN_ID)`, would genuinely fail to
-- even CREATE in real Postgres now that TRANSACTION_HEADER's
-- primary key is the composite (TXN_ID, CREATED_AT) - a foreign key
-- must reference a column set that's actually unique on the parent,
-- and TXN_ID alone no longer is.
--
-- TRANSACTION_ENTRY is also, in its own right, likely the SINGLE
-- highest-volume table in the whole schema (2+ entries per
-- transaction, every transaction) - partitioning it was always going
-- to be necessary regardless of the FK issue.
-- ============================================================

CREATE TABLE TRANSACTION_ENTRY (
    ENTRY_ID              UUID            NOT NULL DEFAULT gen_random_uuid(),
    TXN_ID                    UUID         NOT NULL,
    HEADER_CREATED_AT            TIMESTAMPTZ NOT NULL,  -- THE FIX: propagated from the parent
                                                          -- TRANSACTION_HEADER row at insert time,
                                                          -- making the composite FK below possible
    ACCOUNT_ID                      VARCHAR(20) NOT NULL,
    DEBIT_AMT                          DECIMAL(15,2) NOT NULL DEFAULT 0,
    CREDIT_AMT                            DECIMAL(15,2) NOT NULL DEFAULT 0,
    CREATED_AT                               TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (ENTRY_ID, HEADER_CREATED_AT),

    -- THE ACTUAL FIX: a composite foreign key, referencing BOTH
    -- columns of TRANSACTION_HEADER's real composite primary key.
    CONSTRAINT FK_ENTRY_TXN_HEADER
        FOREIGN KEY (TXN_ID, HEADER_CREATED_AT)
        REFERENCES TRANSACTION_HEADER (TXN_ID, CREATED_AT)

) PARTITION BY RANGE (HEADER_CREATED_AT);

CREATE TABLE TRANSACTION_ENTRY_2026_08 PARTITION OF TRANSACTION_ENTRY
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
CREATE TABLE TRANSACTION_ENTRY_2026_09 PARTITION OF TRANSACTION_ENTRY
    FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');

CREATE INDEX IDX_ENTRY_TXN_ID ON TRANSACTION_ENTRY (TXN_ID, HEADER_CREATED_AT);
