-- ============================================================
-- ECBP — The 8 Additional Tables From the Systematic Review, Partitioned
-- ============================================================
-- Applying the same proven pattern from the first 7 tables: range
-- partition by each table's own real timestamp column, composite
-- primary key where a unique constraint exists, and composite
-- foreign keys wherever another table references the partitioned
-- table's key. Two NEW cascade dependencies found while doing this -
-- SAGA_STEP_LOG -> SAGA_INSTANCE and SWIFT_MESSAGE_LOG ->
-- SETTLEMENT_INSTRUCTION - the exact same class of problem the
-- TRANSACTION_ENTRY fix closed earlier, now found and closed here too.
-- ============================================================

CREATE TABLE CARD_AUTHORIZATION (
    AUTH_ID                 UUID            NOT NULL DEFAULT gen_random_uuid(),
    TXN_ID                    UUID          NOT NULL,
    CARD_TOKEN                  VARCHAR(19) NOT NULL,
    ACCOUNT_ID                    VARCHAR(20) NOT NULL,
    MERCHANT_NAME                    VARCHAR(100) NOT NULL,
    AMOUNT                              DECIMAL(15,2) NOT NULL,
    STATUS                                VARCHAR(20)  NOT NULL,
    AUTHORIZED_AT                          TIMESTAMPTZ  NOT NULL DEFAULT now(),
    HOLD_EXPIRES_AT                          TIMESTAMPTZ NOT NULL,
    CAPTURED_AT                                TIMESTAMPTZ NULL,
    DECLINE_REASON                               VARCHAR(50) NULL,

    PRIMARY KEY (AUTH_ID, AUTHORIZED_AT)
) PARTITION BY RANGE (AUTHORIZED_AT);

CREATE TABLE CARD_AUTHORIZATION_2026_08 PARTITION OF CARD_AUTHORIZATION
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

-- FRAUD_DECISION_LOG - highest fan-out ratio of any table in this review
CREATE TABLE FRAUD_DECISION_LOG (
    DECISION_ID           UUID            NOT NULL DEFAULT gen_random_uuid(),
    TXN_ID                UUID            NOT NULL,
    DETECTION_METHOD       VARCHAR(20)    NOT NULL,
    RULE_ID                VARCHAR(50)    NULL,
    ANOMALY_SCORE            DOUBLE PRECISION NULL,
    ACTION_TAKEN              VARCHAR(30)  NOT NULL,
    LATENCY_MS                 INTEGER     NOT NULL,
    DECIDED_AT                  TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (DECISION_ID, DECIDED_AT)
) PARTITION BY RANGE (DECIDED_AT);

CREATE TABLE FRAUD_DECISION_LOG_2026_08 PARTITION OF FRAUD_DECISION_LOG
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

CREATE TABLE OPEN_BANKING_ACCESS_LOG (
    ACCESS_ID                 UUID           NOT NULL DEFAULT gen_random_uuid(),
    TPP_ID                        VARCHAR(30) NOT NULL,
    ACCOUNT_ID                       VARCHAR(20) NOT NULL,
    REQUESTED_SCOPE                     VARCHAR(30) NOT NULL,
    OUTCOME                                VARCHAR(20) NOT NULL,
    ACCESSED_AT                               TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (ACCESS_ID, ACCESSED_AT)
) PARTITION BY RANGE (ACCESSED_AT);

CREATE TABLE OPEN_BANKING_ACCESS_LOG_2026_08 PARTITION OF OPEN_BANKING_ACCESS_LOG
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

-- SAGA_INSTANCE + SAGA_STEP_LOG - a SECOND cascading FK found, same
-- class of problem as TRANSACTION_ENTRY -> TRANSACTION_HEADER
CREATE TABLE SAGA_INSTANCE (
    SAGA_ID              UUID            NOT NULL DEFAULT gen_random_uuid(),
    TXN_ID                 UUID          NOT NULL,
    SAGA_TYPE               VARCHAR(30)  NOT NULL,
    STATUS                    VARCHAR(20) NOT NULL,
    CURRENT_STEP_INDEX          SMALLINT  NOT NULL DEFAULT 0,
    CREATED_AT                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UPDATED_AT                      TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (SAGA_ID, CREATED_AT)
) PARTITION BY RANGE (CREATED_AT);

CREATE TABLE SAGA_INSTANCE_2026_08 PARTITION OF SAGA_INSTANCE
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

CREATE TABLE SAGA_STEP_LOG (
    STEP_LOG_ID          UUID            NOT NULL DEFAULT gen_random_uuid(),
    SAGA_ID                UUID          NOT NULL,
    SAGA_CREATED_AT           TIMESTAMPTZ NOT NULL,   -- THE FIX: propagated from the parent saga
    STEP_INDEX               SMALLINT    NOT NULL,
    STEP_NAME                  VARCHAR(50) NOT NULL,
    STEP_STATUS                  VARCHAR(20) NOT NULL,
    EXECUTED_AT                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    COMPENSATED_AT                   TIMESTAMPTZ NULL,

    PRIMARY KEY (STEP_LOG_ID, EXECUTED_AT),
    CONSTRAINT FK_STEP_SAGA
        FOREIGN KEY (SAGA_ID, SAGA_CREATED_AT)
        REFERENCES SAGA_INSTANCE (SAGA_ID, CREATED_AT)
) PARTITION BY RANGE (EXECUTED_AT);

CREATE TABLE SAGA_STEP_LOG_2026_08 PARTITION OF SAGA_STEP_LOG
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

CREATE TABLE TOKEN_ACCESS_LOG (
    ACCESS_ID               UUID           NOT NULL DEFAULT gen_random_uuid(),
    TOKEN                    VARCHAR(19)    NOT NULL,
    REQUESTING_SERVICE        VARCHAR(50)   NOT NULL,
    REQUEST_REASON              VARCHAR(100) NOT NULL,
    OUTCOME                      VARCHAR(20) NOT NULL,
    REQUESTED_AT                  TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (ACCESS_ID, REQUESTED_AT)
) PARTITION BY RANGE (REQUESTED_AT);

CREATE TABLE TOKEN_ACCESS_LOG_2026_08 PARTITION OF TOKEN_ACCESS_LOG
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

-- SETTLEMENT_INSTRUCTION + SWIFT_MESSAGE_LOG - a THIRD cascading FK
CREATE TABLE SETTLEMENT_INSTRUCTION (
    SETTLEMENT_ID           UUID            NOT NULL DEFAULT gen_random_uuid(),
    TXN_ID                  UUID            NOT NULL,
    SETTLEMENT_ACCOUNT_ID   VARCHAR(30)     NOT NULL,
    AMOUNT                  DECIMAL(18,2)   NOT NULL,
    DIRECTION               VARCHAR(10)     NOT NULL,
    STATUS                  VARCHAR(20)     NOT NULL,
    PRIORITY                SMALLINT        NOT NULL DEFAULT 5,
    QUEUED_AT                TIMESTAMPTZ     NULL,
    SETTLED_AT               TIMESTAMPTZ     NULL,
    EXTERNAL_CONFIRMATION_REF VARCHAR(100)   NULL,
    CREATED_AT                TIMESTAMPTZ    NOT NULL DEFAULT now(),

    PRIMARY KEY (SETTLEMENT_ID, CREATED_AT)
) PARTITION BY RANGE (CREATED_AT);

CREATE TABLE SETTLEMENT_INSTRUCTION_2026_08 PARTITION OF SETTLEMENT_INSTRUCTION
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

CREATE TABLE SWIFT_MESSAGE_LOG (
    MESSAGE_ID              UUID            NOT NULL DEFAULT gen_random_uuid(),
    SETTLEMENT_ID              UUID          NOT NULL,
    SETTLEMENT_CREATED_AT         TIMESTAMPTZ NOT NULL,  -- THE FIX: propagated from the parent settlement
    TXN_ID                       UUID        NOT NULL,
    MESSAGE_TYPE                   VARCHAR(20) NOT NULL,
    END_TO_END_ID                    VARCHAR(35) NOT NULL,
    RAW_XML                            TEXT      NOT NULL,
    VALIDATION_STATUS                    VARCHAR(20) NOT NULL,
    VALIDATION_ERRORS                      TEXT    NULL,
    SENT_AT                                  TIMESTAMPTZ NULL,
    CREATED_AT                                 TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (MESSAGE_ID, CREATED_AT),
    CONSTRAINT FK_SWIFT_SETTLEMENT
        FOREIGN KEY (SETTLEMENT_ID, SETTLEMENT_CREATED_AT)
        REFERENCES SETTLEMENT_INSTRUCTION (SETTLEMENT_ID, CREATED_AT)
) PARTITION BY RANGE (CREATED_AT);

CREATE TABLE SWIFT_MESSAGE_LOG_2026_08 PARTITION OF SWIFT_MESSAGE_LOG
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

-- TRANSACTION_LIFECYCLE_VIEW - honest note: semantically different
-- from the other 12 tables here. This is a CQRS read model that gets
-- UPDATED as a transaction's lifecycle progresses, not a pure
-- append-only log. Range partitioning still works correctly (an
-- UPDATE routes to whichever partition the row already lives in),
-- but the operational reasoning differs: this is about keeping
-- ACTIVE, still-updating transactions in a small fast partition,
-- separate from the much larger volume of old, permanently-settled ones.
CREATE TABLE TRANSACTION_LIFECYCLE_VIEW (
    TXN_ID                    UUID            NOT NULL,
    FROM_ACCOUNT_ID             VARCHAR(20)   NOT NULL,
    TO_ACCOUNT_ID                 VARCHAR(20) NOT NULL,
    AMOUNT                          DECIMAL(15,2) NOT NULL,
    CURRENCY                          CHAR(3)   NOT NULL,
    LEDGER_STATUS                      VARCHAR(20) NOT NULL,
    INITIATED_AT                         TIMESTAMPTZ NOT NULL,
    SETTLED_AT                            TIMESTAMPTZ NULL,
    FAILURE_REASON_CODE                    VARCHAR(30) NULL,
    FRAUD_CHECK_COUNT                        SMALLINT  NOT NULL DEFAULT 0,
    FRAUD_FINAL_ACTION                        VARCHAR(30) NULL,

    PRIMARY KEY (TXN_ID, INITIATED_AT)
) PARTITION BY RANGE (INITIATED_AT);

CREATE TABLE TRANSACTION_LIFECYCLE_VIEW_2026_08 PARTITION OF TRANSACTION_LIFECYCLE_VIEW
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
