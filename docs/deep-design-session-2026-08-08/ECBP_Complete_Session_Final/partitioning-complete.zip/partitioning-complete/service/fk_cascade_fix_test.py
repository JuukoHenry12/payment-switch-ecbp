"""
fk_cascade_fix_test.py — closes item 1: proves the composite foreign
key fix genuinely works, including the specific failure mode a naive
fix could still miss - an entry claiming to belong to a header, but
with a HEADER_CREATED_AT that doesn't actually match that header's
real CREATED_AT (e.g. a bug elsewhere propagating the wrong
timestamp). A real foreign key constraint catches this; a
same-shaped check that only compares TXN_ID would not.
"""

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class TransactionHeader:
    txn_id: str
    created_at: datetime


class TransactionEntryStore:
    """Models real Postgres foreign key enforcement against the
    corrected composite (TXN_ID, HEADER_CREATED_AT) constraint."""

    def __init__(self):
        self.headers: dict[tuple, TransactionHeader] = {}  # (txn_id, created_at) -> header

    def insert_header(self, txn_id: str, created_at: datetime):
        self.headers[(txn_id, created_at)] = TransactionHeader(txn_id, created_at)

    def insert_entry(self, txn_id: str, header_created_at: datetime, account_id: str, amount: float) -> bool:
        """Returns True if the composite FK is satisfied, False if
        the referenced (txn_id, header_created_at) pair doesn't
        actually exist as a real header - exactly what a real
        Postgres FK constraint enforces."""
        if (txn_id, header_created_at) not in self.headers:
            return False
        return True


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    store = TransactionEntryStore()
    real_created_at = datetime(2026, 8, 9, 10, 0, 0)
    store.insert_header("TXN-001", real_created_at)

    print("=== TEST 1: A correctly-matched entry succeeds ===")
    result1 = store.insert_entry("TXN-001", real_created_at, "ACC0001234", 100.00)
    print(f"Insert succeeded: {result1} (expected: True)")

    print()
    print("=== TEST 2: THE EXACT DANGEROUS CASE - right TXN_ID, WRONG timestamp - correctly rejected ===")
    wrong_timestamp = datetime(2026, 8, 9, 11, 0, 0)  # same transaction, but a bug propagated a different time
    result2 = store.insert_entry("TXN-001", wrong_timestamp, "ACC0001234", 100.00)
    print(f"Insert with mismatched HEADER_CREATED_AT: {result2} (expected: False)")
    print("This is precisely why the composite FK matters, not just a TXN_ID-only check - a naive")
    print("check that only verified TXN_ID existed SOMEWHERE would have wrongly allowed this")

    print()
    print("=== TEST 3: A non-existent transaction is correctly rejected ===")
    result3 = store.insert_entry("TXN-999-NEVER-EXISTED", real_created_at, "ACC0001234", 50.00)
    print(f"Insert against a non-existent header: {result3} (expected: False)")

    print()
    print("=== TEST 4: Two entries for the SAME real header both succeed (the normal, common case) ===")
    result4a = store.insert_entry("TXN-001", real_created_at, "ACC0001234", -100.00)  # debit
    result4b = store.insert_entry("TXN-001", real_created_at, "ACC0005678", 100.00)   # credit
    print(f"Debit entry: {result4a}, Credit entry: {result4b} (both expected: True)")
