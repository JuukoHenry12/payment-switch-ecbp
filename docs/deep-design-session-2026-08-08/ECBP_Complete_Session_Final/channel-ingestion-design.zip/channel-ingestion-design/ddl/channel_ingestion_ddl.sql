-- ============================================================
-- ECBP Channel Ingestion Layer — DDL
-- ============================================================
-- The missing piece identified directly: everything built today
-- (routing, fraud, tokenization, authorization, ledger) is
-- genuinely channel-agnostic ONCE a transaction enters the system -
-- but nothing actually terminates a real POS connection, ATM switch
-- message, kiosk session, or MQ-delivered message. This is that
-- front door.
-- ============================================================

CREATE TABLE CHANNEL_INGESTION_LOG (
    INGESTION_ID              UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_ID                       UUID        NOT NULL,   -- assigned HERE, at the very first point of entry -
                                                            -- the same correlation key that then threads through
                                                            -- every package built today
    CHANNEL_TYPE                    VARCHAR(10) NOT NULL, -- POS, ATM, KIOSK, MQ
    RAW_MESSAGE_TYPE                   VARCHAR(30) NOT NULL, -- ISO8583_0200, NDC_WITHDRAWAL, KIOSK_JSON, MQ_XML
    TERMINAL_ID                           VARCHAR(20) NULL,
    NORMALIZATION_OUTCOME                    VARCHAR(20) NOT NULL, -- NORMALIZED, REJECTED_MALFORMED
    REJECT_REASON                               VARCHAR(100) NULL,
    RECEIVED_AT                                   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IDX_INGESTION_CHANNEL ON CHANNEL_INGESTION_LOG (CHANNEL_TYPE, RECEIVED_AT);
-- One query answers "how much traffic is each channel actually
-- sending, and how much of it is malformed" - genuinely useful
-- operational visibility that doesn't exist anywhere else today.
