# Channel Ingestion Layer — POS / ATM / KIOSK / MQ

## What this closes

The one honest gap identified directly: everything built earlier today is genuinely channel-agnostic *once a transaction enters the system* — but nothing actually terminated a real POS connection, ATM switch message, kiosk session, or MQ-delivered message. This is that front door, for all four channels, each parsing a genuinely different real-world format.

## Files

```
ddl/channel_ingestion_ddl.sql       - CHANNEL_INGESTION_LOG, per-channel traffic and rejection visibility
service/channel_ingestion.py        - 4 real adapters, tested against 9 scenarios
```

## Verified, working — 9 real scenarios

1. **POS** — a genuine, correctly-framed ISO 8583 message (length-prefixed PAN, processing code, amount, terminal ID), parsed byte by byte
2. **ATM withdrawal** — real ISO 8583 processing code 01, correctly distinguished
3. **ATM balance inquiry, the honest edge case** — processing code 30 carries a zero amount, and the parser correctly reads the transaction type from the processing code, not by inferring it from the amount — a $0 amount must never be silently treated as a $0 withdrawal
4. **KIOSK** — a genuinely different transport and format (JSON over what would be HTTP in production), correctly parsed
5. **MQ** — XML payload, the format legacy/mainframe integrations commonly use, correctly parsed
6. **The MQ connection interface**, tested against an injected queue — real IBM MQ requires the pymqi client library and an actual queue manager, neither available in this sandbox, so the connection layer is injected exactly like every other genuinely external dependency handled today (SWIFT, live FX feeds)
7. **The actual proof of the design** — all four channels, despite completely different raw wire formats, produce the exact same IngestedTransaction Python type
8. **Malformed messages, per channel** — each adapter rejects bad input with a specific, clear reason, not a generic failure
9. **The real integration test** — a POS-ingested transaction, parsed from raw bytes, is fed directly into the actual RoutingEngine from routing-design (fixed earlier today) and correctly routes to Visa settlement. This is the same discipline as integration-fixes — proving the connection, not describing it

## Why the ATM balance-inquiry case (Test 3) is the one worth remembering

A balance inquiry and a $0 withdrawal look identical if you only read the amount field — and confusing the two in a real system is exactly the kind of subtle bug that survives testing against "normal" transactions and only surfaces in production against a specific transaction type nobody thought to test. Reading the processing code as the source of truth for transaction type, never inferring it from amount, is the correct, deliberate design choice here.

## How this connects to everything built today

```
Raw POS/ATM/KIOSK/MQ message arrives
        |
        v
Channel-specific adapter parses it, assigns a real txn_id,
logs to CHANNEL_INGESTION_LOG
        |
        v
Produces one IngestedTransaction - identical shape regardless of channel
        |
        v
Flows into the SAME pipeline built all day: RoutingEngine (proven in
Test 9), fraud RuleEngine, TokenLifecycleService, CardAuthorizationService,
the sharded ledger - none of which need to know or care which channel
the transaction originated from
```

## Honest limitations, stated plainly

- **The ISO 8583 parsing here is a real, structurally correct subset** (MTI, PAN, processing code, amount, terminal ID) — a full production parser handles the complete 128-bit bitmap and all defined data elements, which this deliberately doesn't attempt to fully replicate
- **NDC/DDC (the actual ATM-vendor-specific protocols, distinct from ISO 8583)** are not built here — this adapter assumes the ATM's driving protocol has already been normalized to ISO 8583 by an upstream driver, which is itself a real, standard piece of ATM switch architecture, not something skipped by oversight
- **Real IBM MQ connectivity** (actual pymqi client, real queue manager connection, XA transaction support for exactly-once delivery) is a genuine, separate infrastructure task — this proves the parsing and normalization logic is correct against realistic MQ payloads, not a live MQ integration
