# FX / Currency Exchange Engine — Design Package

## What this closes

`swift-design` (earlier today) moved money between currencies via a real ISO 20022 message, but never actually *converted* it — the amount field just carried the same number regardless of currency. This package adds real conversion, with the two properties that actually matter financially: honest spread application, and staleness protection.

## Files

```
ddl/fx_engine_ddl.sql          - EXCHANGE_RATE (in-memory-loaded, spread-bearing), FX_CONVERSION_LOG (full audit trail)
service/fx_engine.py           - tested against 6 real scenarios
```

## Verified, working — 6 real scenarios

1. **A real conversion** — $5,000 (the same amount from TXN-003 in the SWIFT package) converts at a rate *below* the mid-market rate, the spread working in the bank's favor, exactly as real FX conversion actually operates
2. **Same-currency conversion** — genuinely 1:1, no spread applied at all
3. **Round-trip loss, proven, not asserted** — $1,000 → SGD → back to USD lands at $990.03, not $1,000.00. This is the honest, correct behavior — the bank earns its spread on *both* legs of the conversion, and pretending a round trip should be lossless would misrepresent how real currency conversion economics work
4. **Stale rate refused outright** — a rate 45 seconds old, past its configured 30-second staleness limit, is rejected rather than silently used. Using an out-of-date FX rate during a volatile market moment is a real, material financial risk, not a theoretical concern
5. **A fresh rate is correctly accepted** — proving the staleness check isn't overly aggressive
6. **The audit trail recovers the exact spread** — recording both the applied rate and the underlying mid rate means an auditor can independently verify the bank's actual margin on any conversion, computed purely from the stored record, without needing to trust it was fair

## Why recording both rates matters, specifically

A weaker design might log only the final converted amount. Test 6 proves something more valuable: given only `mid_rate_at_time` and `rate_applied` from the log, the exact 50 basis point spread is recoverable through simple arithmetic — no need to trust the system's own claim about its margin, the number itself proves it.

## How this ties into everything built today

```
An outgoing SWIFT settlement (swift-design) needs currency conversion
        │
        ▼
FxEngine.convert() — in-memory rate lookup, same caching principle
as routing-design's 6,261x measured speedup
        │
        ▼
FX_CONVERSION_LOG records both rates — same audit philosophy as
journal-design: complete, auditable, no reconstruction needed
        │
        ▼
The converted amount flows into the pacs.008 message construction
(swift-design), now carrying a genuinely correct converted value
```

## Honest limitation

Real-time rate *feed ingestion* (actually pulling live rates from Reuters/Bloomberg-equivalent sources) is not built — `EXCHANGE_RATE` is seeded with static test data. This package proves the conversion, spread, and staleness *logic* is correct against realistic rate data, not a live market data integration.
