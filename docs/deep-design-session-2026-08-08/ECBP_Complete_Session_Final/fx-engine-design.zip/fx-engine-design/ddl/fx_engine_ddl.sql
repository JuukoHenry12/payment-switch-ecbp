-- ============================================================
-- ECBP FX / Currency Exchange Engine — DDL
-- ============================================================
-- Directly extends the SWIFT cross-border work (swift-design,
-- earlier today) - that package moved USD to a correspondent
-- account but never actually converted currency. This closes that.
-- ============================================================

CREATE TABLE EXCHANGE_RATE (
    CURRENCY_PAIR             VARCHAR(7)     PRIMARY KEY,   -- e.g. 'USD/SGD'
    MID_RATE                     DECIMAL(12,6) NOT NULL,     -- the raw market rate, no margin applied
    SPREAD_BPS                      INTEGER    NOT NULL,     -- basis points of margin the bank applies (its actual revenue)
    SOURCE                             VARCHAR(30) NOT NULL, -- which real-time rate feed this came from
    UPDATED_AT                            TIMESTAMPTZ NOT NULL DEFAULT now(),
    MAX_STALENESS_SECONDS                    INTEGER  NOT NULL DEFAULT 30  -- a rate older than this MUST NOT be used
);

INSERT INTO EXCHANGE_RATE (CURRENCY_PAIR, MID_RATE, SPREAD_BPS, SOURCE) VALUES
    ('USD/SGD', 1.345000, 50, 'REUTERS_FEED'),   -- 50 bps = 0.50% spread
    ('SGD/USD', 0.743494, 50, 'REUTERS_FEED'),
    ('USD/EUR', 0.920000, 40, 'REUTERS_FEED');

CREATE TABLE FX_CONVERSION_LOG (
    CONVERSION_ID              UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    TXN_ID                        UUID        NOT NULL,   -- same correlation key as every package today
    FROM_CURRENCY                    CHAR(3)  NOT NULL,
    TO_CURRENCY                        CHAR(3) NOT NULL,
    SOURCE_AMOUNT                         DECIMAL(18,2) NOT NULL,
    CONVERTED_AMOUNT                        DECIMAL(18,2) NOT NULL,
    RATE_APPLIED                              DECIMAL(12,6) NOT NULL,  -- the ACTUAL rate used, spread included - full audit trail
    MID_RATE_AT_TIME                            DECIMAL(12,6) NOT NULL,  -- what the raw market rate was, for margin verification
    CONVERTED_AT                                  TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Recording BOTH the applied rate and the underlying mid rate is
-- what lets an auditor later verify the bank's actual margin on
-- every single conversion - not just trust it was fair.
