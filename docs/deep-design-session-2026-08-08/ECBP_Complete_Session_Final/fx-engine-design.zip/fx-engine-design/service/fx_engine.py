"""
fx_engine.py — real currency conversion, extending the SWIFT
cross-border work from earlier today (which moved money between
currencies without ever actually converting it). Two real properties
tested carefully:

  1. SPREAD APPLICATION - a bank never converts at the raw mid-market
     rate; it applies a spread (basis points of margin) that is its
     actual revenue on the conversion. Tested to prove the spread is
     correctly applied in the bank's favor on BOTH buy and sell sides,
     and that round-tripping a conversion (convert then convert back)
     genuinely loses value - exactly how real FX economics work, not
     an oversight.

  2. STALENESS PROTECTION - using an out-of-date exchange rate is a
     real, serious financial risk (rates move constantly; a 30-second-
     old USD/SGD rate during a volatile market moment could mean a
     real, material loss). Tested to prove a stale rate is rejected
     outright, not silently used.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP


class StaleRateError(Exception):
    pass


@dataclass
class ExchangeRate:
    currency_pair: str
    mid_rate: Decimal
    spread_bps: int
    updated_at: datetime
    max_staleness_seconds: int


class FxEngine:

    def __init__(self, rates: dict[str, ExchangeRate]):
        # Loaded into memory once, same principle as every config
        # cache built today - FX conversion happens on every
        # cross-border transaction, this cannot be a per-transaction
        # database round-trip.
        self.rates = rates

    def convert(self, amount: Decimal, from_currency: str, to_currency: str, now: datetime) -> dict:

        if from_currency == to_currency:
            # Same-currency "conversion" - no spread, no rate lookup
            # needed at all, genuinely 1:1.
            return {"converted_amount": amount, "rate_applied": Decimal("1.0"), "mid_rate": Decimal("1.0")}

        pair = f"{from_currency}/{to_currency}"
        rate = self.rates.get(pair)
        if rate is None:
            raise ValueError(f"No exchange rate available for {pair}")

        staleness = (now - rate.updated_at).total_seconds()
        if staleness > rate.max_staleness_seconds:
            raise StaleRateError(
                f"Rate for {pair} is {staleness:.0f}s old, exceeds the {rate.max_staleness_seconds}s "
                f"maximum staleness - REFUSING to convert using an out-of-date rate")

        # Apply the spread AGAINST the customer, in the bank's favor -
        # this is the actual, honest mechanic of how banks make money
        # on FX, not something to hide or approximate away.
        spread_multiplier = Decimal("1") - (Decimal(rate.spread_bps) / Decimal("10000"))
        effective_rate = rate.mid_rate * spread_multiplier

        converted = (amount * effective_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        return {"converted_amount": converted, "rate_applied": effective_rate, "mid_rate": rate.mid_rate}


# ------------------------------------------------------------
# REAL TESTS
# ------------------------------------------------------------
if __name__ == "__main__":

    now = datetime(2026, 8, 8, 12, 0, 0)

    rates = {
        "USD/SGD": ExchangeRate("USD/SGD", Decimal("1.345000"), 50, now, 30),
        "SGD/USD": ExchangeRate("SGD/USD", Decimal("0.743494"), 50, now, 30),
    }
    engine = FxEngine(rates)

    print("=== TEST 1: A basic conversion - TXN-003's real $5,000 USD from the SWIFT package earlier today ===")
    result1 = engine.convert(Decimal("5000.00"), "USD", "SGD", now)
    print(f"Mid rate: {result1['mid_rate']}, applied rate: {result1['rate_applied']}")
    print(f"Converted amount: {result1['converted_amount']} SGD")
    print(f"Applied rate is LOWER than mid rate (the spread working against the customer, "
          f"in the bank's favor): {result1['rate_applied'] < result1['mid_rate']} (expected: True)")

    print()
    print("=== TEST 2: Same-currency 'conversion' - exactly 1:1, no spread applied ===")
    result2 = engine.convert(Decimal("100.00"), "USD", "USD", now)
    print(f"Converted amount: {result2['converted_amount']} (expected: 100.00, unchanged)")

    print()
    print("=== TEST 3: Round-trip conversion GENUINELY loses value - real FX economics, not a bug ===")
    usd_to_sgd = engine.convert(Decimal("1000.00"), "USD", "SGD", now)
    sgd_amount = usd_to_sgd["converted_amount"]
    back_to_usd = engine.convert(sgd_amount, "SGD", "USD", now)
    final_usd = back_to_usd["converted_amount"]
    print(f"Started with: $1000.00 USD")
    print(f"Converted to: {sgd_amount} SGD")
    print(f"Converted back to: ${final_usd} USD")
    print(f"Genuinely less than the original $1000.00 (the bank's spread on BOTH legs, "
          f"exactly how real FX conversion actually costs money): {final_usd < Decimal('1000.00')}")

    print()
    print("=== TEST 4: STALE RATE - a rate older than its staleness limit is correctly REFUSED ===")
    stale_now = now + timedelta(seconds=45)  # 45s later, exceeds the 30s max staleness
    try:
        engine.convert(Decimal("1000.00"), "USD", "SGD", stale_now)
        print("FAIL - a stale rate was used without complaint")
    except StaleRateError as e:
        print(f"Correctly refused: {e}")

    print()
    print("=== TEST 5: A FRESH rate, well within staleness limits, is correctly accepted ===")
    fresh_now = now + timedelta(seconds=10)  # 10s later, well within the 30s limit
    result5 = engine.convert(Decimal("1000.00"), "USD", "SGD", fresh_now)
    print(f"Converted successfully: {result5['converted_amount']} SGD (expected: succeeds, no staleness error)")

    print()
    print("=== TEST 6: Full audit trail captures BOTH the applied rate and the underlying mid rate ===")
    print("(this is what lets an auditor later verify the bank's actual margin on any conversion)")
    print(f"For test 1's conversion: mid_rate={result1['mid_rate']}, rate_applied={result1['rate_applied']}")
    implied_spread_bps = round((1 - (result1['rate_applied'] / result1['mid_rate'])) * 10000)
    print(f"Implied spread recoverable from the audit trail alone: {implied_spread_bps} bps "
          f"(expected: 50, matching the configured spread exactly)")
